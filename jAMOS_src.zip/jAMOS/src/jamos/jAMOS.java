/////////////////////////////////////////////////////////////////
// jAMOS - AMOS BASIC reimplemented in Java!                   //
// (C) 2012 Mequa Innovations                                  //
/////////////////////////////////////////////////////////////////

package jamos;

//import java.util.*;
//import java.util.List; 

import jamos.abkviewer.AbkViewer;
import jamos.jamal.AmalPrograms;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.text.*;
//import javax.swing.event.*;
import javax.swing.undo.*;
import java.util.zip.*;
//import java.util.jar.*;
//import GameEngineWrapper.AMOS_Sprite;

import jgame.*;
//import jgame.impl.JGEngineInterface;
import jgame.platform.*;

/** Alpha version jGame integration in jAMOS */
public class jAMOS extends JGEngine //StdGame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7994608697645436867L;
	// The above was added by Eclipse IDE.

	// Added:
	static boolean runonly = false; //true;
	int applet;
	static String title;

	static AMOS_System AM;
	static String amosCode;
	static String[] AMALCode;
	static String environmentCode;
	static GameEngineWrapper wrapper;

	// ntsc or pal - this is set false (PAL mode) here by default
	// also false (PAL mode) in main() - change main() to change default!

	boolean ntsc = true;

	static String inputstring;
	JScrollPane scrollPane;
	private JTextArea    _editArea;
	JMenu fileMenu2;
	JMenu fileMenu3;
	JMenu fileMenu4;
	JMenu fileMenu5;
	JMenu fileMenu6;
	JMenu fileMenu7;
	JMenu fileMenu8;
	JMenu fileMenu9;

	HashMap<Object, Action> actions;

	//undo helpers
	protected UndoAction undoAction;
	protected RedoAction redoAction;
	protected UndoManager undo = new UndoManager();

	private Action _runAction2 = new RunAction2();
	private Action _runAction = new RunAction();
	private Action _pauseAction = new PauseAction();

	//protected RunAction _runaction;
	//protected PauseAction _pauseaction;
	boolean editorpaused = false;

	// Added:
	boolean launchprogramnow = false;
	boolean loadexamplenow = false;
	String loadexamplefilename = "";
	boolean loadfilenow = false;
	boolean savefilenow = false;
	boolean savejavafilenow = false;
	String javacode = "";
	boolean runcompiledexamplenow = false;
	boolean translatetoviewnow = false;
	boolean translatetocpp = false;
	boolean translatetosavenow = false;
	boolean outputtojarnow = false;

	//static Player mainsprite1; // moved to GameEngineWrapper
	static int numprograms;

	static MyListener myListener;

	int editingchannel = 1;
	boolean viewingtranslatedcode = false;
	boolean editingenvironment = false;
	static boolean editingamos = true;

	int[] caretposition = new int[1024];

	// Added for editor window - stored in frame:
	public static JFrame frame;
	
	// Is this needed?
	//JGFont scoring_font = new JGFont("Arial", 0, 8);
	
	jAMOS mthis;
	

	public static void main(String[]args)
	{
		// Select PAL mode (ntsc=false) for now:
		boolean ntsc;
		ntsc=false;
		new jAMOS(ntsc); //new JAMAL(new JGPoint(720, 576));
	}
	
	// Launch applet mode:
	// Select PAL mode (ntsc=false) for now:
	public jAMOS()
	{
		ntsc = false;
		initEngineApplet();
	}
	public jAMOS(boolean nts)
	{
		ntsc=nts;
		if (nts)
			initEngine(720, 480);
		else
			initEngine(720, 576);
	}
	//public JAMAL(JGPoint size) { initEngine(size.x,size.y); }
	
	// Initialise the "game":
	public void initGame()
	{
		// Removed (now empty file) - load resources from JGame table:
		//defineMedia("resources/jAMAL.tbl");

		// Define empty JGame table (and enable splash screen):
		defineMedia("resources/blank.tbl");

		// First define the splash image here:
		// Was: splash_image	-	0	resources/jAMOS.jpg	- // jAMAL.jpg
		//setsplash();

		// "null" indicates the null image, which will show as a transparent tile
		// Was: emptytile	.	0	null
		defineImage("emptytile", ".", 0, "null", "-");
		defineImage("null", ".", 0, "null", "-");

		//int t = -1;
		mthis = this;
		wrapper = new GameEngineWrapper(this);
		wrapper.AM = new AMOS_System(this);
		AM = wrapper.AM;
		AM.wrapper = wrapper;
		myListener = new MyListener();

		// Load the converted/translated/compiled AMAL scripts here:
		AM.translatedamalprograms = new AmalPrograms(AM);

		int t;

		t=jamos(((Class<? extends jAMOS>)getClass()));
		setsplash();

		if (t == 0);
		////	AM.amalcompiler.AmalCompile(System.out, 1, numprograms);

		wrapper.initspritesandbobs();
		//try { wait(1000); } catch (Exception e) { };

		wrapper.mainsprite1 = new Player(0, 0, 1); //0, 0, 5

		// Debug:
		//mainsprite1.setGraphic("splash_image"); // debug

		// Set the default AMAL Environment Generator code - removed:
		//environmentCode = defaultEnvGenString();

		// Add some sprites:
		// New - because of EnvGen, only add sprites we need
		// TO DO - improve this:

		//System.out.println("numprograms = " + numprograms);
		for (int pp = 1; pp <= numprograms; pp++)
		{
			// New: Only create sprite if doesn't already exist:
			if (true)
				AM.sprite(pp, pfWidth()/2 - 30, pfHeight()/2 - 40, 1);

			AM.amalOn(pp);
		}
		// AM.amalOn(); // To fix!

		for (int pp = 1; pp <= numprograms; pp++)
			AM.channelToSprite(pp, pp);

		// Added: Reset the screen position (TO DO)
		AM.screenDisplay(0,0,0);
		AM.screenOffset(0,0,0);



		// Lex the environment string:
		// Debug - if environment buffer is null:
		if (environmentCode == null)
			System.out.println("Null AMAL environment string!");
		AM.envGen.processcode(environmentCode);

		// Interpret and run the environment string (MOVED):
		AM.envGen.interpretEnvGen();


		// MequaScript: Tokenise the instructions:
		AM.lexer.lexString(amosCode);


		// Set the decorative background image
		//setBGImage("jamal");

		//setBGImage("jamal");
		//setBGImage("back1");
		//setBGColor(JGColor.black);
		//setBGImage(1, "jamal", true, true);

		// Removed: 50fps PAL refresh (non-Vsync). Put back in as an option?
		if (isMidlet())
		{
			//setFrameRate(25,1);
			if (ntsc)
				setFrameRate(30,1); // 60,1 // 45,1
			else
				setFrameRate(30,1); // Changed. Was (25,1)
			setGameSpeed(2.0);
		} else {
			if (ntsc)
				setFrameRate(60,1); // 60,1 // 45,1
			else
				setFrameRate(60,1); // Changed. Was (50,1)
		}

		// Added: Use VSync with JOGL as default.
		setVideoSyncedUpdate(true);
		//setVideoSyncedUpdate(false);

		//setHighscores(10,new Highscore(0,"nobody"),15);
		//startgame_ingame=true;

		// Hide the mouse cursor:
		setCursor(null);

		// Added: Create console window:
		new Console();

		// Create editor window here:
		if (!runonly)
			createtextpane();
	}
	
	// Entered after the main method:
	public int jamos(Class<? extends jAMOS> mthis) // throws IOException //(String args[]) throws IOException
	{
		// TO DO: Load Blank.jamos instead of Default.jamos if no resources found:
		//String filename = "amos/Blank.jamos";
		String runonlyfilename = "example/RunOnly.jamos";
		String filename = "example/Default.jamos";

		// Added for jAMOS:
		editingamos = true;

		AMALCode = new String[256];
		boolean usefile = false;

		AMALCode[0] = ""; AMALCode[1] = "Move 100,100,25;";
		//AMALCode[1] = "";

		// First check if a RunOnly.jamos file is present, and if so load and disable the editor:
		try {
			AMALCode = loadfile(usefile, filename, AMALCode, mthis.getResourceAsStream(runonlyfilename));
			runonly = true;
		} catch (Exception e) { }

		if (!runonly)
		{
			try {
				AMALCode = loadfile(usefile, filename, AMALCode, mthis.getResourceAsStream(filename));
			} catch (Exception e) { System.out.println("Error loading file "+filename);}
		}

		if (AMALCode == null)
			System.out.println("Error loading code string!");

		numprograms = 0;
		inputstring = "";

		//if (AMALCode != null)
		for (int channel = 1; (channel < AMALCode.length) && !(AMALCode[channel].equals("")); channel++)
		{
			AM.amal(channel, AMALCode[channel]);
			inputstring += AMALCode[channel] + '\n';
			numprograms++;
		}
		return 0;
	}
	
	// (640, 512) //(640, 442));}
	//public static void main(String[]args) {new JAMAL(parseSizeArgs(args,0));}

	//public void initCanvas() { setCanvasSettings(40,26,16,16,null,null,null); }
	//public void initCanvas() { setCanvasSettings(40,32,16,16,null,null,null); }
	public void initCanvas()
	{
		if (ntsc)
			initCanvas_ntsc();
		else
			initCanvas_pal();
	}
	// PAL full SD 720x576
	public void initCanvas_pal()
	{
		setCanvasSettings(45,36,16,16,null,null,null);
	}
	// NTSC full SD 720x480
	public void initCanvas_ntsc()
	{
		setCanvasSettings(45,30,16,16,null,null,null);
	}

	// Used to grab the resource:
	InputStream grabresource(String filename)
	{
		return getClass().getResourceAsStream(filename);
	}

	//public static void requestfocus() { requestFocus(); }

	void setsplash()
	{
		// Update the splash image:
		try
		{
			if (!runonly)
				defineImage("splash_image", "-", 0, "resources/jAMOS.jpg", "-"); // jAMAL.jpg
			else
				defineImage("splash_image", "-", 0, "resources/RunOnly.jpg", "-");
		}
		catch (Exception e)
		{	
		}
	}

	public void startGameOver()
	{
		removeObjects(null, 0);
	}
	public void doFrame()
	{
		// Move all objects.
		moveObjects();
	}

	// Create default AMAL Environment Generator string here:
	public static String defaultEnvGenString()
	{
		String out;
		// Added: Create default Environment string: 
		out = "' AMAL Environment Generator\n";
		out += "Bob Off : Sprite Off : Rainbow Del\nScreen 0\n";
		out += "Screen Open 0,720,576,16777216,Hires+Laced\n";
		out += "Load \"resources/sprites\", 1\n";
		out += "Load Iff \"resources/back.jpg\", 0\n";
		return out;
	}

	public String[] loadfile(boolean usefile, String filename, String[] AMALCode, InputStream input) throws IOException
	//public static String[] loadfile(boolean usefile, String filename, String[] AMALCode, Class<? extends JAMAL> mthis, InputStream input) throws IOException
	//public static String[] loadfile(boolean usefile, String filename, String[] AMALCode, JAMAL mthis) throws IOException
	{
		// Load the file:
		String channelCode = "";
		String line = "";
		int channel = -2; // for jAMOS
		//InputStream input;
		InputStreamReader isr;
		LineNumberReader lnr;

		// Set the default AMAL Environment Generator code:
		environmentCode = defaultEnvGenString();
		if (frame != null)
		{
			//String newfname = filename;

			//System.out.println("Debug: Testing filename part:\""
			//		+ filename.substring(0, 8)+"\" with \"example/");
			if (filename.substring(0, 8).equals("example/"))
			{
				//frame.setTitle(title+" - \""+filename+"\"");
				frame.setTitle(title+" - "+(filename.substring(8)).substring(0, (filename.length() - 14)));
			}
			else
			{
				frame.setTitle(title+" - "+filename);
			}
		}
		// Choose between file and resource loading:
		if (usefile)
		{
			FileInputStream fis = new FileInputStream(filename);
			isr = new InputStreamReader(fis);
		}
		else
		{	
			//input = ((Class<? extends JAMAL) mthis).getResourceAsStream(filename);
			//input = ((Class<? extends JAMAL>) mthis).getResourceAsStream(filename);
			//input = mthis.getResourceAsStream(filename);
			isr = new InputStreamReader(input);
		}

		lnr = new LineNumberReader(isr);

		// Updated to parse EnvGen strings from file:
		while(true)
		{
			line = lnr.readLine();
			if (line == null)
				break;

			// Debug: Test for EnvGen switch:
				//if (line.length()>15)// && (line.substring(0, 16)).equals("AMAL Environment"))
			//	System.out.println("Debug: Environment? "+line.substring(0, 11));
			
			if (line.length()>13 && (line.substring(0, 13)).equals("AMAL Channel "))
			{
				if (channel >= 0)
					AMALCode[channel] = channelCode;
				else if (channel == -2)
					amosCode = channelCode;
				else
					environmentCode = channelCode;

				channel = Integer.parseInt(line.substring(13));
				//System.out.println(channelCode);
				//System.out.println("AMAL Program = " + channel);
				channelCode = "";
			}
			// Added - load the EnvGen string from file if found:
			else if (line.length()>15 && (line.substring(0, 16)).equals("AMAL Environment"))
			{
				if (channel >= 0)
					AMALCode[channel] = channelCode;
				else if (channel == -2)
					amosCode = channelCode;
				else
					environmentCode = channelCode;

				channel = -1; // -1 for EnvGen for now
				//System.out.println("Attempting to load EnvGen string from file!");
				channelCode = "";
			}
			else
			{
				channelCode += line + "\n";
				//channelCode += line + " ";
			}
		}
		
		// Added for jAMOS
		if (channel == -2)
		{
			amosCode = channelCode + '\n';
			AMALCode[0] = "default amal program";
		}
		else if (channel == -1)
		{
			environmentCode = channelCode + '\n';
			AMALCode[0] = "default amal program";
		}
		else
		{
			AMALCode[channel] = channelCode + '\n';
			AMALCode[channel + 1] = "";
		}

		// Lex the environment string:
		AM.envGen.processcode(environmentCode);

		// MequaScript: Tokenise the instructions:
		AM.lexer.lexString(amosCode);

		// Close files here if appropriate...
		if (usefile)
		{

		}

		return AMALCode;
	}

	// Run an included compiled/translated example here:
	public void runcompiledexample()
	{
		int oldnumprograms = numprograms;

		//AM.amalOff();
		for (int c = 1; c <= numprograms; c++)
			AM.amalOff(c);

		// Save the text if appropriate:
		//if (!viewingtranslatedcode)
		//	AMALCode[editingchannel] = _editArea.getText();

		// Switching to compiled mode - hold on to your hats!
		editingamos = false;
		AM.runningcompiled = true;
		viewingtranslatedcode = true;

		// Clear the loaded file info:
		frame.setTitle(title + "- Compiled Java Example");

		// Destroy the old code here:
		//if (AMALCode != NULL)
		//AMALCode.free();
		//AMALCode = new String[256]; // fix
		for (int s=0; s<256; s++)
			AMALCode[s] = null;

		// Initialise the channels here:
		numprograms = AM.translatedamalprograms.numPrograms();
		fileMenu2.setText("Running translated code");

		// Now flip the text:
		//editingchannel = 1; // fix this, should start from 0?
		_editArea.setText("This program is already translated to Java source and successfully built!");
		_editArea.setCaretPosition(0); // move to top

		// Destroy the old sprites here:
		//AM.spriteOff();
		for (int channel = 1; channel <= oldnumprograms; channel++)
		{
			AM.amalOff(channel);
			AM.sprite(channel, -100, -100, 1);// kludge!
			wrapper.mainsprite[channel].destroy(); // does this work?
			wrapper.mainsprite[channel] = null;
		}
		//AM.AmalOff(); // debug this

		// Set the default channels to sprites:
		for (int channel = 1; channel <= numprograms; channel++)
			AM.channelToSprite(channel, channel);

		// Added: Reset the screen position (TO DO)
		AM.screenDisplay(0,0,0);
		AM.screenOffset(0,0,0);

		// Create the new sprites here:
		for (int channel = 1; channel <= numprograms; channel++)
		{
			AM.sprite(channel, pfWidth()/2 - 30, pfHeight()/2 - 40, 1);
			AM.amal(channel, channel); // moved
			AM.amalOn(channel); // moved - use AM.AmalOn(); after the loop when fixed.
		}

		// Added - MequaScript: Erase the code and tokenise:
		amosCode = "";
		AM.lexer.lexString(amosCode);

		// Run the translated environment script:
		AM.translatedamalprograms.environment();

		//AM.AmalOn();

		// Remove the old channel menu:
		//for (int c = oldnumprograms+2; c >= 1; c--) // was +1
		//	fileMenu2.remove(c-1);
		fileMenu2.removeAll();

		// Added: Environment window (dummy menu item here):
		JMenuItem nm = new JMenuItem("Translated Environment");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		// Create the new channel menu here:
		for (int c = 1; c <= numprograms; c++)
		{
			nm = new JMenuItem("Translated " + c);
			nm.addActionListener(myListener);
			fileMenu2.add(nm);
		}
	}

	// Load the file or resource here!
	public void loadamalexample(String filename, boolean usefile)
	{
		int oldnumprograms = numprograms;
		editingenvironment = false;

		//if (AMALCode != NULL)
		//	AMALCode.free();

		//AMALCode = new String[256]; // fix
		for (int s=0; s<256; s++)
			AMALCode[s] = null;

		//boolean usefile = false;
		AMALCode[0] = "";
		if (!usefile){
			try{ AMALCode = loadfile(usefile, "example/"+filename, AMALCode, grabresource("example/"+filename));}
			catch (Exception e2) { }
		}else{
			try{ AMALCode = loadfile(usefile, filename, AMALCode, grabresource(filename));}
			catch (Exception e2) { }
		}
		numprograms = 0;
		inputstring = "";

		for (int channel = 1; (channel < AMALCode.length) && !(AMALCode[channel] == null) && !(AMALCode[channel].equals("")); channel++)
		{
			//AM.amal(channel, AMALCode[channel]);
			inputstring += AMALCode[channel] + '\n';
			numprograms++;
		}

		// Now flip the text:
		// Added - check if loading .jamos or .jamal file:
		if (AM.right(loadexamplefilename, 6).equals(".jamal"))
		{
			editingamos = false;
			editingchannel = 1; // fix this, should start from 0?
			_editArea.setText(AMALCode[editingchannel]);
		}
		else
		{
			editingamos = true;
			editingchannel = 1; // fix this, should start from 0?
			_editArea.setText(amosCode);
		}

		_editArea.setCaretPosition(0); // move to top


		// Need to fix the menus here too - update number of channels.

		// Destroy the old sprites here:
		//AM.spriteOff();
		for (int channel = 1; channel <= oldnumprograms; channel++)
		{
			AM.amalOff(channel);
			AM.sprite(channel, -100, -100, 1); // kludge!
			wrapper.mainsprite[channel].destroy(); // does this work?
			wrapper.mainsprite[channel] = null;
		}
		//AM.AmalOff(); // debug this

		// Wait for the interpreter to finish (debug this):
		//while (AM.interpreterrunning)
		//	System.out.println("Waiting for the interpreter to finish!");

		// Lex the environment string:
		AM.envGen.processcode(environmentCode);

		// MequaScript: Tokenise the instructions:
		AM.lexer.lexString(amosCode);

		// Create the new sprites here as necessary (TO DO):
		for (int channel = 1; channel <= numprograms; channel++)
			if (true) // Check if does not exist here or is != null (?)
				AM.sprite(channel, pfWidth()/2 - 30, pfHeight()/2 - 40, 1);

		// Set the default channels to sprites:
		for (int channel = 1; channel <= numprograms; channel++)
			AM.channelToSprite(channel, channel);

		// Added: Reset the screen position (TO DO)
		AM.screenDisplay(0,0,0);
		AM.screenOffset(0,0,0);

		// Interpret and run the environment string - MOVED:
		AM.envGen.interpretEnvGen();

		// Start the AMAL scripts, allocate to channel (currently 'flat'), and turn on:
		for (int channel = 1; channel <= numprograms; channel++)
		{
			//AM.channelToSprite(channel, channel); // redundant? - removed
			AM.amal(channel, AMALCode[channel]); // moved
			AM.amalOn(channel); // moved - use AM.AmalOn(); after the loop when fixed.
		}

		//System.out.println("Old number of channels:" + oldnumprograms);
		//System.out.println("New number of channels:" + numprograms);

		// Remove the old channel menu:
		fileMenu2.removeAll();

		if (editingamos)
			fileMenu2.setText("jAMOS Program");
		else
			fileMenu2.setText("AMAL Program "+editingchannel);

		// Added: AMOS window:
		JMenuItem nm = new JMenuItem("jAMOS Program");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		fileMenu2.addSeparator();

		// Added: Environment window:
		nm = new JMenuItem("AMAL Environment");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		// Create the new channel menu here:
		for (int c = 1; c <= numprograms; c++)
		{
			nm = new JMenuItem("AMAL " + c);
			nm.addActionListener(myListener);
			fileMenu2.add(nm);
		}

		fileMenu2.addSeparator();

		nm = new JMenuItem("New Channel");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		fileMenu2.addSeparator();

		nm = new JMenuItem("Show All Programs");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);
	}
	
	public void unpauseamal()
	{
		editorpaused = false;
		//_pauseAction.setText("");
		for (int pp = 1; pp <= numprograms; pp++)
			AM.amalOn(pp);
		//AM.amalOn(); // broken here?
	}

	public void runamal()
	{
		//AM.amalOff();
		for (int c = 1; c <= numprograms; c++)
			AM.amalOff(c);

		// Save the text if appropriate:
		if (!viewingtranslatedcode)
		{
			if (editingamos)
				amosCode = _editArea.getText();
			else if (editingenvironment == false)
				AMALCode[editingchannel] = _editArea.getText();
			else
				environmentCode = _editArea.getText();
		}

		// Flip the background to something more gamey:
		//setBGImage("jamal");
		//SwingUtilities.invokeLater(new Runnable() { public void run() { setBGImage("jamal");} } );

		//setRequestFocusEnabled(true);
		//JAMAL.requestFocus(); // which element to select?

		// Wait for the interpreter to finish:
		//while (AM.interpreterrunning)
		//System.out.println("Waiting for the interpreter to finish!");

		// Lex the environment string:
		AM.envGen.processcode(environmentCode);

		// MequaScript: Tokenise the instructions:
		AM.lexer.lexString(amosCode);

		// Create the new sprites here as necessary (TO DO):
		for (int channel = 1; channel <= numprograms; channel++)
			if (true) // Check if does not exist here or is != null (?)
				AM.sprite(channel, pfWidth()/2 - 30, pfHeight()/2 - 40, 1);

		// Set the default channels to sprites:
		for (int channel = 1; channel <= numprograms; channel++)
			AM.channelToSprite(channel, channel);

		// Added: Reset the screen position (TO DO)
		AM.screenDisplay(0,0,0);
		AM.screenOffset(0,0,0);

		// Interpret and run the environment string - MOVED:
		AM.envGen.interpretEnvGen();

		// Start the AMAL scripts, allocate to channel (currently 'flat'), and turn on:
		for (int c = 1; c <= numprograms; c++)
		{
			if (!AM.runningcompiled)
				AM.amal(c, AMALCode[c]); // moved
			else
				AM.amal(c, c);
			AM.amalOn(c); // moved - use AM.AmalOn(); after the loop when fixed.
		}

		// AM.AmalOn(); // is broken here(?). (doesn't correctly calculate number of channels)
	}
	
	
	// TODO - move/tidy this!
	public class Player extends JGObject
	{
		public Player(double x,double y,double speed)
		{

			// Load default background (blank) - was "jamal" instead of "":
			super("myobject",true,x,y,1,"", 0,0,speed,speed,-1);

			// Added - TO DO - may move this
			// Load the default background image:

			//defineImage("resources/back.jpg", "", 0, "resources/back.jpg", "img_op", 0, 0, 4000, 4000);
			//setImage(null); // Is this needed?
			//setImage("resources/back.jpg"); // Set the graphics

			//super("myobject",true,x,y,1,"splash_image", 0,0,speed,speed,-1);
			//setGraphic("jamal"); // debug

			//super("myobject",true,x,y,1,"jAMOS.jpg", 0,0,speed,speed,-1); // jAMAL.JPG
			// Double to lores:
			/*SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					JGImage i = getImage("jamal");
					i.scale(640, 442);
					setImage("jamal");
				}
			});*/
		}
		public void move()
		{
			setDir(0,0);

			// Interpret and run the MequaScript string:
			if (!editorpaused)
				for (int n=0; n<AM.g.ActiveObjects.size(); n++)
					AM.interpreter.interpret(AM.g.mytokens, n);

			// Run the AMAL interpreter here:
			AM.synchro();

			wrapper.animatesprites();
			wrapper.animatebobs();

			//x+=0.01; // test early screen motion
			//System.out.println("Sprite 1 animation frame: " + AM.ISprite(1));

			// Test sprite motion:
			//AM.Sprite(0, AM.XSprite(0)+1, AM.YSprite(0), 1);*/

			// Test - use this thread to select "Run" or "Restart":
			if (launchprogramnow)
			{
				launchprogramnow = false;

				//if (!AM.runningcompiled)
				runamal(); // fix this for compiled examples!
			}
			else if (loadexamplenow)
			{
				loadexamplenow = false;
				AM.runningcompiled = false;
				loadamalexample(loadexamplefilename, false); // usefile=false
			}
			else if (loadfilenow)
			{
				loadfilenow = false;
				AM.runningcompiled = false;

				// Grab the filename:
				loadamalexample(loadexamplefilename, true); // usefile = true; false for debug
			}
			else if (savefilenow)
			{
				savefilenow = false;

				// Grab the filename:
				savejamosfile(loadexamplefilename);
			}
			else if (runcompiledexamplenow)
			{
				runcompiledexamplenow = false;
				runcompiledexample();
			}
			else if(translatetoviewnow)
			{
				translatetoviewnow = false;
				viewingtranslatedcode = true;
				String header = "";
				String content;
				
				if (translatetocpp)
				{
					fileMenu2.setText("Viewing C++");
					
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					PrintStream ps = new PrintStream(baos);
					AM.amalcompiler.AmalCompileCPPHeader(ps, 1, numprograms);
					header = baos.toString(); //(charsetName); // e.g. ISO-8859-1
					playAudio("translated");
				}
				else
				{
					fileMenu2.setText("Viewing Java");
					playAudio("java");
				}

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				AM.amalcompiler.AmalCompile(ps, 1, numprograms, translatetocpp); // Added: false for CPP
				
				if (translatetocpp)
				{
					content = "*** AmalPrograms.h ***\n" + header + "\n*** AmalPrograms.cpp ***\n" + baos.toString(); //(charsetName); // e.g. ISO-8859-1
				}
				else
				{
					content = baos.toString(); //(charsetName); // e.g. ISO-8859-1
				}

				// Now flip the text:
				_editArea.setText(content);
				_editArea.setCaretPosition(0); // move to top
			}
			else if (translatetosavenow)
			{
				translatetosavenow = false;

				viewingtranslatedcode = true;
				fileMenu2.setText("Viewing Java");

				playAudio("java");

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				AM.amalcompiler.AmalCompile(ps, 1, numprograms, translatetocpp); // Added: false for CPP
				String content = baos.toString(); //(charsetName); // e.g. ISO-8859-1

				// Now flip the text:
				_editArea.setText(content);
				_editArea.setCaretPosition(0); // move to top

				// Now grab the text to export to a file:
				// Use an OS-native file requester:
				FileDialog fd = new FileDialog(new Frame(), "Save an AmalPrograms.java file", FileDialog.SAVE);
				fd.setFile("AmalPrograms.java");
				//fd.setDirectory("../");
				fd.setLocation(50, 50);
				fd.setVisible(true); //fd.show(); // fix this!
				loadexamplefilename = fd.getFile();

				// Now we signal for this to be called on another thread:
				javacode = content;
				savejavafilenow = true;
			}
			else if (savejavafilenow)
			{
				savejavafilenow = false;

				// Save the Java file:
				savejavafile(loadexamplefilename);
			}
			else if (outputtojarnow)
			{
				outputtojarnow = false;
				outputtojar();
			}
		}
	}

	/////////////////////////////////////////////////
	// The jAMOS Editor:
	/////////////////////////////////////////////////

	public void createtextpane()
	{
		//... Create scrollable text area.
		_editArea = new JTextArea(25, 100); //(15, 80);
		_editArea.setBorder(BorderFactory.createEmptyBorder(2,2,2,2));
		_editArea.setFont(new Font("monospaced", Font.PLAIN, 14));

		//JScrollPane scrollingText;
		scrollPane = new JScrollPane(_editArea);

		// Added: Add CTRL+Y shortcut to delete a whole line (easter egg):
		_editArea.addKeyListener(new KeyListener()
		{
			@Override
			public void keyTyped(KeyEvent e) { }

			@Override
			public void keyPressed(KeyEvent e)
			{
				if ((e.getKeyCode() == KeyEvent.VK_Y) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0))
				{
					System.out.println("Delete a line here!");
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {}
		});

		// Added: Add [Shift]+[Cursor arrows] (easter egg):
		_editArea.addKeyListener(new KeyListener()
		{
			@Override
			public void keyTyped(KeyEvent e) { }

			@Override
			public void keyPressed(KeyEvent e)
			{
				if ((e.getKeyCode() == KeyEvent.VK_UP) && ((e.getModifiers() & KeyEvent.SHIFT_MASK) != 0))
				{
					_editArea.setCaretPosition(0); // move to top
				}
				else if ((e.getKeyCode() == KeyEvent.VK_DOWN) && ((e.getModifiers() & KeyEvent.SHIFT_MASK) != 0))
				{
					_editArea.setCaretPosition(_editArea.getHeight()-1); // move to bottom
				}
				else if ((e.getKeyCode() == KeyEvent.VK_LEFT) && ((e.getModifiers() & KeyEvent.SHIFT_MASK) != 0))
				{
					//_editArea.setCaretPosition(_editArea.getHeight()-1); // move to bottom
				}
				else if ((e.getKeyCode() == KeyEvent.VK_RIGHT) && ((e.getModifiers() & KeyEvent.SHIFT_MASK) != 0))
				{
					//_editArea.setCaretPosition(_editArea.getHeight()-1); // move to bottom
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {}
		});


		//-- Create a content pane, set layout, add component.
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		content.add(scrollPane, BorderLayout.CENTER);

		//... Create menubar
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = menuBar.add(new JMenu("Start"));
		fileMenu.setMnemonic('S');
		fileMenu.add(_runAction);
		fileMenu.add(_runAction2);
		fileMenu.add(_pauseAction);
		fileMenu.addSeparator();

		// New:
		JMenuItem nm = new JMenuItem("New Project");
		nm.addActionListener(myListener);
		fileMenu.add(nm);
		fileMenu.addActionListener(myListener);
		fileMenu.addSeparator();

		nm = new JMenuItem("About jAMOS");
		nm.addActionListener(myListener);
		fileMenu.add(nm);
		fileMenu.addActionListener(myListener);
		nm = new JMenuItem("About jAMAL");
		nm.addActionListener(myListener);
		fileMenu.add(nm);
		fileMenu.addActionListener(myListener);
		fileMenu.addSeparator();

		nm = new JMenuItem("Exit");
		nm.addActionListener(myListener);
		fileMenu.add(nm);
		fileMenu.addActionListener(myListener);


		// Note use of actions, not text.
		//fileMenu.add(_saveAction);
		//fileMenu.addSeparator(); 
		//fileMenu.add(_exitAction);

		//JMenu editMenu = menuBar.add(createEditMenu());

		fileMenu2 = menuBar.add(new JMenu("jAMOS Program"));
		fileMenu2.setMnemonic('N');

		// Added: AMOS window:
		nm = new JMenuItem("jAMOS Program");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		fileMenu2.addSeparator();

		// Added: Environment window:
		nm = new JMenuItem("AMAL Environment");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		for (int c = 1; c <= numprograms; c++)
		{
			nm = new JMenuItem("AMAL " + c);
			nm.addActionListener(myListener);
			fileMenu2.add(nm);
		}

		fileMenu2.addSeparator();

		nm = new JMenuItem("New Channel");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		fileMenu2.addSeparator();

		nm = new JMenuItem("Show All Programs");
		nm.addActionListener(myListener);
		fileMenu2.add(nm);

		// Add Strip menu and item/buttons (rename identifier):
		fileMenu5 = menuBar.add(new JMenu("AMAL Stripper"));
		fileMenu5.setMnemonic('R');
		fileMenu5.addActionListener(myListener);

		nm = new JMenuItem("Strip all and display");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("Strip current and display");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		fileMenu5.addSeparator();

		nm = new JMenuItem("Strip current and update");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("Strip all and update");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);


		// Add Translate menu and item/button:
		fileMenu3 = menuBar.add(new JMenu("Translator"));
		fileMenu3.setMnemonic('T');

		nm = new JMenuItem("Translate to Java");
		nm.addActionListener(myListener);
		fileMenu3.add(nm);
		fileMenu3.addActionListener(myListener);
		
		nm = new JMenuItem("Translate to C++");
		nm.addActionListener(myListener);
		fileMenu3.add(nm);
		fileMenu3.addActionListener(myListener);


		// Add jAMOS Example menu and item/button:
		fileMenu8 = menuBar.add(new JMenu("Example"));
		fileMenu8.setMnemonic('E');

		nm = new JMenuItem("Plotter.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("Mandelbrot.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("LoadAbk.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);
		
		nm = new JMenuItem("LoadAbk2.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("PasteBob.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("PasteBobAbk.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("Drawing.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("Rainbows.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("Arrays.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);
		
		nm = new JMenuItem("EnvgenAndDatatypes.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);
		
		

		nm = new JMenuItem("jAMOSOut.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);

		nm = new JMenuItem("Default.jamos");
		nm.addActionListener(myListener);
		fileMenu8.add(nm);


		// Add jAMOS Tutorial menu and item/button:
		fileMenu9 = menuBar.add(new JMenu("Tutorial"));
		fileMenu9.setMnemonic('T');

		nm = new JMenuItem("HelloWorld.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("DynamicTypes.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("HybridSyntax.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("MoveSprite.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("UseMouse.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("UseGameControls.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("Maths.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("Procedures.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("Procedures2.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);

		nm = new JMenuItem("MultiBrains.jamos");
		nm.addActionListener(myListener);
		fileMenu9.add(nm);        


		// Add AMAL Example menu and item/button:
		fileMenu4 = menuBar.add(new JMenu("AMAL Example"));
		fileMenu4.setMnemonic('A');

		nm = new JMenuItem("MultiChannelExample.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("BouncyBalls.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("MoreBouncyBalls.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("OldDefault.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("Mystery.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("Shoot.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("ScreenDragDemo.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		nm = new JMenuItem("ScreenScrollingDemo.jamal");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		fileMenu4.addSeparator();
		nm = new JMenuItem("Translated Example");
		nm.addActionListener(myListener);
		fileMenu4.add(nm);

		if (!isApplet())
		{
			// add to Translate menu too, as well as File:
			//fileMenu3.addSeparator();

			nm = new JMenuItem("Export as a Java file");
			nm.addActionListener(myListener);
			fileMenu3.add(nm);
		}

		fileMenu3.addSeparator();
		nm = new JMenuItem("Translated Example");
		nm.addActionListener(myListener);
		fileMenu3.add(nm);

		// Add Tutorial menu and item/button:
		fileMenu5 = menuBar.add(new JMenu("AMAL Tutorial"));
		fileMenu5.setMnemonic('T');

		// Add the tutorials here:
		nm = new JMenuItem("SimpleMove.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);
		fileMenu5.addActionListener(myListener);

		nm = new JMenuItem("SimpleLoop.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("SimpleFor.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("SimpleLoopedMove.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("SimpleLoopedFor.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("SimpleAnimation.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("Rotate.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("Mouse.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("MouseAutotest.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("SimpleGameControl.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm); 

		nm = new JMenuItem("GameControl.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		nm = new JMenuItem("AI.jamal");
		nm.addActionListener(myListener);
		fileMenu5.add(nm);

		// Moved/removed:
		//nm = new JMenuItem("New.jamos");
		//nm.addActionListener(myListener);
		//fileMenu5.add(nm);

		// Finally if not an applet:
		if (!isApplet())
		{
			// Add Viewer menu and item/button:
			fileMenu7 = menuBar.add(new JMenu("AbkViewer"));
			fileMenu7.setMnemonic('T');
			nm = new JMenuItem("AbkViewer (x1)");
			nm.addActionListener(myListener);
			fileMenu7.add(nm);
			nm = new JMenuItem("AbkViewer (x2)");
			nm.addActionListener(myListener);
			fileMenu7.add(nm);

			//Add the File menu at the end (unorthodox!)
			fileMenu6 = menuBar.add(new JMenu("File"));
			fileMenu6.setMnemonic('F');

			nm = new JMenuItem("Open ASCII jAMOS file");
			nm.addActionListener(myListener);
			fileMenu6.add(nm);
			fileMenu6.addActionListener(myListener);

			nm = new JMenuItem("Save ASCII jAMOS file");
			nm.addActionListener(myListener);
			fileMenu6.add(nm);

			fileMenu6.addSeparator();

			nm = new JMenuItem("Export as a Java file");
			nm.addActionListener(myListener);
			fileMenu6.add(nm);

			// Removed - need to be able to create JAR file first from entire directory structure.
			//fileMenu6.addSeparator();
			//nm = new JMenuItem("Export as a runnable JAR file");
			//nm.addActionListener(myListener);
			//fileMenu6.add(nm);
		}


		/*for (int c = 1; c <= numprograms; c++)
        {
        	JMenuItem nm = new JMenuItem("" + c);
        	nm.addActionListener(myListener);
        	fileMenu3.add(nm);
        }*/

		//scrollPane = new JTextPane(); // Creates an empty text pane

		// Changed for jAMOS:
		_editArea.setText(amosCode);
		//if (AMALCode != null)
		//	_editArea.setText(AMALCode[1]); // Sets its text

		_editArea.setCaretPosition(0); // move to top
		//_editArea.getCaretPosition();
		//scrollPane.setMargin(new Insets(5,5,5,5));


		//scrollPane = new JScrollPane(textPane);
		scrollPane.setPreferredSize(new Dimension(800, 600)); //(640, 256));


		/*Frame[] frames = Frame.getFrames();
        Dialog dialog = new Dialog( frames[0] );
        dialog.add(textPane);
        dialog.pack();
        dialog.setVisible(true);*/

		frame = new JFrame(""); // makes a window to put it in
		// Set up the menu bar.
		//actions = createActionTable(textPane);

		//JMenuBar mb = new JMenuBar();
		//mb.add(editMenu);
		//frame.setJMenuBar(mb);

		//... Set window content and menu.
		frame.setContentPane(content);
		frame.setJMenuBar(menuBar);

		//... Set other window characteristics.
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		if (!isApplet())
			title="jAMOS alpha 0.24 \u00a9 2012 Mequa Innovations";
		else
			title="jAMOS alpha 0.24 applet demo version \u00a9 2012 Mequa Innovations";
		frame.setTitle(title);
		//frame.getContentPane().setSize(800, 600);
		frame.setPreferredSize(new Dimension(800, 600)); //(700, 400));
		//canvas.setTitle("");

		//frame.getContentPane().add(_editArea, BorderLayout.CENTER); // adds the text pane to the window
		frame.pack(); // adjusts the window to the right size
		frame.setLocationRelativeTo(null);
		frame.setVisible(true); // makes it show up

		defineAudioClip("jAMAL.wav", "resources/jAMAL.wav");
		//playAudio("jAMAL.wav");

		// Added - load and play the jAMOS sample:
		// TODO - find better sample!
		defineAudioClip("jAMOS.wav", "resources/jAMOS.wav");
		playAudio("jAMOS.wav");
	}
	
	class MyListener implements ActionListener
	{
		public MyListener()
		{
			//AbstractButton menuItem = null;
			//menuItem.addActionListener(this);
		}
		public void actionPerformed(ActionEvent e)
		{
			//...Get information from the action event...
			//...Display it in the text area...

			//System.out.println("Selected Program " + e.getActionCommand());

			// Save the old text:
			if (!viewingtranslatedcode)
			{
				if (AMALCode != null)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				// Save the caret position:
				caretposition[editingchannel] = _editArea.getCaretPosition();
			}

			// First check if it wants to translate the text:
			if ((e.getActionCommand()).equals("Translate to Java") && !AM.runningcompiled)
			{
				translatetoviewnow = true; translatetocpp = false;
			}
			else if ((e.getActionCommand()).equals("Translate to C++") && !AM.runningcompiled)
			{
				translatetoviewnow = true; translatetocpp = true;
			}
			// First check if it wants to translate the text:
			else if ((e.getActionCommand()).equals("Export as a Java file") && !AM.runningcompiled)
			{
				translatetosavenow = true; translatetocpp = false;
			}
			// First check if it wants to export to JAR:
			else if ((e.getActionCommand()).equals("Export as a runnable JAR file") && !AM.runningcompiled)
			{
				outputtojarnow = true;
			}
			// Check if it wants to run the compiled example:
			else if ((e.getActionCommand()).equals("Translated Example"))
			{
				//System.out.println("Number of compiled programs: "+AM.translatedamalprograms.numPrograms());

				// This will execute all channels of the compiled program. Put it in the appropriate thread!!!
				//for (int a=0; a<1; a++)
				//for (int channel=1; channel <= AM.translatedamalprograms.numPrograms(); channel++ )
				//	AM.translatedamalprograms.runAmal(channel, channel);

				// Here we need to initialise the compiled programs on the appropriate thread:
				runcompiledexamplenow = true;
				editingenvironment = false;
				editingamos = false;
			}
			// Added: Edit AMOS code:
			else if ((e.getActionCommand()).equals("jAMOS Program") && !AM.runningcompiled)
			{
				editingamos = true;
				editingenvironment = false;
				viewingtranslatedcode = false;
				fileMenu2.setText("jAMOS Program");

				// Now flip the text:
				_editArea.setText(amosCode);
				_editArea.setCaretPosition(0); // move to top
			}
			// Added: Edit environment string:
			else if ((e.getActionCommand()).equals("AMAL Environment") && !AM.runningcompiled)
			{
				editingamos = false;
				editingenvironment = true;
				viewingtranslatedcode = false;
				fileMenu2.setText("AMAL Environment Editor");

				// Now flip the text:
				_editArea.setText(environmentCode);
				_editArea.setCaretPosition(0); // move to top
			}
			// Added: Create a new channel:
			else if ((e.getActionCommand()).equals("New Channel") && !AM.runningcompiled )
			{
				// Create a new program / channel:
				numprograms++;
				AMALCode[numprograms] = "new amal program and channel\n";

				// Now update the menu (TO DO - add to method to avoid copy/paste):

				// Remove the old channel menu:
				fileMenu2.removeAll();

				fileMenu2.setText("AMAL Program " + 1);

				// Added: AMOS window:
				JMenuItem nm = new JMenuItem("jAMOS Program");
				nm.addActionListener(myListener);
				fileMenu2.add(nm);

				fileMenu2.addSeparator();

				// Added: Environment window:
				nm = new JMenuItem("AMAL Environment");
				nm.addActionListener(myListener);
				fileMenu2.add(nm);

				// Create the new channel menu here:
				for (int c = 1; c <= numprograms; c++)
				{
					nm = new JMenuItem("AMAL " + c);
					nm.addActionListener(myListener);
					fileMenu2.add(nm);
				}

				fileMenu2.addSeparator();

				nm = new JMenuItem("New Channel");
				nm.addActionListener(myListener);
				fileMenu2.add(nm);

				fileMenu2.addSeparator();

				nm = new JMenuItem("Show All Programs");
				nm.addActionListener(myListener);
				fileMenu2.add(nm);
			}
			// Check if it wants to view all channels:
			else if ((e.getActionCommand()).equals("Show All Programs") && !AM.runningcompiled)
			{
				// Show all channels here.

				// Save the text if appropriate:
				if (!viewingtranslatedcode)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				editingamos = false;
				viewingtranslatedcode = true;
				editingenvironment = false;
				fileMenu2.setText("Viewing All");

				// Grab the total contents of all the programs:
				String allprogs = "";

				// Added for jAMOS - add the main jAMOS program:
				allprogs += amosCode + "\n\n";

				// Added - add the environment string:
				allprogs += "AMAL Environment\n" + environmentCode + "\n\n";

				for (int channel=1; channel<=numprograms; channel++)
				{
					allprogs += "AMAL Channel " + channel + "\n";
					allprogs += AMALCode[channel] + "\n";

					// Separate the programs with an extra endline:
					if (channel < numprograms)
						allprogs += "\n";
				}

				// Now flip the text:
				_editArea.setText(allprogs);
				_editArea.setCaretPosition(0); // move to top

			}
			// Now check if it wants to strip all programs and display:
			else if ((e.getActionCommand()).equals("Strip all and display") && !AM.runningcompiled)
			{
				playAudio("stripped");

				// Save the text if appropriate:
				if (!viewingtranslatedcode)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				editingamos = false;
				viewingtranslatedcode = true;
				editingenvironment = false;
				fileMenu2.setText("Viewing all stripped");

				// Grab the total contents of all the programs:
				String allprogs = "";
				for (int channel=1; channel<=numprograms; channel++)
				{
					allprogs += "AMAL Channel " + channel + "\n";

					// Now we strip each program in turn, as for below:

					// Grab the stripped text here:
					AM._input = AMALCode[channel];
					AM.CHAN = channel;
					AM.amallexer.REMOVE_UNUSED();
					String content = AM.tokest;

					allprogs += content;
					allprogs += "\n";

					// Separate the programs with an extra endline:
					if (channel < numprograms)
						allprogs += "\n";
				}

				// Now flip the text:
				_editArea.setText(allprogs);
				_editArea.setCaretPosition(0); // move to top
			}
			// Now check if it wants to strip the current program and display:
			else if ((e.getActionCommand()).equals("Strip current and display") && !AM.runningcompiled)
			{
				playAudio("stripped");

				// Save the text if appropriate:
				if (!viewingtranslatedcode)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				fileMenu2.setText("Viewing Stripped "+editingchannel);
				editingamos = false;
				viewingtranslatedcode = true;
				editingenvironment = false;

				//ByteArrayOutputStream baos = new ByteArrayOutputStream();
				//PrintStream ps = new PrintStream(baos);

				// Grab the stripped text here:
				AM._input = AMALCode[editingchannel];
				AM.CHAN = editingchannel;
				AM.amallexer.REMOVE_UNUSED();
				String content = AM.tokest;

				//String content = baos.toString(); //(charsetName); // e.g. ISO-8859-1

				// Now flip the text:
				_editArea.setText(content);
				_editArea.setCaretPosition(0); // move to top
			}
			else if ((e.getActionCommand()).equals("Strip current and update") && !AM.runningcompiled)
			{
				playAudio("stripped");

				// Save the text if appropriate:
				if (!viewingtranslatedcode)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				fileMenu2.setText("AMAL Program "+editingchannel);
				editingamos = false;
				viewingtranslatedcode = false;
				editingenvironment = false;

				// Grab the stripped text here:
				AM._input = AMALCode[editingchannel];
				AM.CHAN = editingchannel;
				AM.amallexer.REMOVE_UNUSED();

				// Copy the stripped text to the appropriate program number:
				AMALCode[editingchannel] = AM.tokest;

				//String content = baos.toString(); //(charsetName); // e.g. ISO-8859-1

				// Now flip the text:
				_editArea.setText(AM.tokest);
				_editArea.setCaretPosition(0); // move to top
			}
			// Foolhardy option - strip all of your AMAL programs and update:
			else if ((e.getActionCommand()).equals("Strip all and update") && !AM.runningcompiled)
			{
				playAudio("stripped");

				// Save the text if appropriate:
				if (!viewingtranslatedcode)
				{
					if (editingamos)
						amosCode = _editArea.getText();
					else if (!editingenvironment)
						AMALCode[editingchannel] = _editArea.getText();
					else
						environmentCode = _editArea.getText();
				}

				fileMenu2.setText("AMAL Program "+editingchannel);
				editingamos = false;
				viewingtranslatedcode = false;
				editingenvironment = false;

				// Grab the stripped text here for each channel:
				// Grab the total contents of all the programs:
				for (int channel=1; channel<=numprograms; channel++)
				{
					// Now we strip each program in turn:

					// Grab the stripped text here:
					AM._input = AMALCode[channel];
					AM.CHAN = channel;
					AM.amallexer.REMOVE_UNUSED();

					// Update the code for each channel:
					AMALCode[channel] = AM.tokest;
				}

				// Now update the editor window as appropriate:
				_editArea.setText(AMALCode[editingchannel]);
				_editArea.setCaretPosition(0); // move to top
			}
			// Quit the program if selected.
			else if ((e.getActionCommand()).equals("Exit"))
			{
				// Close everything here.
				System.exit(0);
			}
			// Run the greeting sample if selected
			else if ((e.getActionCommand()).equals("About jAMOS"))
			{
				playAudio("jAMOS.wav"); //playAudio("jAMAL.wav");
			}
			// Run the greeting sample if selected
			else if ((e.getActionCommand()).equals("About jAMAL"))
			{
				playAudio("jAMAL.wav"); //playAudio("jAMAL.wav");
			}
			// Quit the program if selected.
			else if ((e.getActionCommand()).equals("New Project"))
			{
				// Open the blank AMAL resource
				loadexamplefilename = "New.jamos";

				//System.out.println("Trying to load blank");

				// Now we signal for this to be called on another thread:
				loadexamplenow = true;
			}
			else if ((e.getActionCommand()).equals("Open ASCII jAMOS file"))
			{
				// Use an OS-native file requester:
				FileDialog fd = new FileDialog(new Frame(), "Load a .jamos, .jamal or .txt file", FileDialog.LOAD);

				// Save and set default name
				// TO DO - may need to move to another thread:
				fd.setFile("MyPrograms.jamos");
				fd.setDirectory(".\\");
				fd.setLocation(50, 50);
				fd.setVisible(true); //fd.show(); // fix this!
				loadexamplefilename = fd.getFile();

				// Now we signal for this to be called on another thread:
				loadfilenow = true;
			}
			else if ((e.getActionCommand()).equals("Save ASCII jAMOS file") && !AM.runningcompiled)
			{
				// Use an OS-native file requester:
				FileDialog fd = new FileDialog(new Frame(), "Save a .jamos, .jamal or .txt file", FileDialog.LOAD);
				fd.setFile("*.jamos;*.txt");
				fd.setDirectory(".\\");
				fd.setLocation(50, 50);
				fd.setVisible(true); //fd.show(); // fix this!
				loadexamplefilename = fd.getFile();

				// Now we signal for this to be called on another thread:
				savefilenow = true;
			}
			// Added - dummy placeholder for selecting translated program number (removed as buggy):
			//else if (AM.Left((e.getActionCommand()), 11).equals("Translated "))
			//{
			//System.out.println("Attempting to select "+e.getActionCommand()+"!");
			//}
			// Now check if it wants to load an example:
			else if ((AM.right((e.getActionCommand()), 6).equals(".jamos"))
					|| (AM.right((e.getActionCommand()), 6).equals(".jamal")))
			{	    		
				// Now we signal for this to be called on another thread:
				loadexamplefilename = e.getActionCommand();
				loadexamplenow = true;
			}
			else if (e.getActionCommand().equals("AbkViewer (x1)"))
			{
				// Launch the sprite bank viewer here:
				AbkViewer viewer = new AbkViewer(1);
				viewer.init();
				viewer.createframe();
			}
			else if (e.getActionCommand().equals("AbkViewer (x2)"))
			{
				// Launch the sprite bank viewer here:
				AbkViewer viewer = new AbkViewer(2);
				viewer.init();
				viewer.createframe();
			}
			else if (!AM.runningcompiled)
			{
				// For choosing a channel number
				//System.out.println(AM.Right((e.getActionCommand()), 5));
				viewingtranslatedcode = false;
				editingenvironment = false;
				editingamos = false;

				// Need to test if it's an integer here.
				int newchannel = Integer.parseInt(e.getActionCommand().substring(5)); // added

				// Now flip the text:
				_editArea.setText(AMALCode[newchannel]);
				editingchannel = newchannel;

				fileMenu2.setText("AMAL Program " + editingchannel);

				_editArea.setCaretPosition(caretposition[newchannel]); // move to saved position
				//_editArea.setCaretPosition(0); // move to top
			}
		}

		public void itemStateChanged(ItemEvent e)
		{
			//...Get information from the item event...
			//...Display it in the text area...
			//System.out.println("Item state changed!");
		}
	}



	//////////////////////////////////////////////////inner class OpenAction
	class RunAction extends AbstractAction
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 2818854519468437763L;

		//============================================= constructor
		public RunAction()
		{
			super("Restart");
			putValue(MNEMONIC_KEY, new Integer('R'));
		}

		//========================================= actionPerformed
		public void actionPerformed(ActionEvent e)
		{
			// Added:
			editorpaused = false;

			// Removed test - restart does not function as unpause:
			//if (editorpaused)
			//unpauseamal();
			//else
			launchprogramnow = true; //runamal();
		}
	}
	class RunAction2 extends AbstractAction
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 2818854519468437763L;

		//============================================= constructor
		public RunAction2()
		{
			super("Run");
			putValue(MNEMONIC_KEY, new Integer('R'));
		}

		//========================================= actionPerformed
		public void actionPerformed(ActionEvent e)
		{
			if (editorpaused)
				unpauseamal();
			else
				launchprogramnow = true; //runamal();
		}
	}


	//////////////////////////////////////////////////inner class OpenAction
	class PauseAction extends AbstractAction {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2818854519468437763L;

		//============================================= constructor
		public PauseAction() {
			super("Freeze");
			putValue(MNEMONIC_KEY, new Integer('P'));
		}

		//========================================= actionPerformed
		public void actionPerformed(ActionEvent e)
		{
			editorpaused = !editorpaused;
			if (editorpaused)
			{
				//_pauseAction.setText("");
				for (int pp = 1; pp <= numprograms; pp++)
					AM.amalFreeze(pp);
				//AM.AmalFreeze(); // broken here?
			}
			else
			{
				//_pauseAction.setText("");
				for (int pp = 1; pp <= numprograms; pp++)
					AM.amalOn(pp);
				//AM.AmalOn(); // broken here
			}
		}
	}

	// Create the edit menu.
	protected JMenu createEditMenu()
	{
		JMenu menu = new JMenu("Edit");

		//Undo and redo are actions of our own creation.
		undoAction = new UndoAction();
		menu.add(undoAction);

		redoAction = new RedoAction();
		menu.add(redoAction);

		menu.addSeparator();

		//These actions come from the default editor kit.
		//Get the ones we want and stick them in the menu.
		menu.add(getActionByName(DefaultEditorKit.cutAction));
		menu.add(getActionByName(DefaultEditorKit.copyAction));
		menu.add(getActionByName(DefaultEditorKit.pasteAction));

		menu.addSeparator();

		menu.add(getActionByName(DefaultEditorKit.selectAllAction));
		return menu;
	}
	private Action getActionByName(String name)
	{
		return actions.get(name);
	}
	class UndoAction extends AbstractAction
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 7867474900019362251L;

		public UndoAction()
		{
			super("Undo");
			setEnabled(false);
		}

		public void actionPerformed(ActionEvent e)
		{
			try
			{
				undo.undo();
			}
			catch (CannotUndoException ex)
			{
				System.out.println("Unable to undo: " + ex);
				ex.printStackTrace();
			}
			updateUndoState();
			redoAction.updateRedoState();
		}

		protected void updateUndoState()
		{
			if (undo.canUndo())
			{
				setEnabled(true);
				putValue(Action.NAME, undo.getUndoPresentationName());
			}
			else
			{
				setEnabled(false);
				putValue(Action.NAME, "Undo");
			}
		}
	}

	class RedoAction extends AbstractAction
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = -7852776177427780883L;

		public RedoAction()
		{
			super("Redo");
			setEnabled(false);
		}

		public void actionPerformed(ActionEvent e)
		{
			try
			{
				undo.redo();
			}
			catch (CannotRedoException ex)
			{
				System.out.println("Unable to redo: " + ex);
				ex.printStackTrace();
			}
			updateRedoState();
			undoAction.updateUndoState();
		}

		protected void updateRedoState()
		{
			if (undo.canRedo())
			{
				setEnabled(true);
				putValue(Action.NAME, undo.getRedoPresentationName());
			}
			else
			{
				setEnabled(false);
				putValue(Action.NAME, "Redo");
			}
		}
	}


	// TO DO - Output to a RUNNABLE .jar file:
	// Based on sample code from http://java.sun.com/developer/technicalArticles/Programming/compression/
	void outputtojar()
	{
		final int BUFFER = 4096;
		// Currently this assumes running from jAMAL.jar - improve.
		String inputjar = "jAMAL.jar"; // ../
		try
		{
			//inputjar = (new File
			//  (JAMAL.class.getProtectionDomain()
			//  .getCodeSource().getLocation().toURI())).toString();
		}
		catch (Exception e)
		{
		}


		// Part 1: Extract the JAR/ZIP file:
		try
		{
			// First create the output directories here (improve this):
			boolean success = (new File("temp")).mkdir();
			success |= (new File("temp/META-INF")).mkdir();
			success |= (new File("temp/jamal")).mkdir();
			success |= (new File("temp/jgame")).mkdir();
			success |= (new File("temp/example/jamos")).mkdir();
			success |= (new File("temp/example/resources")).mkdir();
			success |= (new File("temp/example/resources/sprites")).mkdir();
			success |= (new File("temp/jgame/platform")).mkdir();
			success |= (new File("temp/jgame/impl")).mkdir();

			BufferedOutputStream dest = null;
			FileInputStream fis = new FileInputStream(inputjar);
			ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
			ZipEntry entry;
			while(((entry = zis.getNextEntry()) != null) && success)
			{
				int count;
				System.out.println("Extracting: \""+entry+"\"");

				try
				{
					// Exclude the AmalPrograms.class from extraction:
					if (!(entry.toString().equals("example/")) &&
							!(entry.toString().equals("example/AmalPrograms.class")) &&
							!(((entry.toString()).toLowerCase()).contains(".jamos")) &&
							!(((entry.toString()).toLowerCase()).contains(".jamal")))
					{
						byte data[] = new byte[BUFFER];
						// Write the files to the disk (path goes here):
						// Added - replace default AmalPrograms.class
						FileOutputStream fos = null;
						// Use the mini class instead:
						if (entry.toString().equals("example/resources/miniAmalPrograms"))
							fos = new FileOutputStream("temp/example/AmalPrograms.class");
						else if (entry.toString().equals("example/resources/miniAMALCompiler"))
							;//fos = new FileOutputStream("temp/example/AMALCompiler.class");
						else if (entry.toString().equals("example/AmalPrograms.class"))
							; // remove precompiled example
						else if (entry.toString().equals("example/resources/jAMOS.jpg")) // jAMAL.jpg
							; // remove editor splash screen
						//else if (entry.toString().equals("example/AMALCompiler.class"))
						//	;
						else
							fos = new FileOutputStream("temp/"+entry.getName());

						if (fos != null)
						{
							dest = new BufferedOutputStream(fos, BUFFER);
							while ((count = zis.read(data, 0, BUFFER)) != -1)
							{
								dest.write(data, 0, count);
							}
							dest.flush();
							dest.close();
						}
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			zis.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		// Step 2 - save current project as "temp/example/amos/RunOnly.jamos"
		// and replace any files:
		savejamosfile("temp/example/amos/RunOnly.jamos");

		// Step 3 - archive the entire temp folder and save with .JAR extension
		// Code borrowed from:
		// http://www.java-examples.com/create-zip-file-directory-using-zipoutputstream-example
		try
		{
			String zipFile = "YourGame.jar";
			String sourceDirectory = "./temp";

			//create byte buffer
			byte[] buffer = new byte[1024];
			/*
			 * To create a zip file, use
			 * 
			 * ZipOutputStream(OutputStream out)
			 * constructor of ZipOutputStream class.
			 *  
			 */

			//create object of FileOutputStream
			FileOutputStream fout = new FileOutputStream(zipFile);

			//create object of ZipOutputStream from FileOutputStream
			ZipOutputStream zout = new ZipOutputStream(fout);

			//create File object from directory name
			File dir = new File(sourceDirectory);

			//check to see if this directory exists
			if(!dir.isDirectory())
			{
				System.out.println(sourceDirectory + " is not a directory");
			}
			else
			{
				File[] files = dir.listFiles();

				for(int i=0; i < files.length ; i++)
				{
					System.out.println("Adding " + files[i].getName());

					//create object of FileInputStream for source file
					FileInputStream fin = new FileInputStream(files[i]);

					/*
					 * To begin writing ZipEntry in the zip file, use
					 * 
					 * void putNextEntry(ZipEntry entry)
					 * method of ZipOutputStream class.
					 * 
					 * This method begins writing a new Zip entry to 
					 * the zip file and positions the stream to the start 
					 * of the entry data.
					 */

					zout.putNextEntry(new ZipEntry(files[i].getName()));

					/*
					 * After creating entry in the zip file, actually 
					 * write the file.
					 */
					int length;

					while((length = fin.read(buffer)) > 0)
					{
						zout.write(buffer, 0, length);
					}

					/*
					 * After writing the file to ZipOutputStream, use
					 * 
					 * void closeEntry() method of ZipOutputStream class to 
					 * close the current entry and position the stream to 
					 * write the next entry.
					 */

					zout.closeEntry();

					//close the InputStream
					fin.close();
				}
			}

			//close the ZipOutputStream
			zout.close();

			System.out.println("Zip file has been created!");

		}
		catch(IOException ioe)
		{
			System.out.println("IOException :" + ioe);
		}

		// Step 4 - delete the entire temp folder
		//deleteDirectory(new File("temp"));
	}

	// Used above:
	// Recursively delete a directory
	// From: http://www.rgagnon.com/javadetails/java-0483.html
	static public boolean deleteDirectory(File path)
	{
		if(path.exists())
		{
			File[] files = path.listFiles();
			for(int i=0; i<files.length; i++)
			{
				if(files[i].isDirectory())
				{
					deleteDirectory(files[i]);
				}
				else
				{
					files[i].delete();
				}
			}
		}
		return(path.delete());
	}

	// This will export a .java file to disk:
	public void savejavafile(String filename)
	{
		System.out.println("Debug: Attempting to save Java file "+filename);
		try
		{
			FileOutputStream fos = new FileOutputStream(filename);
			BufferedWriter w =  new BufferedWriter(new OutputStreamWriter(fos));

			// Now write the Java class to the ASCII file:
			w.write(javacode);
			w.flush();
			w.close();
			System.out.println("Java file successfully saved!");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// This will save a .jamos or .jamal file to disk:
	public void savejamosfile(String filename)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream(filename);
			BufferedWriter w =  new BufferedWriter(new OutputStreamWriter(fos));

			// Added for jAMOS - add the jAMOS main program here:
			w.write(amosCode);
			w.newLine(); w.newLine();

			// Added - add the environment string:
			w.write("AMAL Environment\n" + environmentCode);
			w.newLine(); w.newLine();

			// Now write the AMAL programs to the file:
			for (int channel=1; channel<=numprograms; channel++)
			{
				w.write("AMAL Channel "+channel);
				w.newLine();

				// Need to parse each line of AMALCode[channel]
				// to add a system newline.
				String lines[] = AMALCode[channel].split("\\r?\\n");
				//w.write(AMALCode[channel]);
				for (int line=0; line<lines.length; line++)
				{
					//System.out.println("Writing new line!");
					w.write(lines[line]);
					w.newLine();
				}

				// Add a separating line between programs for clarity:
				if (channel < numprograms)
					w.newLine();
			}

			// TODO - cludge for alpha 0.1 - add an empty AMAL channel:
			if (numprograms == 0)
			{
				w.write("AMAL Channel 0");
				w.newLine();
			}

			w.flush();
			w.close();
			System.out.println("Successfully saved!");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
