package jamos.jamal;

import jamos.AMOS_System;

import java.util.Vector;

public class AMALEnvGen
{
	public AMOS_System AM;
	public static String[] command = {"screen open", "screen display", "screen offset", "screen close",
		"screen clone", "screen", "double buffer", "dual playfield", "dual priority", "load iff", "load",
		"erase", "hide on", "update every", "flash off", "flash", "set rainbow", "rainbow del", "rainbow",
		"bob off", "bob", "set bob", "sprite off", "sprite", "set sprite buffer", "set reg", "unpack",
		"channel to sprite", "channel to bob", "channel to screen offset", "channel to screen size",
		"channel to rainbow", "if screen", "if not screen", "if bank", "if not bank", "if reg", "channel to screen display", "bell"};

	public static String[] javaCommand = {"AM.screenOpen", "AM.screenDisplay", "AM.screenOffset",
		"AM.screenClose", "AM.screenClone", "AM.screen", "AM.doubleBuffer", "AM.dualPlayfield",
		"AM.dualPriority", "AM.loadIff", "AM.load", "AM.erase", "AM.hideOn", "AM.updateEvery", "AM.flashOff",
		"AM.flash", "AM.setRainbow", "AM.rainbowDel", "AM.rainbow", "AM.bobOff", "AM.bob", "AM.setBob",
		"AM.spriteOff", "AM.sprite", "AM.setSpriteBuffer", "AM.setReg", "AM.unpack", "AM.channelToSprite",
		"AM.channelToBob", "AM.channelToScreenOffset", "AM.channelToScreenSize", "AM.channelToRainbow",
		"AM.isScreen", "AM.isNotScreen", "AM.isBank", "AM.isNotBank", "AM.isReg", "AM.channelToScreenDisplay", "AM.bell"};

	public static String[] cppCommand = {"AM->screenOpen", "AM->screenDisplay", "AM->screenOffset",
		"AM->screenClose", "AM->screenClone", "AM->screen", "AM->doubleBuffer", "AM->dualPlayfield",
		"AM->dualPriority", "AM->loadIff", "AM->load", "AM->erase", "AM->hideOn", "AM->updateEvery", "AM->flashOff",
		"AM->flash", "AM->setRainbow", "AM->rainbowDel", "AM->rainbow", "AM->bobOff", "AM->bob", "AM->setBob",
		"AM->spriteOff", "AM->sprite", "AM->setSpriteBuffer", "AM->setReg", "AM->unpack", "AM->channelToSprite",
		"AM->channelToBob", "AM->channelToScreenOffset", "AM->channelToScreenSize", "AM->channelToRainbow",
		"AM->isScreen", "AM->isNotScreen", "AM->isBank", "AM->isNotBank", "AM->isReg", "AM->channelToScreenDisplay", "AM->bell"};

	// Define the envScript vector:
	public static Vector<Vector<Object>> envScript = new Vector<Vector<Object>>();

	// Constructor function:
	public AMALEnvGen(AMOS_System AMi)
	{
		AM = AMi;
	}
	public static int checkcommand(String inputline)
	{
		for (int c=0; c<command.length; c++)
			if (inputline.length() >= command[c].length())
				if ((inputline.substring(0, command[c].length()).toLowerCase()).equals(command[c]))
					return c;
		return -1;
	}
	public static Object parsearg(String input)
	{
		//System.out.println("Debug: Running =parsearg("+input+")");
		int intarg = 0;
		String stringarg = "";
		if (input.equals(""))
			return 0;

		try	{
			intarg = Integer.parseInt(input);
			return intarg;
		} catch(Exception e) {
			if ((input.charAt(0) == '\"') && (input.charAt(input.length()-1) == '\"') && input.length()>=2)
			{
				stringarg = input.substring(1, input.length() - 1); //  was -2
				return stringarg;
			}
			else if (input.toLowerCase().equals("lowres"))
				return 0;
			else if (input.toLowerCase().equals("hires"))
				return 0x8000;
			else if (input.toLowerCase().equals("laced"))
				return 4;
			else if (input.toLowerCase().equals("hires+laced"))
				return 0x8004;
			else if (input.toLowerCase().equals("laced+hires"))
				return 0x8004;
		}
		return -1;
	}
	public static void processline(String input)
	{
		// Note: Empty lines are already tested for earlier.

		// Strip any spaces or tabs:
		while (input.substring(0, 1).equals(" ")) // || input.substring(0, 1).equals(""))
			input = input.substring(1);

		// Ignore comments (TO DO - convert to save to Java)		
		if (input.substring(0, 1).equals("'") || input.substring(0, 3).toLowerCase().equals("rem"))
			return;

		int commandnum = checkcommand(input);
		//System.out.println("checkcommand result: "+commandnum+" - "+command[commandnum]);

		String lineargs = "";
		if (commandnum >= 0)
			lineargs = input.substring(command[commandnum].length());

		// Strip any spaces or tabs:
		if (lineargs.length() > 0)
			while ((lineargs.length() > 0) && (lineargs.substring(0, 1).equals(" "))) // || lineargs.substring(0, 1).equals(""))
				lineargs = lineargs.substring(1);

		//if (lineargs.length() > 0)
		//	System.out.println("arguments line: "+lineargs);

		// Split them up by comma, maximum 10:
		String linearg[] = new String[10];
		int numargs = 0;

		// Check number of commas
		String argchop = lineargs;
		int comma;
		comma = argchop.indexOf(',');
		while (comma >= 0)
		{
			linearg[numargs] = argchop.substring(0, comma);
			argchop = argchop.substring(comma + 1);
			//System.out.println("Debug: argchop = "+argchop);
			numargs++;
			comma = argchop.indexOf(',');
		}
		linearg[numargs] = argchop;
		numargs++;

		if (lineargs.equals(""))
		{
			numargs = 0;
		}
		else
		{
			// Strip any initial spaces off arguments here:
			for (int a=0; a < numargs; a++)
				if (linearg[a].length() > 0)
					while (linearg[a].charAt(0) == ' ')
						linearg[a]=linearg[a].substring(1);

			// Strip any trailing spaces:
			for (int a=0; a < numargs; a++)
				if (linearg[a].length() > 0)
					while (linearg[a].charAt(linearg[a].length() - 1) == ' ')
						linearg[a]=linearg[a].substring(0, linearg[a].length() - 1);
		}

		// Create the new vector for the line:
		Vector<Object> newline = new Vector<Object>();
		newline.add(commandnum);

		// Check and convert argument types here:
		for (int c=0; c<numargs; c++)
			newline.add(parsearg(linearg[c]));

		// Insert the new line into the envScript vector:
		envScript.add(newline);
	}
	public void processcode(String input)
	{
		// TO DO: Need to remove comments intelligently first to allow for : in comment...

		String input2 = input.replaceAll(":", "\n");
		String[] lines = input2.split("\\r?\\n");
		envScript.clear();

		for (int a=0; a<lines.length; a++)
		{
			if(!(lines[a].equals("")))
				processline(lines[a]);
		}
	}
	public static void dump()
	{
		Vector<Object> newline;

		for (int a=0; a<envScript.size(); a++)
		{
			// Type safety needs fixing!
			newline = ((Vector<Object>)(envScript.get(a)));

			System.out.println("checkcommand result: "+newline.get(0)+" - "+command[(Integer)newline.get(0)]);
			if (newline.size() > 1)
				System.out.println("Number of arguments: "+(newline.size() - 1));
			for (int c=1; c<=(newline.size() - 1); c++)
				System.out.println("Argument #"+c+": *"+newline.get(c)+"*");
		}
	}

	public String outputCPP()
	{
		String output = "void environment()\n{\n";
		Vector<Object> line;

		for (int a=0; a<envScript.size(); a++)
		{
			// Type safety fixed here:
			line = (Vector<Object>)envScript.get(a);

			// Exclude special cases: 37 = channelToScreenDisplay, 38=Bell (added):
			if (((Integer)line.get(0) >= 32) && ((Integer)line.get(0) != 37) && ((Integer)line.get(0) != 38))
				output += "	if (";
			else
				output += "	";

			output += cppCommand[(Integer)line.get(0)] + "(";

			// To do - support string output below:
			for (int c=1; c <=(line.size() - 1); c++)
			{
				// If using Load Iff or Load, allow strings:
				if (((((Integer)line.get(0) == 9)
						|| ((Integer)line.get(0) == 10))
						&& (c == 1))
						// For Set Rainbow strings:
						|| (((Integer)line.get(0) == 16 )
								&& ((c == 4) || (c == 5) || (c == 6))) )
					output += "\"" + line.get(c) + "\"";
				else
					output += line.get(c);

				if ( c <= (line.size() - 2))
					output += ", ";
			}

			// Exclude special case: 37 = channelToScreenDisplay:
			if (((Integer)line.get(0) >= 32) && ((Integer)line.get(0) < 37))
				output += "))\n	";
			else
				output += ");\n";
		}

		output += "}\n";
		return output;
	}

	public String outputJava()
	{
		String output = "	public void environment()\n	{\n";
		Vector<Object> line;

		for (int a=0; a<envScript.size(); a++)
		{
			// Type safety fixed here:
			line = (Vector<Object>)envScript.get(a);

			// Exclude special cases: 37 = channelToScreenDisplay, 38=Bell (added):
			if (((Integer)line.get(0) >= 32) && ((Integer)line.get(0) != 37) && ((Integer)line.get(0) != 38))
				output += "		if (";
			else
				output += "		";

			output += javaCommand[(Integer)line.get(0)] + "(";

			// To do - support string output below:
			for (int c=1; c <=(line.size() - 1); c++)
			{
				// If using Load Iff or Load, allow strings:
				if (((((Integer)line.get(0) == 9)
						|| ((Integer)line.get(0) == 10))
						&& (c == 1))
						// For Set Rainbow strings:
						|| (((Integer)line.get(0) == 16 )
								&& ((c == 4) || (c == 5) || (c == 6))) )
					output += "\"" + line.get(c) + "\"";
				else
					output += line.get(c);

				if ( c <= (line.size() - 2))
					output += ", ";
			}

			// Exclude special case: 37 = channelToScreenDisplay:
			if (((Integer)line.get(0) >= 32) && ((Integer)line.get(0) < 37))
				output += "))\n	";
			else
				output += ");\n";
		}

		output += "	}\n";
		return output;
	}

	public int interpretEnvGen()
	{
		Vector<Object> line;
		for (int a=0; a<envScript.size(); a++)
		{
			// Type safety needs fixing here:
			line = (Vector<Object>)(envScript.get(a));

			//System.out.println("interpretEnvGen() line="+a+", command="+(Integer)line.get(0)); // debug

			// Get args for each:
			switch ((Integer)line.get(0))
			{
			case 0:
				AM.screenOpen((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(Integer)line.get(4), (Integer)line.get(5));
				break;
			case 1:
				AM.screenDisplay((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3));
				break;
			case 2:
				AM.screenOffset((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3));
				break;
			case 3:
				AM.screenClose();
				break;
			case 4:
				AM.screenClone((Integer)line.get(1));
				break;
			case 5:
				AM.screen((Integer)line.get(1));
				break;
			case 6:
				AM.doubleBuffer();
				break;
			case 7:
				AM.dualPlayfield((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 8:
				AM.dualPriority((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 9:
				AM.loadIff((String)line.get(1), (Integer)line.get(2));
				break;
			case 10:
				AM.load((String)line.get(1), (Integer)line.get(2));
				break;
			case 11:
				AM.erase((Integer)line.get(1));
				break;
			case 12:
				AM.hideOn();
				break;
			case 13:
				AM.updateEvery((Integer)line.get(1));
				break;
			case 14:
				AM.flashOff();
				break;
			case 15:
				AM.flash((Integer)line.get(1), (String)line.get(2));
				break;
			case 16:
				AM.setRainbow((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(String)line.get(1), (String)line.get(2), (String)line.get(3));
				break;
			case 17:
				AM.rainbowDel();
				break;
			case 18:
				AM.rainbow((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(Integer)line.get(4));
				break;
			case 19:
				AM.bobOff();
				break;
			case 20:
				AM.bob((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(Integer)line.get(4));
				break;
			case 21:
				AM.setBob((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(Integer)line.get(4));
				break;
			case 22:
				AM.spriteOff();
				break;
			case 23:
				AM.sprite((Integer)line.get(1), (Integer)line.get(2), (Integer)line.get(3),
						(Integer)line.get(4));
				break;
			case 24:
				AM.setSpriteBuffer((Integer)line.get(1));
				break;
			case 25:
				AM.setReg((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 26:
				AM.unpack((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 27:
				AM.channelToSprite((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 28:
				AM.channelToBob((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 29:
				AM.channelToScreenOffset((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 30:
				AM.channelToScreenSize((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 31:
				AM.channelToRainbow((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 32:
				if (AM.isScreen((Integer)line.get(1)))
					a++;
				break;
			case 33:
				if (AM.isNotScreen((Integer)line.get(1)))
					a++;
				break;
			case 34:
				if (AM.isBank((Integer)line.get(1)))
					a++;
				break;
			case 35:
				if (AM.isNotBank((Integer)line.get(1)))
					a++;
				break;
			case 36:
				if (AM.isReg((Integer)line.get(1), (Integer)line.get(1)))
					a++;
				break;
			case 37:
				AM.channelToScreenDisplay((Integer)line.get(1), (Integer)line.get(2));
				break;
			case 38:
				AM.bell();
				break;
			default:
				break;
			}
		}

		return 0;
	}
	public static void main(String args[])
	{
		//String input = "    Screen open   0 , 320  , 256   , 16   , hires         \n";
		//input += "Screen 0 : Double Buffer : Bob Off \n";
		//input += "If Reg 1, 0 : Screen 0";

		AMALEnvGen envgen = new AMALEnvGen(new AMOS_System(null));

		String input = "bob 1,100,100,1 : bob 2,100,150,1 : bob 3,100,250,1";

		// Lex the environment string:
		envgen.processcode(input);

		// Now dump the vector contents:
		//dump();
		System.out.println(envgen.outputJava());
	}	
}
