/////////////////////////////////////////////////////////////////
// jAMAL - AMOS Animation Language reimplemented in Java!      //
// (C) 2012 Mequa Innovations                                  //
/////////////////////////////////////////////////////////////////
package jamos.jamal;

//import java.util.*;
import jamos.AMOS_System;

import java.io.*;

class AMALDebugTest
{
    static AMOS_System AM;

    public static void main(String args[]) throws IOException
    {
    	//String filename = "AMAL.amal";
        String filename = "../jamos/OldDefault.jamal";
        String[] AMALCode = new String[256];
        
        AMALCode = loadfile(filename, AMALCode);
        
        AM = new AMOS_System(null);
        
        int numchannels = 0;

        // Write stripped output to file:
        FileOutputStream ffout;
        PrintStream fout;
        
        try
        {
            ffout = new FileOutputStream("AMAL_stripped.amal");
            fout = new PrintStream(ffout);
            for (int channel = 1; (channel < AMALCode.length) && !(AMALCode[channel].equals("")); channel++)
            {
                if (channel > 1)
                    fout.println("");

                fout.println("AMAL Channel " + channel);
                AM.amal(channel, AMALCode[channel]);

                // Write stripped output to file:
                fout.println(AM.tokest);
                numchannels++;
            }
            fout.close();
        }
        catch (Exception e)
        {
            System.err.println("Error: " + e.getMessage());
        }

        if (numchannels > 0)
        {
            //AM.amalcompiler.AmalCompile(System.out, 1, numchannels);
            //AM.amalcompiler.DEBUG();

            // Write to file:
            //FileOutputStream ffout;
            //PrintStream fout;
            try
            {
                ffout = new FileOutputStream("AMALout.java");
                fout = new PrintStream(ffout);
                AM.amalcompiler.AmalCompile(fout, 1, numchannels, false); // Added: false for CPP
                fout.close();
            }
            catch (Exception e)
            {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }

    public static String[] loadfile(String filename, String[] AMALCode) throws IOException
    {
        // Load the file:
        String channelCode = "";
        String line = "";
        int channel = 0;
        File dir = new File(filename);
        System.out.println("Path: " + dir);
                
        FileInputStream fis = new FileInputStream(filename);
        InputStreamReader isr = new InputStreamReader(fis);
        LineNumberReader lnr = new LineNumberReader(isr);
        while(true)
        {
            line = lnr.readLine();
            if (line == null)
                break;
            if (line.length()>13 && (line.substring(0, 13)).equals("AMAL Channel "))
            {
                AMALCode[channel] = channelCode;
                channel = Integer.parseInt(line.substring(13));
                //System.out.println(channelCode);
                //System.out.println("Channel = " + channel);
                channelCode = "";
            }
            else
            {
                channelCode += line;
                channelCode += " ";
            }
        }
        AMALCode[channel] = channelCode;
        AMALCode[channel + 1] = "";
        return AMALCode;
    }
}
