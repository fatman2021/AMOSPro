///////////////////////////////////////////////////////////
// AMOS AMAL -> Load AMAL ABK Banks
// By Stephen Harvey-Brooks - Mequa Innovations
///////////////////////////////////////////////////////////

package jamos.jamal;
import jamos.AMOS_System;

import java.io.*;

// TODO - not working yet!
// Load AMOS .abk AMAL banks files directly:
public class AMALBank
{
	public AMOS_System AM;

	// Constructor function:
	public AMALBank(AMOS_System AMi)
	{
		AM = AMi;
	}

	public int loadabk(String f) throws IOException
	{
		String file = System.getProperty("user.dir") + "\\" + f;
		char c = 1;
		int ambk = 0;
		int banknumber = 0;
		long banklength = 0;
		int flag = 0;
		String namebank = "";

		long stringsstart = 0;
		int numprogs = 0;

		FileInputStream fileinputstream = new FileInputStream(file);
		DataInputStream datainputstream = new DataInputStream(fileinputstream);

		if ((char)datainputstream.readByte() == 'A')
			if ((char)datainputstream.readByte() == 'm')
				if ((char)datainputstream.readByte() == 'B')
					if ((char)datainputstream.readByte() == 'k')
						ambk = 1;

		if (ambk == 1)
			System.out.println("AMOS bank detected!");
		else
			return -1;

		banknumber = readWord(datainputstream);
		//banknumber = (banknumber << 8) | (int)datainputstream.readUnsignedByte();
		System.out.println("banknumber = " + banknumber);

		flag = readWord(datainputstream);
		//flag = (flag * 256) + (int)datainputstream.readUnsignedByte();
		System.out.println("flag = " + flag);

		banklength = readLong(datainputstream);
		//banklength = (banklength << 8) | datainputstream.readByte();
		//banklength = (banklength << 8) | datainputstream.readByte();
		//banklength = (banklength << 8) | datainputstream.readByte();
		//banklength = banklength - 8;
		System.out.println("banklength = " + banklength);
		System.out.println("banklength = 0x" + Long.toHexString(banklength));

		namebank = "";
		for (int a=0; a<8; a++)
			namebank = namebank + (char)datainputstream.readUnsignedByte();
		System.out.println("namebank = " + namebank);

		if (namebank.equals("Amal    "))
			System.out.println("AMAL bank detected!");
		else
			return -1;

		stringsstart = readLong(datainputstream);
		//stringsstart = (stringsstart << 8) | (int)datainputstream.readByte();
		//stringsstart = (stringsstart << 8) | (int)datainputstream.readByte();
		//stringsstart = (stringsstart << 8) | (int)datainputstream.readByte();
		System.out.println("stringsstart = " + stringsstart);
		System.out.println("stringsstart = 0x" + Long.toHexString(stringsstart));

		for (long temp=0; temp<stringsstart; temp++)
			c = (char)datainputstream.readUnsignedByte();

		numprogs = readWord(datainputstream);
		System.out.println("numprogs = " + numprogs);
		System.out.println("numprogs = 0x" + Long.toHexString(numprogs));

		c = 1;
		while (c >= 0)
		{
			//int ii;
			c = (char)datainputstream.readUnsignedByte();

			if (c>31 && c<128)
			{
				if (c == '~')
					System.out.println();
				else
					System.out.print(Character.toString(c));
			}
			else
				System.out.print(" #" + ((int)0 + c + "# "));
		}
		System.out.println();

		datainputstream.close();
		fileinputstream.close();
		
		return 0+(int)c;
	}
	
	/*
	private int readByte(DataInputStream d) throws IOException
	{
		int b1 = d.readUnsignedByte();
		return b1;
	}
	*/

	private int readWord(DataInputStream d) throws IOException
	{
		int b1 = d.readUnsignedByte();
		int b2 = d.readUnsignedByte();
		System.out.println("readWord: " + b1 + " " + b2);
		return (b1 << 8) + b2;
	}

	private long readLong(DataInputStream d) throws IOException
	{
		long l1 = readWord(d);
		long l2 = readWord(d);
		System.out.println("readLong: " + l1 + " " + l2);
		return (l1 << 16) + l2;
	}
}
