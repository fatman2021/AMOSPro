package jamos;

//import jgame.*;
import jamos.jAMOS.Player;
import jamos.abkviewer.AbkDecode;
import jamos.abkviewer.AbkFile;
import jamos.abkviewer.AbkGfx;
import jamos.abkviewer.AbkViewer;

import java.io.File;
import java.util.ArrayList;

import jgame.JGImage;
import jgame.platform.*;
import jgame.JGObject;
//import java.io.*;
//import java.util.Random;
//import jamal.JAMAL.AMOS_Sprite;
//import jgame.JGPoint;

public class GameEngineWrapper
{
	jAMOS ma;
	//(class <? extends JAMAL>) ma2;
	AMOS_System AM;
	
	// Used to hold the simulated AMOS Sprites and Bobs:
	AMOS_Sprite mainsprite[];
	AMOS_Sprite mainbob[];
	
	// Moved:
	Player mainsprite1;

	// Added:
	java.awt.image.BufferedImage buf = null;
	java.awt.Graphics gg = null;
	
	public GameEngineWrapper(jAMOS mygame)
	{
		ma = mygame;
		AM = jAMOS.AM;
		//AM = ma.AM;
	}
	
	void prepdraw()
	{
		String backgroundid = mainsprite1.getGraphic();
		if (buf == null)
		{
			// This retrieves JGImage from the background defined image
			JGImage bgimg=ma.getImage(backgroundid);

			// Our own routine to create an Image object from it
			java.awt.Image img=bgimg.getImage();
		   
			// Create a new Java AWT image:
    		java.awt.GraphicsEnvironment ge = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
    		java.awt.GraphicsDevice gs = ge.getDefaultScreenDevice();
    		java.awt.GraphicsConfiguration gc = gs.getDefaultConfiguration();
			buf = gc.createCompatibleImage(img.getWidth(ma), img.getHeight(ma), java.awt.Transparency.BITMASK);
			gg=buf.getGraphics();
			gg.drawImage(img, 0, 0, ma);
		}
	}
	
	void finalisedraw()
	{
		// Replace the defined image with the composed image:
		//JREImage je=new JREImage((java.awt.Image)buf);
		String backgroundid = mainsprite1.getGraphic();
		JGImage je=(JGImage)new JREImage((java.awt.Image)buf);
		ma.reDefineImage(backgroundid, (JGImage)je);
	}
	
	public void loadaudio()
	{
		// Moved from AMOS_System:
		// TODO - move to wrapper
		// Added: Load audio clips:
		ma.defineAudioClip("bell", "resources/bell.wav");
		ma.defineAudioClip("boom", "resources/boom.wav");
		ma.defineAudioClip("shoot", "resources/shoot.wav");
		ma.defineAudioClip("java", "resources/java.wav");
		ma.defineAudioClip("translated", "resources/translated.wav");
		ma.defineAudioClip("stripped", "resources/stripped.wav");
	}
	
	// Moved from AMOS_System: Sound methods:
	// New:
	public void bell()
	{
		ma.playAudio("bell");
	}
	public void bell(int pitch)
	{
		// TODO:
		bell();
	}
	public void shoot()
	{
		ma.playAudio("shoot");
	}
	public void boom()
	{
		ma.playAudio("boom");
	}
	
	// AMOS Screen instructions:
    public void screenOpen(int a, int b, int c, int d, int e)
    {
    	AM.ScreenWidth[a]=b;
    	AM.ScreenHeight[a]=c;
    	AM.ScreenColors[a]=d;
    	AM.ScreenRes[a]=e;
    	AM.ScreenOffsetX[a]=0;
    	AM.ScreenOffsetY[a]=0;
    	AM.ScreenDisplayX[a]=0; //?
    	AM.ScreenDisplayY[a]=0; //?
    	AM.ScreenDisplayWidth[a]=b;
    	AM.ScreenDisplayHeight[a]=c;
    	
    	// TO DO - Cursor:
    	AM.ScreenXCur[a]=0;
    	AM.ScreenYCur[a]=0;
        
    	//System.out.println("Debug: Attempting to open screen "+a);
    	
        // Create the new screen here (or earlier):
        // Need to build an array for multiple screens.
        // Here we create a blank screen.
    	// Set the background file here:
		//jAMOS.mainsprite1.setImage(null); // Is this needed?
		//jAMOS.mainsprite1.setImage("resources/back.jpg"); // Set the graphics - TO DO - also work without resources
        
        // Create the screen here:
    	// Create a new Java AWT image:
		java.awt.GraphicsEnvironment ge = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
		java.awt.GraphicsDevice gs = ge.getDefaultScreenDevice();
		java.awt.GraphicsConfiguration gc = gs.getDefaultConfiguration();
		buf = gc.createCompatibleImage(b, c, java.awt.Transparency.BITMASK);
		gg=buf.getGraphics();
		JGImage je=(JGImage)new JREImage((java.awt.Image)buf);
		
		String backgroundid = mainsprite1.getGraphic();
		ma.defineImage(backgroundid, (JGImage)je);
		
		AM.ink(0);
		AM.bar(0, 0, b, c);
    }
	
    // Load image or IFF file (supports other formats instead for now):
	public void loadIff(String a, int b)
	{
		boolean alreadyloaded = false;
		
		// TODO - load real IFF image here:
		if (a.substring(a.length()-4).toLowerCase().equals(".iff"))
		{
			System.out.println("Load real IFF here!\n");
			
			// First create the AbkViewer object:
			AbkViewer viewer = new AbkViewer();
			viewer.abkfile = new AbkFile(viewer, a, ma.getClass());
	    	viewer.abkgfx =  new AbkGfx(viewer);
	    	viewer.abkdecode = new AbkDecode(viewer);
	    	
	    	// Load the image into memory:
	    	if (new File(a).exists())
	    		viewer.abkdecode.loadIff(a, true);
	    	else
	    		viewer.abkdecode.loadIff(a, false);
	    	
	    	System.out.println("Loaded real IFF here! Trying to draw!\n");
	    	
	    	prepdraw();
	    	viewer.abkgfx.simpleplotiff((java.awt.Graphics2D)gg, 2);
	    	finalisedraw();
			return;
		}
		
		// Now test if the file has already been loaded to the buffer:
		for (int n=0; n<AM.loadedimages.size() && (alreadyloaded == false); n++)
			if (AM.loadedimages.get(n).equals(a))
				alreadyloaded = true;
		
		if (!alreadyloaded)
		{
			// Load the image if it hasn't been loaded already:
			ma.defineImage(a, "", 0, a, "img_op", 0, 0, 3000, 3000);
			// Add the image path to the buffer:
			AM.loadedimages.add(a);
		}
		
		// Set the background file here:
		//mainsprite1.setImage(null); // Is this needed?
		//mainsprite1.setImage(a);
		
		// Copy to the background buffer:
		prepdraw();
		gg.drawImage(ma.getImage(a).getImage(), 0, 0, ma);
		finalisedraw();
	}
	

	// Load a Sprite bank from AMOS Basic .abk files:
	public int loadamosabk(String fileName)
	{
		// First create the AbkViewer object:
		AbkViewer viewer = new AbkViewer();
		viewer.abkfile = new AbkFile(viewer, fileName, ma.getClass());
    	viewer.abkgfx =  new AbkGfx(viewer);
    	viewer.abkdecode = new AbkDecode(viewer);
    	
    	// Cludge: Add null image:
    	AM.currentspriteimages.add(null);
    	
    	// Load the sprites into memory:
    	if (new File(fileName).exists())
    		viewer.abkdecode.loadSprites(fileName, true);
    	else
    		viewer.abkdecode.loadSprites(fileName, false);
    	
    	// Now copy the sprites to the JGame buffer:
    	for (int i=0; i<viewer.numobjects; i++)
    	{
    		String path = fileName+"/"+i;
    		
    		// Create a new Java AWT image:
    		java.awt.GraphicsEnvironment ge = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
    		java.awt.GraphicsDevice gs = ge.getDefaultScreenDevice();
    		java.awt.GraphicsConfiguration gc = gs.getDefaultConfiguration();
    		
    		java.awt.image.BufferedImage buf = gc.createCompatibleImage(Math.max(viewer.xsize[i], 1), Math.max(viewer.ysize[i], 1), java.awt.Transparency.BITMASK);
    		java.awt.Graphics gg=buf.getGraphics();
    		
    		// Modify the image here:
    		viewer.abkgfx.simpleplotsprite((java.awt.Graphics2D)gg, i, 1);
    		
    		// Convert back to JREImage:
    		JREImage je=new JREImage((java.awt.Image)buf);
    		// Replace the defined image with the composed image:
    		ma.defineImage(path, (JGImage)je);
    		
    		// Flipping:
    		je=new JREImage((java.awt.Image)buf);
    		// Replace the defined image with the composed image:
    		ma.defineImageFlipped(path+"_h", (JGImage)je, 1);
    		
    		je=new JREImage((java.awt.Image)buf);
    		// Replace the defined image with the composed image:
    		ma.defineImageFlipped(path+"_v", (JGImage)je, 2);
    		
    		je=new JREImage((java.awt.Image)buf);
    		// Replace the defined image with the composed image:
    		ma.defineImageFlipped(path+"_hv", (JGImage)je, 3);
    		
    		
    		// Add the fake path to the vector of sprite image names:
    		AM.currentspriteimages.add(path);
    	}
		
		return 0;
	}
	
	// Moved these - wrapper methods for JGame
	public void bob(int a, double b, double c)
	{ 
		bob(a, b, c, ibob(a));
	}
	
	//wrapper.bob(a, xHard(currentScreen, (new Double(b).intValue())), yHard(currentScreen, (new Double(c).intValue())), d);
	public void bob(int a, double b, double c, int d)
	{
		if (mainbob[a] == null)
		{
			mainbob[a] = newsprite(
					AM.xHard(AM.currentScreen, (new Double(b).intValue())), /* - AM.ScreenOffsetX[AM.currentScreen]),*/
					AM.yHard(AM.currentScreen, (new Double(c).intValue())), 0); /* - AM.ScreenOffsetY[AM.currentScreen]), 0); */
		}
		else
		{
			mainbob[a].x = AM.xHard(AM.currentScreen, (new Double(b).intValue()));
			mainbob[a].y = AM.yHard(AM.currentScreen, (new Double(c).intValue()));
		
			//mainbob[a].x = AM.xHard(AM.currentScreen, (new Double(b).intValue()) - AM.ScreenOffsetX[AM.currentScreen]);
			//mainbob[a].y = AM.yHard(AM.currentScreen, (new Double(c).intValue()) - AM.ScreenOffsetY[AM.currentScreen]);
		}
		
		if (mainbob[a] == null)
			return;
		
		mainbob[a].imagenumber = d;
		
		AM.BobX[a]=new Double(b).intValue();
		AM.BobY[a]=new Double(c).intValue();
		AM.BobImage[a]=d;
		
		///* Do flip - moved (old): */
		//if (mainbob[a].imagenumber >= 0x8000)
		//	mainbob[a].setGraphic("myanim_r");
		//else
		//	mainbob[a].setGraphic("myanim_l");
	}
	public void sprite(int a, double b, double c)
	{ 
		sprite(a, b, c, isprite(a));
	}
	public void sprite(int a, double b, double c, int d)
	{
		if (mainsprite[a] == null)
		{
			mainsprite[a] = newsprite(b, c, 0);
		}
		else
		{
			mainsprite[a].x = b;
			mainsprite[a].y = c;
		}
		
		if (mainsprite[a] == null)
			return;
		
		mainsprite[a].imagenumber = d;
		
		// TODO!
		//AM.SpriteX[a]=new Double(b).intValue();
		//AM.SpriteY[a]=new Double(c).intValue();
		//AM.SpriteImage[a]=d;
		
		///* Do flip: */
		//if (mainsprite[a].imagenumber >= 0x8000)
		//	mainsprite[a].setGraphic("myanim_r");
		//else
		//	mainsprite[a].setGraphic("myanim_l");
		//
		//mainsprite[a].clearAnim();
	}
	
	// DO THESE WORK?
	public double xbob(int a)
	{
		//System.out.println("xbob("+a+") = " + AM.xScreen(new Double(mainbob[a].x).intValue()));
		//AM.BobX[a]=new Double(b).intValue();
		//AM.BobY[a]=new Double(c).intValue();
		//AM.BobImage[a]=d;

		if (mainbob[a] != null)
			return AM.BobX[a]; 
		// Removed - buggy:
		//return AM.xScreen(new Double(mainbob[a].x).intValue());
		else
			return 0;
	}
	public double ybob(int a)
	{
		//System.out.println("ybob("+a+") = " + AM.yScreen(new Double(mainbob[a].y).intValue()));
		if (mainbob[a] != null)
			return AM.BobY[a]; 
		// Removed - buggy:
		//return AM.yScreen(new Double(mainbob[a].y).intValue());
		else
			return 0;
	}
	public int ibob(int a)
	{
		if (mainbob[a] != null)
			return AM.BobImage[a]; // removed // return mainbob[a].imagenumber;
		else
			return 0;
	}
	public double xsprite(int a)
	{
		if (mainsprite[a] != null)
			//return AM.SpriteX[a]; // TODO
			return mainsprite[a].x;
		else
			return 0;
	}
	public double ysprite(int a)
	{
		if (mainsprite[a] != null)
			//return AM.SpriteY[a]; // TODO
			return mainsprite[a].y;
		else
			return 0;
	}
	public int isprite(int a)
	{
		if (mainsprite[a] != null)
			//return AM.SpriteImage[a]; // TODO
			return mainsprite[a].imagenumber;
		else
			return 0;
	}
	
	public int joy(int a)
	{
		int out = 0;
		if (ma.getKey(jAMOS.KeyUp)) // was ma.KeyUp
			out |= 1;
		if (ma.getKey(jAMOS.KeyDown)) // was ma.KeyDown
			out |= 2;
		if (ma.getKey(jAMOS.KeyLeft)) // was ma.KeyLeft
			out |= 4;
		if (ma.getKey(jAMOS.KeyRight)) // was ma.KeyRight
			out |= 8;
		if (ma.getKey(jAMOS.KeyFire) || ma.getKey(jAMOS.KeyCtrl)) // was ma.KeyFire
			out |= 16;
		return out;
		//return A_Jup(t1) + (2*A_Jdown(t1)) + (4*A_Jleft(t1)) + (8*A_Jright(t1)) + (16*A_Fire(t1));
	}
	public int xmouse()
	{
		return ma.getMouseX();
	}
	public int ymouse()
	{
		return ma.getMouseY();
	}
	
	// To do:
	public int mousekey(int t1)
	{
		if (t1 == -1)
			//System.out.println("Result = " + ((ma.getMouseButton(1) || ma.getMouseButton(2) || ma.getMouseButton(3)) ? 1 : 0));
			return (ma.getMouseButton(1) || ma.getMouseButton(2) || ma.getMouseButton(3)) ? 1 : 0;
		else
			return ma.getMouseButton(t1) ? 1 : 0;
	}
	
	public void initspritesandbobs()
	{
		/* Initialise the sprite and bob arrays (currently up to 1024 sprites each): */
		mainsprite = new AMOS_Sprite[1024];
		mainbob = new AMOS_Sprite[1024];
		for (int pp=0; pp<1024; pp++)
		{
			mainsprite[pp] = null;
			mainbob[pp] = null;
		}
	}
	
	public void boboff(int a)
	{
		AM.bob(a, -100, -100, 1); // kludge!
		//if (mainbob[a] != null)
		//	mainbob[a].destroy();
		//mainbob[a] = null;
	}
	public void boboff()
	{
		for (int a=0; a<1024; a++)
			boboff(a);
	}
	public void spriteoff(int a)
	{
		AM.sprite(a, -100, -100, 1); // kludge!
		//if (mainsprite[a] != null)
		//	mainsprite[a].destroy();
		//mainsprite[a] = null;
	}
	public void spriteoff()
	{
		for (int a=0; a<1024; a++)
			spriteoff(a);
	}
	
	// To improve:
	public void animatesprites()
	{
		//System.out.println("Debug: Dumping pre-loaded sprite bank paths:");
		//for (int n=0; n<AM.currentnumspriteimages; n++)
		//{
		//	System.out.println("Sprite Image #"+n+": \""+AM.currentspriteimages.get(n)+"\"");
		//}
		
		for (int pp=0; pp<1024; pp++)
		{			
			int spriteimagenumber = AM.iSprite(pp);
			
			int spritehflip = spriteimagenumber & 0x8000;
			int spritevflip = spriteimagenumber & 0x4000;
			spriteimagenumber -= spritehflip;
			spriteimagenumber -= spritevflip;
			
			// First do sprites:
			if ((mainsprite[pp] == null) || !(spriteimagenumber >= 0 && spriteimagenumber < AM.currentspriteimages.size())) 
				;
			else if ((spritehflip == 0) && (spritevflip == 0))
				mainsprite[pp].setImage(AM.currentspriteimages.get(spriteimagenumber));
			else if ((spritehflip != 0) && (spritevflip == 0))
				mainsprite[pp].setImage(AM.currentspriteimages.get(spriteimagenumber)+"_h");
			else if ((spritehflip == 0) && (spritevflip != 0))
				mainsprite[pp].setImage(AM.currentspriteimages.get(spriteimagenumber)+"_v");
			else if ((spritehflip != 0) && (spritevflip != 0))
				mainsprite[pp].setImage(AM.currentspriteimages.get(spriteimagenumber)+"_hv");
		}
	}
	
	// To improve:
	public void animatebobs()
	{
		for (int pp=0; pp<1024; pp++)
		{			
			int bobimagenumber = AM.iBob(pp);
			int bobhflip = bobimagenumber & 0x8000;
			int bobvflip = bobimagenumber & 0x4000;
			bobimagenumber -= bobhflip;
			bobimagenumber -= bobvflip;
			
			// Now do bobs:
			if (mainbob[pp] == null || !(bobimagenumber >= 0 && bobimagenumber < AM.currentspriteimages.size()))
				;
			if ((bobhflip == 0) && (bobvflip == 0))
				mainbob[pp].setImage(AM.currentspriteimages.get(bobimagenumber));
			else if ((bobhflip != 0) && (bobvflip == 0))
				mainbob[pp].setImage(AM.currentspriteimages.get(bobimagenumber)+"_h");
			else if ((bobhflip == 0) && (bobvflip != 0))
				mainbob[pp].setImage(AM.currentspriteimages.get(bobimagenumber)+"_v");
			else if ((bobhflip != 0) && (bobvflip != 0))
				mainbob[pp].setImage(AM.currentspriteimages.get(bobimagenumber)+"_hv");
		}
	}
	
	public AMOS_Sprite newsprite(double x, double y, double speed)
	{
		return new AMOS_Sprite(x, y, speed);
	}
	
	public class AMOS_Sprite extends JGObject
	{
		int imagenumber;
		public AMOS_Sprite(double x,double y,double speed) {
			super("myobject",true,x,y,1,"null", 0,0,speed,speed,-1);
		}
		public void move() {
			//setDir(0,0);
		}
		/*public void hit(JGObject obj) {
			if (and(obj.colid,2)) ma.lifeLost();
			else {
				ma.score += 5;
				obj.remove();
			}
		}*/
		
		// test:
		/*public void paint()
		{
			ma.setColor(JGColor.black);
			for (int n=0; n<100; n++)
				for (int m=0; m<100; m++)
				{
					ma.setColor(JGColor.black);
					Random randomgenerator = new Random();
					if (randomgenerator.nextInt(3)== 1)
					{
						ma.drawLine(x+n,y+m,x+n+1,y+m,false);
						ma.drawLine(x+n,y+m+1,x+n,y+m,false);
					}
				}
		}*/
	}
	
	// Added:
	public void screenSize(int a, int b, int c)
	{
		//System.out.println("Debug: Doing screenSize: w="+b+", h="+c);
		AM.ScreenDisplayWidth[a] = b;
		AM.ScreenDisplayHeight[a] = c;

		// Resize and update the screen background image here:
		if (mainsprite1.getImageName().equals(a));
		ma.defineImage(mainsprite1.getImageName(), "", 0, mainsprite1.getImageName(), "img_op", 0, 0, b, c);

		// Re-display the screen (TO DO:)
		screenDisplay(a, AM.ScreenDisplayX[a], AM.ScreenDisplayY[a]);
	}

	public void screenDisplay(int a, int b, int c)
	{
		// Reposition the screen (TO DO - just one image now):
		AM.ScreenDisplayX[a]=b;
		AM.ScreenDisplayY[a]=c;

		// Set the appropriate screen number here (TO DO)

		mainsprite1.setPos(AM.ScreenDisplayX[a] - AM.ScreenOffsetX[a], AM.ScreenDisplayY[a] - AM.ScreenOffsetY[a]);

		// TO DO: Multiple screen support:
		// Now move all bobs of that screen accordingly:
		for (int pp=0; pp<1024; pp++)
			// Optimise - search up to highest allocated bob number (TO DO)
			if ((mainbob[pp]) != null)
				// Later ensure these are moved with the appropriate screen:
				bob(pp, xbob(pp), ybob(pp), ibob(pp));
	}
	
	// Banks:
	// Load a bank (folder of sprites for now)
	// TO DO - faux packed pictures (with unpack).
	public void load(String a, int b)
	{
		int numsp=0;
		//System.out.println("Loading bank file \""+a+"\" to bank " + b);

		// First check if b == 1 (sprite bank)
		if (b == 1)
		{
			// Need to initialise both:
			AM.currentspriteimages = new ArrayList<String>();

			// Added - load ABK file if appropriate:
			if (a.length() > 4)
			{
				if (a.substring(a.length()-4).toLowerCase().equals(".abk"))
				{
					loadamosabk(a);
					return;
				}
			}

			// Load and label sprites from a folder.
			// Supports multiple extensions.
			boolean filefound = false;
			do
			{
				String path = "";
				int ext;
				String[] extension = {".png", ".gif", ".jpg"};

				filefound = false;
				// Check each extension in turn:
				for (ext=0; (ext < extension.length) && (filefound==false); ext++)
				{
					// Load the image if it hasn't been loaded already:
					try
					{
						boolean alreadyloaded = false;

						// Here check if already loaded for each extension type:
						path = a + "/" + AM.currentspriteimages.size() + extension[ext];

						// Now test if the file has already been loaded to the buffer:
						//System.out.println("Debug: Trying to load sprite image #"+numsp+" from file \""+path+"\"");

						if (AM.loadedspriteimages.size() > 0)
						{
							for (int ind=0; ind<AM.loadedspriteimages.size(); ind++)
							{
								if (AM.loadedspriteimages.get(ind).equals(path))
								{
									alreadyloaded = true;
									//System.out.println("Success! Already loaded image identified!");
									break;
									// "path" is now the image identifier!
								}
							}
						}

						// Load the sprite image from the file if not already loaded,
						// then add the path to the loaded images string vector:
						if (alreadyloaded == false)
						{
							path = a+ "/" + numsp + extension[ext]; // currentspriteimages[]
							//System.out.println("Debug: Need to load sprite image \""+path+"\" from disk.");

							ma.defineImage(path, "-", 0, path, "-", 0, 0, 100, 100); //"-"
							ma.defineImage(path+"_h", "-", 0, path, "x", 0, 0, 100, 100); //"x"
							//ma.getImage(path+"_h").flip(true, false); // does not work here
							ma.defineImage(path+"_v", "-", 0, path, "y", 0, 0, 100, 100); //"y"
							//ma.getImage(path+"_v").flip(false, true);
							ma.defineImage(path+"_hv", "-", 0, path, "u", 0, 0, 100, 100); //"u"
							//ma.getImage(path+"_hv").flip(true, true);

							AM.loadedspriteimages.add(path);
						}

						// Need to initialise both:
						AM.currentspriteimages.add(path);

						// Increment the number of sprite images;
						numsp++;

						filefound = true;
						//System.out.println("Sprite successfully loaded!");
					} catch (Error e) { // optimise this (TO DO) - what type of error is thrown?
						//System.out.println("Caught Error!");
					}
				}
				//if (filefound)
				//	System.out.println("Going round the do while loop once more...");
			}
			while(filefound);

			//System.out.println("Total number of sprite images loaded: "+numsp);
		}

		// Removed - for ABK loading - TO DO:
		//try { loadabk(a); } catch (IOException e) { }
	}
	
	// TODO:
	public void erase(int a)
	{
	}
	
	
	// Added - drawing methods:
	public int pastebob(int x, int y, int a)
	{
		prepdraw();

		int bobhflip = a & 0x8000;
		int bobvflip = a & 0x4000;
		a -= bobhflip;
		a -= bobvflip;

		String flipstr = "";
		if ((bobhflip>0) && (bobvflip>0))
			flipstr = "_hv";
		else if (bobhflip>0)
			flipstr = "_h";
		else if (bobvflip>0)
			flipstr = "_v";

		// Paste the bob here:
		gg.drawImage((ma.getImage(AM.currentspriteimages.get(a)+flipstr).getImage()), x, y, ma);

		finalisedraw();
		return 0;
	}
	
	public int plot(int x, int y, int a)
	{
		prepdraw();

		// Plot here:
		gg.setColor(new java.awt.Color(a));
		gg.fillRect(x, y, 1, 1);

		finalisedraw();
		return 0;
	}
	public int plot(int x, int y)
	{
		prepdraw();

		// Plot here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.fillRect(x, y, 1, 1);

		finalisedraw();
		return 0;
	}
	public int draw(int x1, int y1, int x2, int y2)
	{
		prepdraw();

		// Draw line here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.drawLine(x1, y1, x2, y2);

		finalisedraw();
		return 0;
	}
	public int bar(int x1, int y1, int x2, int y2)
	{
		prepdraw();

		// Draw bar here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.fillRect(x1, y1, x2-x1, y2-y1);

		finalisedraw();
		return 0;
	}
	public int box(int x1, int y1, int x2, int y2)
	{
		prepdraw();

		// Draw box here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.drawRect(x1, y1, x2-x1, y2-y1);

		finalisedraw();
		return 0;
	}
	public int circle(int x1, int y1, int r)
	{
		prepdraw();

		// Draw circle here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.drawOval(x1-r, y1-r, r*2, r*2);

		finalisedraw();
		return 0;
	}
	public int ellipse(int x1, int y1, int r1, int r2)
	{
		prepdraw();

		// Draw ellipse here:
		gg.setColor(new java.awt.Color(AM._ink));
		gg.drawOval(x1-r1, y1-r2, r1*2, r2*2);

		finalisedraw();
		return 0;
	}
}
