package jamos.mequascript;

public class ExpressionReturn
{
	// 0 = constant numbers, 1=variables, 2=functions, 3=strings, 4=operators, 5=tempvalue, -1=null (no [valid] expression)
	int exptype;
	double expdata;
}
