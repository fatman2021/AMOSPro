package jamos.mequascript;
import java.util.ArrayList;

public class Game
{
	// Create dynamically allocatable array of tokens (brains):
	public ArrayList <TheTokens> mytokens = new ArrayList<TheTokens>();

	// Currently one myvalues per brain - will be customisable number of instances of each (including none).
	public ArrayList <ActiveObject> ActiveObjects = new ArrayList<ActiveObject>();
	
	// Note: (WAS) Using nasty global variables...
	// Command 1 = "print"
	// Set an array of strings. (only 10?)
	String[] textinstruction = new String[25]; // 20
	String[] textfunction = new String[200]; // 100
	int numinstructions;
	int numfunctions;
}
