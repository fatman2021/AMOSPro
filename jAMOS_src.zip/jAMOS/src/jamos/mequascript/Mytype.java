// Custom type used for MequaScript:
package jamos.mequascript;

public class Mytype
{
	  int t;
	  double d;
	  String s;
	  
	  Mytype()
	  {
		  t=0;
		  d=0;
	  }
	  void erase()
	  {
		  t=0;
		  d=0;
	  }
	  void set(double a)
	  {
		  t=0;
		  d=a;
	  }
	  void set(String a)
	  {
		  t=1;
		  s=a;
	  }
	  void dump()
	  {
		  if (t == 0)
			  System.out.println(""+d);
		  else if (t == 1)
			  System.out.println(s);
	  }
	  void add(double b)
	  {
		  if (t == 0)
			  d += b;
		  else if (t == 1)
			  s += (""+b);
	  }
	  void add(String b)
	  {
		   if (t == 0)
		   {
		      t = 1;
		      s = b;
		   }
		   else if (t == 1)
		   {
		      s += b;
		   }
	  }
	  
	  // Added to produce a duplicate object:
	  Mytype copy()
	  {
		 Mytype ret = new Mytype();
		 ret.t = this.t;
		 ret.d = this.d;
		 ret.s = this.s;
		 return ret;
	  }
}
