// Custom ARRAY type used for MequaScript:
package jamos.mequascript;

// Added for arrays:
import java.util.ArrayList;
import jamos.mequascript.Mytype;

public class Mytypearray
{
	  ArrayList<Mytype> arr = null;
	  ArrayList<Integer> dimensions = new ArrayList<Integer>();
	  ArrayList<Integer> dimensionsindex = new ArrayList<Integer>();
	  int arrsize = 0;
	  
	  Mytypearray(ArrayList<Integer> newdimensions)
	  {
		  this.dimension(newdimensions);
	  }
	  
	  // For arrays:
	  void dimension(ArrayList<Integer> newdimensions)
	  {
		  int size = 1;
		  
		  for (int n=0; n<newdimensions.size(); n++)
		  {
			  size *= newdimensions.get(n);
			  
			  // Create the dimensionsindex array to calculate later:
		      dimensionsindex.add(0);
		  }
		  
		  dimensions = newdimensions;
		  
		  arr = new ArrayList<Mytype>();
		  arrsize = size;
		  for (int temp=0; temp<size; temp++)
			  arr.add(new Mytype());
		  
		  // Now calculate the dimensionsindex in reverse:
		  size = 1;
		  for (int n=newdimensions.size()-1; n>=0; n--)
		  {
			  dimensionsindex.set(n, size);
			  size *= newdimensions.get(n);
		  }
	  }
	  
	  // Get/set with multi-dimensional support:
	  int getindexfrommulti(ArrayList<Integer> multidimensions)
	  {
		  int num = 0;
		  for (int n=0; n<multidimensions.size(); n++)
			  num += dimensionsindex.get(n) * multidimensions.get(n);
		  
		  return num;
	  }
	  
	  // Setter methods:
	  int set(ArrayList<Integer> multidimensions, Mytype val)
	  {
		  return set(getindexfrommulti(multidimensions), val);
	  }
	  int set(int num, Mytype val)
	  {
		  if (num < arrsize)
		  {
			  //System.out.println("Debug: Setting array index "+num);
			  arr.set(num, val);
			  return 0;
		  }
		  else
		  {
			  System.err.println("Error: Array set index out of bounds!");
			  return -1;
		  }
	  }
	  
	  // Getter methods:
	  Mytype get(ArrayList<Integer> multidimensions)
	  {
		  return get(getindexfrommulti(multidimensions));
	  }
	  Mytype get(int num)
	  {
		 if (num < arrsize)
		 {
			 //System.out.println("Debug: Getting array index "+num);
			 return arr.get(num);
		 }
		 else
		 {
			 System.err.println("Error: Array get index out of bounds!");
			 return new Mytype(); //null;
		 }
	  }
}
