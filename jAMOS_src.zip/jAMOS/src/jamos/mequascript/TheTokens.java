package jamos.mequascript;
import java.util.ArrayList;
import java.util.Stack;

public class TheTokens
{
	//thetokens(string s);
	//void addtokens(string s);

	ArrayList <TokeniserReturn> myparameters = new ArrayList<TokeniserReturn>();
	ArrayList <String> myvarnames = new ArrayList<String>();
	ArrayList <String> myarraynames = new ArrayList<String>();
	ArrayList <String> mystrings = new ArrayList<String>();
	
	// Added for Procedures:
	ArrayList <String> myprocedures = new ArrayList<String>();
	ArrayList <String> myprocedurecalls = new ArrayList<String>();
	ArrayList <Integer> myprocedurepositions = new ArrayList<Integer>();
	
	// Used for Procedure calls at run-time, to hold the initial position:
	Stack <Integer> myprocedurestack = new Stack<Integer>();
	
	String name = "";
	
	TheTokens()
	{
	}
	TheTokens(String s)
	{
		name = s;
	}
}
