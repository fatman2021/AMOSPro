package jamos.mequascript;
import java.util.ArrayList;

public class ActiveObject
{
	ArrayList <Mytype> myvars = new ArrayList<Mytype>();
	ArrayList <Mytypearray> myarrays = new ArrayList<Mytypearray>();
	public int ObjectBrain;
	
	// Added for Java - AMAL-style pause:
	int currentpos = 0;
	int paused = 0;
	
	// Moved Procedure Param returns here (was in AMOS_System.java):
    public String myparamstring = "";
    public double myparamfloat = 0.0;
    public int myparamint = 0;
    public int myparamtype = 0; // 0=int, 1=double, 2=string
};
