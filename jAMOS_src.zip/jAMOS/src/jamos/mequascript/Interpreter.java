package jamos.mequascript;

// Added for jAMOS:
import jamos.AMOS_System;

import java.util.ArrayList;

public class Interpreter
{
	// Added init method:
	Game g;
	CommandWrapper commandwrapper;
	
	// Added for jAMOS:
	AMOS_System am;
	
	public Interpreter (Game g_, AMOS_System am_)
	{
		g=g_;
		am = am_;
		commandwrapper = new CommandWrapper(g, am);
	}

	// TODO - duplicate:
	String lower(String s)
	{
		return s.toLowerCase();
	}
	String floattostring(double value)
	{
		if (((double)((int)value)) != value)
			return ""+value;
		else
			return ""+((int)value);
	}
	
	// For the Interpreter:
	double getarg(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return arg;
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).d;
		case 3:
			return 0; // String: mytokens.mystrings[arg] - fix types!
		case 5:
			return mytemps[(int)arg].d; // Make sure initialised!
		default:
			return 0;
		}
	}
	String getarg2(double arg, int argtype, ActiveObject myvalues, TheTokens mytokens, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return floattostring(arg);
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			// Convert number if appropriate:
			if (myvalues.myvars.get((int)arg).t == 0)
				return floattostring(myvalues.myvars.get((int)arg).d);
			else
				return myvalues.myvars.get((int)arg).s;
		case 3:
			return mytokens.mystrings.get((int)arg);
		case 5:
			return ((mytemps[(int)arg].s)); // Make sure initialised!
		default:
		}
		return null;
	}
	// Was int in C++, changed to boolean in Java:
	boolean isnumber(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case -1:
			return true;
		case 0:
			return true;
		case 1: // Variable name - to do:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).t == 0;
		case 3:
			return false;
		case 5:
			return (mytemps[(int)arg].t) == 0; // Make sure initialised!
		default:
		}
		return false;
	}


	// Modified interpreter routine - note: if (nn>0) is removed!
	void setextravars(int nn)
	{
		//if (nn>0)
		//{
		//ArrayList <Mytype> myvars = (multivalues.get(nn).myvars);
		ArrayList <Mytype> myvars = (g.ActiveObjects.get(nn).myvars);
		//System.out.println("Number of vars: " +myvars.size()); //debug
		
		myvars.add(new Mytype());
		myvars.get(0).s =  "Test Object"; // Object Name
		myvars.get(0).t = 1;
		myvars.add(new Mytype());
		myvars.get(1).s = "Description Goes Here!"; // Object Description
		myvars.get(1).t = 1;
		myvars.add(new Mytype());
		myvars.get(2).d = 0; // Portable
		myvars.get(2).t = 0;
		myvars.add(new Mytype());
		myvars.get(3).d = 0; // Examine
		myvars.get(3).t = 0;
		myvars.add(new Mytype());
		myvars.get(4).d = 0; // Use
		myvars.get(4).t = 0;
		myvars.add(new Mytype());
		myvars.get(5).d = 0; // Use With
		myvars.get(5).t = 0;
		myvars.add(new Mytype());
		myvars.get(6).d = 0; // Take
		myvars.get(6).t = 0;
		myvars.add(new Mytype());
		myvars.get(7).d = 0; // In inventory
		myvars.get(7).t = 0;

		// Removed - from 3Dlicious! - not implemented here:
		//setobjectvars(nn); // removed

		//}
	}

	public int initvalues(ArrayList <TheTokens> multitokens, int nn)
	{
		String temptext;
		//String temptext2;

		// Now initialise the variables for the object (size given in the brain/class):
		for (int n=0; n<(multitokens.get(g.ActiveObjects.get(nn).ObjectBrain).myvarnames.size()); n++)
		{
			// Exception: Check if any used variable names correspond to brain/class names:
	        // NOTE: In Java: temptext = ...
			temptext = lower(multitokens.get(g.ActiveObjects.get(nn).ObjectBrain).myvarnames.get(n));
			int ob = 0;
			
			// Find the first object of the appropriate class/brain (returned in n):
			for (ob=0; ob<g.ActiveObjects.size() &&
					!temptext.equals(lower(multitokens.get(g.ActiveObjects.get(ob).ObjectBrain).name)); ob++);

			// Add the new variable:
			Mytype tempvar = new Mytype();
			if (ob<g.ActiveObjects.size())
				tempvar.d = (double)ob;
			else
				// Clear the variable:
				tempvar.d = 0;

			tempvar.t = 0;
			g.ActiveObjects.get(nn).myvars.add(tempvar);
		}

		// Set the extra variables here (removed for Java):
		//setextravars(nn); // removed

		// Note: temptext is deleted automatically by Java's garbage collector.
		return 0;
	}


	// The Interpreter!
	public int interpret(ArrayList <TheTokens> multitokens, int on)
	{
		TokeniserReturn ret;
		Mytype realret = new Mytype();
		//int jumplevel; // removed - not used
		int iflevel, numjumps, limitjumps;
		ActiveObject myvalues;
		TheTokens mytokens;

		//// Initialise the array for nested jump-points:
		//int jumppoint[100]; // removed

		double[] ifexp = new double[20];
		int[] iffinaljumppoint = new int[20];

		// Only 50 temps? (Should be enough - was 100) - changed to 100!
		Mytype[] mytemps = new Mytype[100];
		// Added for Java - initialise mytemps[]
		for (int whichtemp=0; whichtemp<100; whichtemp++)
			mytemps[whichtemp] = new Mytype();

		// Note: Move these to the class if concurrent brain interpretation is necessary (i.e. and Amal-style 'Pause')...

		// For the brain:
		//jumplevel = 0; // removed - not used
		iflevel = 0;

		// Debug - the number of jumps made and limit:
		// Reset this as appropriate:
		numjumps = 0;
		// Make this limit customisable (eventually):
		limitjumps = 100000000; // was 1000;

		myvalues = g.ActiveObjects.get(on);
		mytokens = multitokens.get(myvalues.ObjectBrain);

		// Allow multi-pausing:
		if (myvalues.paused > 0)
			myvalues.paused--;

		// TODO: Start from set position // using myvalues.currentpos instead of l

		for (; (myvalues.currentpos)<(mytokens.myparameters.size()) && (numjumps<limitjumps) && (myvalues.paused == 0); myvalues.currentpos++)
		{
			ret = mytokens.myparameters.get(myvalues.currentpos);
			
			// Finally, evaluate the instruction itself:
			if ((ret.insttype) == 1) // Standard Instruction
			{
				// For executing system instructions:
				switch(ret.instflag)
				{
				case 1:
					// Else If
					// Include the !ifexp(...) in the new ifexp:

					// Similar to If:
					if (!((0==ifexp[iflevel - 1]) && (0!=getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps))))
					{
						// Skip to the endif if a successful If or Else If test has already been run,
						// otherwise, skip to the next Else If or Else...
						if (ifexp[iflevel - 1] != 0)
							myvalues.currentpos = iffinaljumppoint[iflevel - 1] - 1;
						else
							myvalues.currentpos = (int)ret.args[1] - 1;
					}
					else
					{
						ifexp[iflevel - 1] = 1;
					}
					break;
				case 2:
					// Else
					if (ifexp[iflevel - 1] != 0)
						myvalues.currentpos = (int)ret.args[1] - 1;
					//iflevel--; // Removed
					break;
				case 3:
					// End/Exit - TODO - move to end of code (ignore parameters):
					myvalues.currentpos = mytokens.myparameters.size();
					break;
				case 5:
					// Until
					//System.out.println("DEBUG: UNTIL needs some work");
					// Jump to jump-point if argument is false:
					if (getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps) == 0)
					{
						myvalues.currentpos = (int)ret.args[1] - 1; // -1 because of the loop
						// Increase the number of jumps made:
						numjumps++;
					}
					break;
				case 6:
					// If
					//System.out.println("DEBUG: IF needs some work, jump point = "+((int)ret.args[3]));
					ifexp[iflevel] = getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps);
					iffinaljumppoint[iflevel] = (int)ret.args[3];
					iflevel++;
					// Move to set jumppoint if argument is false:
					if (ifexp[iflevel - 1] == 0)
						myvalues.currentpos = (int)ret.args[1] - 1; // -1 because of the loop
					break;
				case 7: case 18:
					// Endif, End If
					iflevel--;
					break;
				case 8:
					// While
					//System.out.println("DEBUG: WHILE needs some work, jump point = "+((int)ret.args[3]));
					// Move to set jumppoint if argument is false:
					if (getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps) == 0)
					//{
					myvalues.currentpos = (int)ret.args[1] - 1; // -1 because of the loop
					// Debug - increase the number of jumps made (removed)
					//numjumps++;
					//}
					break;
				case 9: case 15: case 16: case 17:
					// Wend, Loop, Endwhile, Forever
					// Jump to jump-point (where we evaluate the temps before the while):
					myvalues.currentpos = (int)ret.args[0] - 1; // -1 because of the loop
					// Debug - increase the number of jumps made:
					numjumps++;
					break;
				case 12:
					// Wait Vbl

					//if (ret.numargs > 0)
					//{
					//	System.out.println("DEBUG: Wait Vbl "+((int)ret.args[0])+" here!");
					//	myvalues.paused = (int)ret.args[0];
					//}
					//else
					//{
					//System.out.println("DEBUG: Wait Vbl here!");
					myvalues.paused = 1;
					//}

					break;
				case 13:
					// Wait - TODO
					//System.out.println("DEBUG: WAIT needs some work");

					if (ret.numargs > 0)
					{
						//System.out.println("DEBUG: Wait "+((int)ret.args[0])+" here!");
						myvalues.paused = (int)ret.args[0];
					}
					else
					{
						//System.out.println("DEBUG: Wait (1) here!");
						myvalues.paused = 1;
					}

					break;
				case 19:
					// Procedure:
					//System.out.println("DEBUG - executing Procedure "+mytokens.myprocedures.get((int)ret.args[0])+" ("+ret.args[0]+"), end position:"+ret.args[1]);
		
					// Jump to the end position, 1 after the End Proc (+1 removed as it's added automatically):
					myvalues.currentpos = (int)ret.args[1]; // + 1;
					break;
				case 20:
					// End Proc:
					//System.out.println("DEBUG - executing End Proc");
					
					// First grab the return value, if it exists:
					if (ret.numargs > 0)
					{
						if (isnumber(ret.args[0], ret.argtypes[0], myvalues, mytemps))
						{
							myvalues.myparamfloat = getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps);
							myvalues.myparamint = (int)(myvalues.myparamfloat);
							//myvalues.myparamint = (int)getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps);
						}
						else
						{
							myvalues.myparamstring = getarg2(ret.args[0], ret.argtypes[0], myvalues, mytokens, mytemps);
						}
					}
					
					// Jump back to position on stack here:
					if (!mytokens.myprocedurestack.empty())
					{
						myvalues.currentpos = mytokens.myprocedurestack.pop();
					}
					else
					{
						System.err.println("Error: Procedure stack is empty!");
					}
					
					break;
				case 21: case 22:
				{{
					// Proc (call Procedure):
					//System.out.println("TODO - executing Proc "+mytokens.myprocedures.get((int)ret.args[0])+" ("+ret.args[0]+"), jumppoint="+mytokens.myprocedurepositions.get((int)ret.args[0]));
					
					int procpos = mytokens.myprocedurepositions.get((int)ret.args[0]);
					TokeniserReturn procedureret = mytokens.myparameters.get(procpos);
					
					// First grab any arguments (debug - removed):
					/*if (ret.numargs > 1)
					{
						System.out.print("TODO: Proc arguments: ");
						for (int arg=1; arg<ret.numargs; arg++)
						{
							if (isnumber(ret.args[arg], ret.argtypes[arg], myvalues, mytemps))
							{
								System.out.print(""+ getarg(ret.args[arg], ret.argtypes[arg], myvalues, mytemps));
							}
							else
							{
								System.out.print("\"");
								System.out.print(getarg2(ret.args[arg], ret.argtypes[arg], myvalues, mytokens, mytemps));
								System.out.print("\"");
							}
							
							if ((arg+1)<(ret.numargs))
								System.out.print(", ");
						}
						System.out.println();
					}*/
					
					int procedureargs = (int)procedureret.args[2];
					if (procedureargs != ((ret.numargs) - 1))
						System.out.println("Syntax error: Wrong number of arguments in procedure call!");
					
					//if (procedureargs > 0)
					//	System.out.println("Debug: Procedure definition has "+procedureargs+" arguments.");
					
					// Now pass the evaluated expressions to the procedure definition's defined variables:
					for (int varnum=0; (varnum<procedureargs) && (varnum<((ret.numargs) - 1)); varnum++)
					{
						int whichvar = (int)procedureret.args[3+varnum];
						if (isnumber(ret.args[varnum+1], ret.argtypes[varnum+1], myvalues, mytemps))
						{
							double arg = getarg(ret.args[varnum+1], ret.argtypes[varnum+1], myvalues, mytemps);
							// Set the variable here to the given number:
							myvalues.myvars.get(whichvar).set(arg);
						}
						else
						{
							String argstr = getarg2(ret.args[varnum+1], ret.argtypes[varnum+1], myvalues, mytokens, mytemps);
							// Set the variable here to the given string:
							myvalues.myvars.get(whichvar).set(argstr);
						}
					}
					
					// Add current position to stack here:
					mytokens.myprocedurestack.push(myvalues.currentpos);
					
					// Branch to position of procedure here:
					myvalues.currentpos = procpos;
					
					break;
				}}
				case 23:
				{
					// Dim (to dimension arrays):
					
					//int arraynum = (int)ret.args[0]; // debug
					int numargs = (int)ret.args[1];
					ArrayList<Integer> dimensions = new ArrayList<Integer>();
					
					// Debug:
					//String arrayname = mytokens.myarraynames.get(arraynum);
					//System.out.println("DEBUG: Dim called here!");
					//System.out.println("Array name: #"+arrayname+"# ("+arraynum+")");
					//System.out.println("Number of dimensions: "+numargs);
					
					for (int c=0; c<numargs; c++)
					{
						int whicharg = c + 2;
						if (isnumber(ret.args[whicharg], ret.argtypes[whicharg], myvalues, mytemps))
						{
							double arg = getarg(ret.args[whicharg], ret.argtypes[whicharg], myvalues, mytemps);
							dimensions.add((int)arg);
							// Debug:
							//System.out.println(floattostring(arg));
						}
						else
						{
							System.err.println("Syntax error: Array dimension must be a number!");
							String argstr = getarg2(ret.args[whicharg], ret.argtypes[whicharg], myvalues, mytokens, mytemps);
							// Debug:
							System.err.println(argstr);
						}
					}
					
					// Now dimension arraynum with dimensions - should be initial declaration here (TEST - TODO):
					// TODO - test if it is correct number!!!
					Mytypearray newarray = new Mytypearray(dimensions);
					
					// Add the array here:
					myvalues.myarrays.add(newarray);	
					
					break;
				}
				default:
					// case 14: - Do (not executed)
					// case 4: - Repeat (not executed)
					break;
				}

				//System.out.println(textinstruction[ret.instflag] + " ");
				//dumparg(ret.arg, ret.argtype, mytokens);
				//System.out.println("");
			}
			else if ((ret.insttype) == 2) // Let Temp[x] = a OPERATOR b
			{
				if (isnumber(ret.args[1], ret.argtypes[1], myvalues, mytemps) 
						&& isnumber(ret.args[2], ret.argtypes[2], myvalues, mytemps))
				{
					// Get args 1 and 2, do operation...
					double arg1 = getarg(ret.args[1], ret.argtypes[1], myvalues, mytemps);
					double arg2 = getarg(ret.args[2], ret.argtypes[2], myvalues, mytemps);
					mytemps[(int)ret.args[0]].t = 0;

					switch (ret.instflag)
					{
					case 0: // dot (.) - to do
						if (g.ActiveObjects.get((int)arg1).myvars.get((int)arg2).t == 0)
						{
							mytemps[(int)ret.args[0]].d = g.ActiveObjects.get((int)arg1).myvars.get((int)arg2).d;
						}
						else
						{
							mytemps[(int)ret.args[0]].s = g.ActiveObjects.get((int)arg1).myvars.get((int)arg2).s;
							mytemps[(int)ret.args[0]].t = 1;
						}
						break;
					case 1:
						mytemps[(int)ret.args[0]].d = (arg2 == 0) ? 1 : 0; // arg1 or arg2?
						break;
					case 2:
						mytemps[(int)ret.args[0]].d = arg1 * arg2;
						break;
					case 3:
						mytemps[(int)ret.args[0]].d = arg1 / arg2;
						break;
					case 4:
						mytemps[(int)ret.args[0]].d = ((int)arg1) % ((int)arg2); // Better conversion to int?
						break;
					case 5:
						mytemps[(int)ret.args[0]].d = arg1 + arg2;
						break;
					case 6:
						mytemps[(int)ret.args[0]].d = arg1 - arg2;
						break;
					case 7:
						mytemps[(int)ret.args[0]].d = (arg1 < arg2) ? 1 : 0;
						break;
					case 8:
						mytemps[(int)ret.args[0]].d = (arg1 > arg2) ? 1 : 0;
						break;
					case 9:
						mytemps[(int)ret.args[0]].d = (arg1 <= arg2) ? 1 : 0;
						break;
					case 10:
						mytemps[(int)ret.args[0]].d = (arg1 >= arg2) ? 1 : 0;
						break;
					case 11:
						mytemps[(int)ret.args[0]].d = (arg1 == arg2) ? 1 : 0;
						break;
					case 12:
						mytemps[(int)ret.args[0]].d = (arg1 != arg2) ? 1 : 0;
						break;
					case 13:
						mytemps[(int)ret.args[0]].d = ((int)arg1) & ((int)arg2); // Changed - was: // ((arg1 != 0) && (arg2 != 0)) ? 1 : 0;
						break;
					case 14:
						mytemps[(int)ret.args[0]].d = ((int)arg1) | ((int)arg2); // Changed - was: // ((arg1 != 0) || (arg2 != 0)) ? 1 : 0;
						break;
					}
				}
				else
				{
					String arg1 = getarg2(ret.args[1], ret.argtypes[1], myvalues, mytokens, mytemps);
					String arg2;

					if (isnumber(ret.args[2], ret.argtypes[2], myvalues, mytemps))
						arg2 = floattostring(getarg(ret.args[2], ret.argtypes[2], myvalues, mytemps));
					else
						arg2 = getarg2(ret.args[2], ret.argtypes[2], myvalues, mytokens, mytemps);

					//System.out.println("-"+arg2+"- -"+ret.argtypes[2]+"-"); // debug
					switch (ret.instflag)
					{
					case 5: // was 1
						mytemps[(int)ret.args[0]].s = arg1 + arg2;
						mytemps[(int)ret.args[0]].t = 1;
						break;
					case 11: // was 5
						mytemps[(int)ret.args[0]].d = (arg1 == arg2) ? 1 : 0;
						mytemps[(int)ret.args[0]].t = 0;
						break;
					case 12:
						mytemps[(int)ret.args[0]].d = (arg1 != arg2) ? 1 : 0;
						mytemps[(int)ret.args[0]].t = 0;
						break;
					default:
						System.out.println("DAMN! Cannot use that operator with a string! "+arg1+" "+ret.instflag+" "+arg2);
						mytemps[(int)ret.args[0]].t = 0;
						break;
					}                 
				}
			}
			else if ((ret.insttype) == 3) // Let Temp[x] = Function(a)
			{
				// Temp - as for below...
				// Evaluate func(arg) here - return answer instead of arg...
				realret.erase();
				realret = commandwrapper.runfunction(ret, mytokens, myvalues, 1, realret, mytemps);
				mytemps[(int)ret.args[0]].t = realret.t;
				if (realret.t == 0)
					mytemps[(int)ret.args[0]].d = realret.d;
				else
					mytemps[(int)ret.args[0]].s = realret.s; //?    
			}
			else if ((ret.insttype) == 4) // Let Temp[x] = a - should be redundant.
			{
				if (isnumber(ret.args[0], ret.argtypes[0], myvalues, mytemps)) //&& isnumber(ret.args[1], ret.argtypes[1], myvalues))
				{
					// Get arg
					double arg = getarg(ret.args[1], ret.argtypes[1], myvalues, mytemps);
					mytemps[(int)ret.args[0]].d = arg;
					mytemps[(int)ret.args[0]].t = 0;
				}
				else
				{
					String arg = getarg2(ret.args[1], ret.argtypes[1], myvalues, mytokens, mytemps);
					mytemps[(int)ret.args[0]].s = arg;
					mytemps[(int)ret.args[0]].t = 1;
				}
			}
			else if (((ret.insttype) >= 5) && ((ret.insttype) <= 11)) // Var[instflag] = arg;
			{
				if (isnumber(ret.args[0], ret.argtypes[0], myvalues, mytemps)) //&& isnumber(ret.args[1], ret.argtypes[1], myvalues))
				{
					// Set variables to arg:
					double arg = getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps);
					// Variable name: mytokens.myvarnames[ret.instflag]

					// Set the variable now:
					switch (ret.insttype)
					{
					case 5: // =
						myvalues.myvars.get(ret.instflag).set(arg);
						break;
					case 6: // +=
						myvalues.myvars.get(ret.instflag).d += arg;
						break;
					case 7: // -=
						myvalues.myvars.get(ret.instflag).d -= arg;
						break;
					case 8: // /=
						myvalues.myvars.get(ret.instflag).d /= arg;
						break;
					case 9: // *=
						myvalues.myvars.get(ret.instflag).d *= arg;
						break;
					case 10: // ++
						myvalues.myvars.get(ret.instflag).d ++;
						break;
					case 11: // --
						myvalues.myvars.get(ret.instflag).d --;
						break;
					default:
						break;
					}
					myvalues.myvars.get(ret.instflag).t = 0;
				}
				else
				{
					String arg = getarg2(ret.args[0], ret.argtypes[0], myvalues, mytokens, mytemps);
					
					// Set the variable now:
					switch (ret.insttype)
					{
					case 5: // =
						myvalues.myvars.get(ret.instflag).s = arg;
						break;
					case 6: // +=
						myvalues.myvars.get(ret.instflag).s += arg;
						break;
					}
					myvalues.myvars.get(ret.instflag).t = 1;
				}
			}
			else if (((ret.insttype) >= 25) && ((ret.insttype) <= 31)) // Array(expressions) = arg;
			{
				// Variable name: mytokens.myarraynames.get(ret.instflag)
				//System.out.print("TODO: Assign array here! "+ mytokens.myarraynames.get(ret.instflag)+"(");
				//for (int arg=1; arg<ret.numargs; arg++)
				//{
				//	System.out.print(getarg(ret.args[arg], ret.argtypes[arg], myvalues, mytemps));
				//	if ((arg+1) < (ret.numargs)) System.out.print(", ");
				//}
				//System.out.print(")=");
				
				// Get the ArrayList/vector of dimensional arguments:
				ArrayList<Integer> multidemargs = new ArrayList<Integer>();
				for (int arg=1; arg<ret.numargs; arg++)
					multidemargs.add((int) getarg(ret.args[arg], ret.argtypes[arg], myvalues, mytemps));
				
				if (isnumber(ret.args[0], ret.argtypes[0], myvalues, mytemps)) //&& isnumber(ret.args[1], ret.argtypes[1], myvalues))
				{
					// Set variables to arg:
					double arg = getarg(ret.args[0], ret.argtypes[0], myvalues, mytemps);
					//System.out.println("Debug: Set array index to "+arg); // debug
					
					// Set the variable now:
					switch (ret.insttype)
					{
					case 25: // =
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d = arg;
						break;
					case 26: // +=
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d += arg;
						break;
					case 27: // -=
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d -= arg;
						break;
					case 28: // /=
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d /= arg;
						break;
					case 29: // *=
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d *= arg;
						break;
					case 30: // ++
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d ++;
						break;
					case 31: // --
						myvalues.myarrays.get(ret.instflag).get(multidemargs).d --;
						break;
					default:
						break;
					}
					myvalues.myarrays.get(ret.instflag).get(multidemargs).t = 0;
				}
				else
				{
					String arg = getarg2(ret.args[0], ret.argtypes[0], myvalues, mytokens, mytemps);
					//System.out.println(arg); // debug
					
					// Set the variable now:
					switch (ret.insttype)
					{
					case 25: // =
						myvalues.myarrays.get(ret.instflag).get(multidemargs).s = arg;
						break;
					case 26: // +=
						myvalues.myarrays.get(ret.instflag).get(multidemargs).s += arg;
						break;
					default:
						break;
					}
					myvalues.myarrays.get(ret.instflag).get(multidemargs).t = 1;
					
					//System.out.println("Debug: Set string array here! "+arg);
				}
				
			}
			else if (((ret.insttype) >= 15) && ((ret.insttype) <= 21)) // brain.var = arg;
			{
				if (isnumber(ret.args[1], ret.argtypes[1], myvalues, mytemps))
				{
					// Set variables to arg:
					double arg = getarg(ret.args[1], ret.argtypes[1], myvalues, mytemps);
					// Variable name: mytokens.myvarnames[ret.instflag]

					// Set the variable now:
					switch (ret.insttype)
					{
					// ret.instflag = array of local variable (i.e. 'main') containing BRAIN NUM...
					// ret.args[0] = array of referred variable
					case 15: // =
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).set(arg);
						break;
					case 16: // +=
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d += arg;
						break;
					case 17: // -=
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d -= arg;
						break;
					case 18: // /=
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d /= arg;
						break;
					case 19: // *=
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d *= arg;
						break;
					case 20: // ++
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d ++;
						break;
					case 21: // --
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).d --;
						break;
					default:
						break;
					}
					g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).t = 0;
				}
				else 
				{
					String arg = getarg2(ret.args[1], ret.argtypes[1], myvalues, mytokens, mytemps);
					
					// Set the variable now:
					switch (ret.insttype)
					{
					case 15: // =
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).s = arg;
						break;
					case 16: // +=
						g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).s += arg;
						break;
					}
					g.ActiveObjects.get((int)myvalues.myvars.get(ret.instflag).d).myvars.get((int)ret.args[0]).t = 1;
				}
			}
			else if (((ret.insttype) >= 35) && ((ret.insttype) <= 41)) // brain.array(expressions) = arg;
			{
				System.out.println("TO DO: Assign brain.array(expression) = arg ...");
			}
			else if ((ret.insttype) == 50) // Function as Instruction
			{
				// Evaluate func(arg) here:
				realret.erase();
				commandwrapper.runfunction(ret, mytokens, myvalues, 0, realret, mytemps);
			}
			else
			{
				System.out.println("Error: No instruction recognised."); // debug
			}
		}

		// Error messages:
		// If allowed number of jumps exceeded:
		if (numjumps >= limitjumps)
		{
			System.out.println("Error: Too many jumps or infinite loop - exceeded limit of "+limitjumps);
			myvalues.paused = 1; // Added for consistency
		}

		//System.out.println(""); //System.out.println("End of script\n"); // debug // removed

		// Note: mytemps[] and realret are deleted automatically by Java's garbage collector.

		return 0;
	}
}
