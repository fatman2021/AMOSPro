package jamos.mequascript;
import java.util.ArrayList;
import java.util.Arrays;

public class Parser
{
	Game g;
	boolean OPTIMISE;
	boolean AMOS = true;
	
	// Moved:
	int numtemps = 0;
	
	public Parser (Game g_, boolean OPTIMISE_)
	{
		g=g_;
		OPTIMISE = OPTIMISE_;
	}

	// TODO - duplicate:
	// For the Parser:
	String floattostring(double value)
	{
		if (((double)((int)value)) != value)
			return ""+value;
		else
			return ""+((int)value);
	}
	double getarg(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return arg;
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).d;
		case 3:
			return 0; // String: mytokens.mystrings[arg] - fix types!
		case 5:
			return mytemps[(int)arg].d; // Make sure initialised!
		default:
			return 0;
		}
	}
	String getarg2(double arg, int argtype, ActiveObject myvalues, TheTokens mytokens, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return floattostring(arg);
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			// Convert number if appropriate:
			if (myvalues.myvars.get((int)arg).t == 0)
				return ""+myvalues.myvars.get((int)arg).d;
			else
				return myvalues.myvars.get((int)arg).s;
		case 3:
			return mytokens.mystrings.get((int)arg);
		case 5:
			return ((mytemps[(int)arg].s)); // Make sure initialised!
		default:
		}
		return null;
	}
	// Was int, changed to boolean:
	boolean isnumber(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case -1:
			return true;
		case 0:
			return true;
		case 1: // Variable name - to do:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).t == 0;
		case 3:
			return false;
		case 5:
			return (mytemps[(int)arg].t) == 0; // Make sure initialised!
		default:
		}
		return false;
	}

	public int initinstructions()
	{
		// Later on, read from a text file...
		g.textinstruction[0]=""; // Added - dummy first index
		g.textinstruction[1]="Else If";
		g.textinstruction[2]="Else";
		g.textinstruction[3]="Exit";
		g.textinstruction[4]="Repeat";
		g.textinstruction[5]="Until";
		g.textinstruction[6]="If";
		g.textinstruction[7]="Endif"; // "End If" // problem!!!
		g.textinstruction[8]="While";
		g.textinstruction[9]="Wend";
		g.textinstruction[10]="{";
		g.textinstruction[11]="}";
		
		g.textinstruction[12]="Wait Vbl";
		g.textinstruction[13]="Wait";
		g.textinstruction[14]="Do";
		g.textinstruction[15]="Loop";
		g.textinstruction[16]="Endwhile"; // as for Wend
		g.textinstruction[17]="Forever"; // following Repeat - as for Loop
		g.textinstruction[18]="End If"; // as for Endif
		g.textinstruction[19]="Procedure"; // Tested elsewhere
		g.textinstruction[20]="End Proc"; // Tested elsewhere
		g.textinstruction[21]="Proc"; // Tested elsewhere
		g.textinstruction[22]="Proc$"; // Tested elsewhere - reserved for procedure calls without Proc...
		g.textinstruction[23]="Dim"; // Tested elsewhere
		g.numinstructions = 23; // 18; // 11;

		g.textfunction[0]=""; // Added - dummy first index
		g.textfunction[1]="Double";
		g.textfunction[2]="Print";
		g.textfunction[3]="Say";
		g.textfunction[4]="Instr";
		g.textfunction[5]="Substring";
		
		// Added for jAMOS:
		g.textfunction[6]="Screen Open";
		g.textfunction[7]="Screen Display";
		g.textfunction[8]="Screen Offset";
		g.textfunction[9]="Screen Close";
		g.textfunction[10]="Screen Clone";
		g.textfunction[11]="Screen";
		g.textfunction[12]="Double Buffer";
		g.textfunction[13]="Dual Playfield";
		g.textfunction[14]="Dual Priority";
		g.textfunction[15]="Load Iff";
		g.textfunction[16]="Load";
		g.textfunction[17]="Erase";
		g.textfunction[18]="Hide On";
		g.textfunction[19]="Update Every";
		g.textfunction[20]="Flash Off";
		g.textfunction[21]="Flash";
		g.textfunction[22]="Set Rainbow";
		g.textfunction[23]="Rainbow Del";
		g.textfunction[24]="Rainbow";
		g.textfunction[25]="Bob Off";
		g.textfunction[26]="Bob";
		g.textfunction[27]="Set Bob";
		g.textfunction[28]="Sprite Off";
		g.textfunction[29]="Sprite";
		g.textfunction[30]="Set Sprite Buffer";
		g.textfunction[31]="Set Reg";
		g.textfunction[32]="Unpack";
		g.textfunction[33]="Channel to Sprite";
		g.textfunction[34]="Channel to Bob";
		g.textfunction[35]="Channel to Screen Offset";
		g.textfunction[36]="Channel to Screen Size";
		g.textfunction[37]="Channel to Rainbow";
		g.textfunction[38]="Channel to Screen Display";
		g.textfunction[39]="Bell";
		g.textfunction[40]="X Mouse";
		g.textfunction[41]="Y Mouse";
		g.textfunction[42]="Mouse Key";
		g.textfunction[43]="X Screen";
		g.textfunction[44]="Y Screen";
		g.textfunction[45]="X Hard";
		g.textfunction[46]="Y Hard";
		g.textfunction[47]="Joy";
		g.textfunction[48]="Jleft";
		g.textfunction[49]="Jright";
		g.textfunction[50]="Jup";
		g.textfunction[51]="Jdown";
		g.textfunction[52]="Fire";
		g.textfunction[53]="X Sprite";
		g.textfunction[54]="Y Sprite";
		g.textfunction[55]="I Sprite";
		g.textfunction[56]="X Bob";
		g.textfunction[57]="Y Bob";
		g.textfunction[58]="I Bob";
		g.textfunction[59]="Paste Bob";
		g.textfunction[60]="Plot";
		g.textfunction[61]="Ink";
		g.textfunction[62]="Draw";
		g.textfunction[63]="Bar";
		g.textfunction[64]="Box";
		g.textfunction[65]="Circle";
		g.textfunction[66]="Ellipse";
		g.textfunction[67]="Rnd";
		g.textfunction[68]="Hrev";
		g.textfunction[69]="Vrev";
		g.textfunction[70]="Rev";
		g.textfunction[71]="Rain";
		g.textfunction[72]="Degree";
		g.textfunction[73]="Radian";
		g.textfunction[74]="Sin";
		g.textfunction[75]="Cos";
		g.textfunction[76]="Tan";
		g.textfunction[77]="Asin";
		g.textfunction[78]="Acos";
		g.textfunction[79]="Atan";
		g.textfunction[80]="Pi#";
		g.textfunction[81]="Left$";
		g.textfunction[82]="Right$";
		g.textfunction[83]="Mid$";
		g.textfunction[84]="Len";
		g.textfunction[85]="Upper$";
		g.textfunction[86]="Lower$";
		g.textfunction[87]="String$";
		g.textfunction[88]="Repeat$";
		g.textfunction[89]="Space$";
		g.textfunction[90]="Flip$";
		g.textfunction[91]="Val";
		g.textfunction[92]="Str$";
		g.textfunction[93]="Asc";
		g.textfunction[94]="Chr$";
		g.textfunction[95]="Boom";
		g.textfunction[96]="Shoot";
		g.textfunction[97]="Param$"; // Special function
		g.textfunction[98]="Param#"; // Special function
		g.textfunction[99]="Param"; // Special function
		g.textfunction[100]="GetArrayValue"; // Special function
		
		g.numfunctions = 100;
		
		// Not included yet from EnvGen:
		//"if screen", "if not screen", "if bank", "if not bank", "if reg"
		
		// From 3Dlicious! (another project)
		/*
		g.textfunction[6]="Take";
		g.textfunction[7]="Rotate";
		g.textfunction[8]="Move";
		g.textfunction[9]="SetNode";
		g.textfunction[10]="SelectUseWith";
		g.textfunction[11]="UseWithMe"; // Swapped with UseWith
		g.textfunction[12]="SetOtherNode";
		g.textfunction[13]="Kill";
		g.textfunction[14]="CreateInventoryObject";
		g.textfunction[15]="CreateActiveObject";
		g.textfunction[16]="UseWith"; // changed - was UsedWith
		g.textfunction[17]="Scale";
		g.textfunction[18]="Sound";
		g.textfunction[19]="Drop";
		g.numfunctions = 19;*/

		return 0;
	}

	/////////////////////////////////////////////////////////////
	// The following are C/C++ wrappers for Java only:
	// C++-style substr:
	String substr(String str, int pos)
	{
		int stlen = str.length();
		if ((pos >= 0) && (stlen > pos))
			return str.substring(pos, Math.min(stlen, str.length())); // removed -1 of stlen-1
		return "";
	}
	String substr(String str, int pos, int len)
	{
		int stlen = str.length();
		if ((pos >= 0) && (stlen > pos))
			return str.substring(pos, Math.min(pos+len, stlen)); // removed -1 of stlen-1
		return "";
	}
	// C-style strlen:
	int strlen(String str)
	{
		return str.length();
	}
	// C-style string comparison:
	int strcmp(String str1, String str2)
	{
		if ((str1==str2) || ((str1.length() == 0) && (str2.length() == 0)))
			return 0;

		return str1.equals(str2) ? 0 : 1;
	}
	int strncmp(String str1, String str2, int len)
	{
		if ((str1==str2) || ((str1.length() == 0) && (str2.length() == 0)))
			return 0;
		if ((str1.length() == 0) || (str2.length() == 0))
			return 1;

		String sub1 = str1.substring(0, Math.min(len, str1.length()));
		String sub2 = str2.substring(0, Math.min(len, str2.length()));
		return sub1.equals(sub2) ? 0 : 1;
	}
	// C-style string to double:
	double strtod(String str)
	{
		return Double.parseDouble(str);
	}
	/////////////////////////////////////////////////////////////

	String upper(String s)
	{
		return s.toUpperCase();
	}
	// TODO - duplicate:
	String lower(String s)
	{
		return s.toLowerCase();
	}
	String uppers(String s)
	{
		return s.toUpperCase();
	}
	String lowers(String s)
	{
		return s.toLowerCase();
	}
	char lowerchar(char c)
	{
		if ((c >= 'A') && (c <= 'Z'))
			return (char) (c - ('A' - 'a'));
		else
			return c;
	}
	String upper_o(String s)
	{
		return s.toUpperCase();
	}
	String lower_o(String s)
	{
		return s.toLowerCase();
	}

	// g; // moved



	// Methods for the Parser follow:
	public ArrayList <TheTokens> inittokens(ArrayList <TheTokens> tokens, int n, String s)
	{
		TheTokens t = new TheTokens(s);
		tokens.add(t);
		return tokens; // added for Java
	}

	// param 1 corrupted!
	ExpressionReturn evaluateexpression(String expression, TheTokens mytokens) //, int numtemps)
	{
		//String temptext="", temptext2=""; //char temptext1[200], temptext2[200];

		// Moved:
		String param1=""; String param2="";
		//char param1.charAt(100]; //char *param1 = new char[50]; // Flexible length? - Fix.
		//char param2.charAt(100]; //char *param2 = new char[50]; // See above...

		ExpressionReturn expret = new ExpressionReturn(); // Added
		ExpressionReturn expret2 = new ExpressionReturn();; // Added

		TokeniserReturn ret = new TokeniserReturn();
		int exptype = -1; // expression type (see above function)
		double data = 0; // for param1
		//double data2 = 0; // for param2 // removed
		int optype = -1; // used for evaluating operators - operator type
		int operatorposition = 0; // used for evaluating operators - where in code?
		int bracketlevel = 0; // used for evaluating operators - ignoring parentheses...
		int bracketposition = 0; // used for functions - where does the new expression start?
		int instring = 0; // Check to see whether we are inside a string...
		int operatorlength = 0; // New addition...

		// Evaluate the expression (simple only here) - ignore parentheses/functions at this point.
		// To begin with - hunt for operators (+ - * /):

		// New: Operator precedence is evaluated in the opposite order.
		operatorposition = 0; //strlen(expression) - 1;
		//for (int nn=strlen(expression)-1; (nn >= 0); nn--)
		for (int nn=0; nn<strlen(expression); nn++)
		{
			char cant = lowerchar(expression.charAt(nn));

			// First switch - check for strings and parentheses:
			switch(cant)
			{
			case '(':
				if (instring == 0)
					bracketlevel++;
				break;
			case ')':
				if (instring == 0)
					bracketlevel--;
				break;
			case '"':
				instring = 1 - instring;
				break;
			}

			// Main switch - scan for operators:
			if ((instring == 0) && (bracketlevel == 0)) switch (cant)
			{
			case '.':
				// dot - check if not floating-point number, i.e. 9.nnn
				if (nn>0)
					if (optype <= 0 && (expression.charAt(nn-1) < '0' || expression.charAt(nn-1) > '9'))
					{
						optype = 0;
						operatorposition = nn;
						operatorlength = 1;
					}
				break;
			case '!':
				// for != (same as <>)
				if (optype <= 12)
				{
					if (expression.charAt(nn+1) == '=')
					{
						optype = 12;
						operatorlength = 2;
						operatorposition = nn;
						nn++;
					}
				}

				// for !
				if (optype <= 1)
				{
					optype = 1;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case 'n':
				if ((strlen(expression)-nn) > 4) //???
				{
					if ((optype <= 1) && lowerchar(expression.charAt(nn+1))=='o' && lowerchar(expression.charAt(nn+2))=='t'
							&& (expression.charAt(nn+3)==' ' || expression.charAt(nn+3)=='(') )
					{
						optype = 1;
						operatorposition = nn;
						operatorlength = 3;
						nn += 2; // will be 3 after n++...
					}
				}
				break;
			case '*':
				if (optype <= 4)
				{
					optype = 2;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case '/':
				if (optype <= 4)
				{
					optype = 3;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case '%':
				if (optype <= 4)
				{
					optype = 4;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case 'm':
				if ((nn>0) && ((strlen(expression)-nn) > 4))
				{
					if ((optype <= 4) && (expression.charAt(nn-1)==' ' || expression.charAt(nn-1)==')')
							&& lowerchar(expression.charAt(nn+1))=='o' && lowerchar(expression.charAt(nn+2))=='d'
							&& (expression.charAt(nn+3)==' ' || expression.charAt(nn+3)=='(') )
					{
						optype = 4;
						operatorposition = nn;
						operatorlength = 3;
						nn += 2; // will be 3 after n++...
					}
				}
				break;
			case '+':
				if (optype <= 6)
				{
					optype = 5;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case '-':
				if (optype <= 6)
				{
					optype = 6;
					operatorposition = nn;
					operatorlength = 1;
				}
				break;
			case '<':
				// for <> (same as !=)
				if (optype <= 12)
				{
					if (expression.charAt(nn+1) == '>')
					{
						optype = 12;
						operatorlength = 2;
						operatorposition = nn;
						nn++;
					}
				}

				// for < or <=
				if (optype <= 10)
				{
					// for <=
					if (expression.charAt(nn+1) == '=')
					{
						optype = 9;
						operatorlength = 2;
						operatorposition = nn;
						nn++;
					}
					else
					{
						// for <
						optype = 7;
						operatorposition = nn;
						operatorlength = 1;
					}
				}
				break;
			case '>':
				// for > or >=
				if (optype <= 10)
				{
					// for >=
					if (expression.charAt(nn+1) == '=')
					{
						optype = 10;
						operatorlength = 2;
						operatorposition = nn;
						nn++;
					}
					else
					{
						// for >
						optype = 8;
						operatorposition = nn;
						operatorlength = 1;
					}
				}
				break;
			case '=':
				if (optype <= 12)
				{
					optype = 11;
					operatorposition = nn;
					// for == (same as = here)...
					if (expression.charAt(nn+1) == '=')
					{
						operatorlength = 2;
						nn++;
					}
					else
						operatorlength = 1;
				}
				break;
			case '&':
				if (optype <= 13)
				{
					optype = 13;
					operatorposition = nn;
					// for && (same as & here)...
					if (expression.charAt(nn+1) == '&')
					{
						operatorlength = 2;
						nn++;
					}
					else
						operatorlength = 1;
				}
				break;
			case 'a':
				if ((nn>0) && ((strlen(expression)-nn) > 4))
				{
					if ((optype <= 13) && (expression.charAt(nn-1)==' ' || expression.charAt(nn-1)==')')
							&& lowerchar(expression.charAt(nn+1))=='n' && lowerchar(expression.charAt(nn+2))=='d'
							&& (expression.charAt(nn+3)==' ' || expression.charAt(nn+3)=='(') )
					{
						optype = 13;
						operatorposition = nn;
						operatorlength = 3;
						nn += 2; // will be 3 after n++...
					}
				}
				break;
			case '|':
				if (optype <= 14)
				{
					optype = 14;
					operatorposition = nn;
					// for || (same as | here)...
					if (expression.charAt(nn+1) == '|')
					{
						operatorlength = 2;
						nn++;
					}
					else
						operatorlength = 1;
				}
				break;
			case 'o':
				if ((nn>0) && ((strlen(expression)-nn) > 3))
				{
					if ((optype <= 14) && (expression.charAt(nn-1)==' ' || expression.charAt(nn-1)==')')
							&& lowerchar(expression.charAt(nn+1))=='r'
							&& (expression.charAt(nn+2)==' ' || expression.charAt(nn+2)=='(') )
					{
						optype = 14;
						operatorposition = nn;
						operatorlength = 2;
						nn += 1; // will be 2 after n++...
					}
				}
				break;      
			}
		}

		param1=""; param2=""; //param1.charAt(0] = (char)0; param2.charAt(0] = (char)0; // Is this needed?

		if (optype == -1) // No operator recognised.
		{
			// Transfer expression into param1 - minus leading spaces:
			int nn=0, nnn=0;
			for (nnn=0; (nnn < strlen(expression)) && expression.charAt(nnn)==' '; nnn++);
			for (nn=nnn; (nn < strlen(expression)); nn++)
				param1 += expression.charAt(nn); //param1.charAt(nn-nnn) = expression.charAt(nn);
			//param1.charAt(nn-nnn) = (char)0;

			// Remove trailing spaces:
			for (int nnnn=nn-nnn-1; nnnn>=0 && param1.charAt(nnnn)==' '; nnnn--)
				param1 = param1.substring(0, param1.length() - 1); //param1.charAt(nnnn) = (char)0;

			// Make param2 null:
			param2 = ""; //param2.charAt(0) = (char)0; // Is this needed?
		}
		else //if (optype != -1) // Operator recognised: + - * / (so far)
		{
			// Grab the first part of the expression string - param1 - minus leading spaces:
			int nn=0; int nnn=0;
			for (nnn=0; (nnn < operatorposition) && expression.charAt(nnn)==' '; nnn++);
			for (nn=nnn; (nn < operatorposition); nn++)
				param1 += expression.charAt(nn); //param1.charAt(nn-nnn) = expression.charAt(nn);
			//param1.charAt(nn-nnn) = (char)0;

			// Remove trailing spaces:
			for (int nnnn=nn-nnn-1; nnnn>=0 && param1.charAt(nnnn)==' '; nnnn--)
				param1 = param1.substring(0, param1.length() - 1); //param1.charAt(nnnn) = (char)0;

			// Grab the second part of the expression string - param2 - minus leading spaces:
			nn=0; nnn=operatorposition + operatorlength;
			// Operator length = 1 - fix this for longer operators...
			for (; (nnn < (int)strlen(expression)) && expression.charAt(nnn)==' '; nnn++); // removed nnn=nnn;
			for (nn=nnn; (nn < (int)strlen(expression)); nn++)
				param2 += expression.charAt(nn); //param2.charAt(nn-nnn) = expression.charAt(nn);
			//param2.charAt(nn-nnn) = (char)0;

			// Remove trailing spaces:
			for (int nnnn=nn-nnn-1; nnnn>=0 && param2.charAt(nnnn)==' '; nnnn--)
				param2 = param2.substring(0, param1.length() - 1); //param2.charAt(nnnn) = (char)0;

			// New - if using dot operator (optype == 0), make the second one into a string:
			if (optype == 0)
			{
				String t = "";
				t = t + ("\"") + param2 + ("\"");
				param2 = t; //strcpy(param2, t);
			}

			// Create a new instruction - insttype = 2 (operator/set temp)
			// Evaluate the expressions
			expret = evaluateexpression(param1, mytokens); //, numtemps); // Recursive.
			expret2 = evaluateexpression(param2, mytokens); //, numtemps); // Recursive.


			ret = new TokeniserReturn(); // In Java - now defined earlier!

			ret.insttype = 2; // Evaluate operator / set temp
			ret.instflag = optype; // Operator number: + - * / (1, 2, 3, 4)
			// Create new array:
			//ret.args[4]; ret.argtypes[4]; //?
			//ret.args = new int[4]; ret.argtypes = new int[4];
			ret.numargs = 3;
			ret.argtypes[1] = expret.exptype; ret.args[1] = expret.expdata;
			ret.argtypes[2] = expret2.exptype; ret.args[2] = expret2.expdata;
			//ret.argtype = expret.exptype;
			//ret.arg = expret.expdata;
			//ret.argtype2 = expret2.exptype;
			//ret.arg2 = expret2.expdata;

			// Get the new temp value:
			int tempvalue = numtemps;
			ret.argtypes[0] = 0; ret.args[0] = tempvalue;
			//ret.argtype3 = 0; // Constant - Is this necessary?     
			//ret.arg3 = tempvalue; // Put into new line - show which temp to set!

			// Shallow copy (???)
			mytokens.myparameters.add(ret);

			// Now put the appropriate temp into the original instruction line:
			data = tempvalue;
			numtemps++; //*numtemps = *numtemps + 1; //*numtemps++; // Zeroed between instructions
			exptype = 5; // Temp (not operator, 4)
		}

		//debug
		//System.out.print(param1+", ");
		//System.out.println(param2);

		// Now parse param1 and param2 (as appropriate) to determine if constant numbers or not
		int param1type = 0; // 0=constant number, 1=not
		if (param1.length() == 0) //if (param1.charAt(0) == (char)0)
			param1type = -1;
		for (int nn=0; (nn<strlen(param1)) && (param1type == 0); nn++)
		{
			int p = (int)param1.charAt(nn);
			if (!((p >= (int)'0') && (p <= (int)'9')) && (p!=(int)0) && (p!=(int)'.'))
			{
				param1type = 1;
			}
		}
		int param2type = 0; // 0=constant number, 1=not
		if (param2.length() == 0) //if (param2.charAt(0) == (char)0)
			param2type = -1;
		for (int nn=operatorposition + operatorlength + 1; (nn < strlen(expression)) && (param2type == 0); nn++) // Added: +1
		{
			int p = 0;
			if (param2.length() > (nn - (operatorposition+1)))
				p = (int)param2.charAt(nn - (operatorposition+1));
			if (!((p >= (int)'0') && (p <= (int)'9')) || (p==(int)0) || (p!=(int)'.'))
				param2type = 1;
		}

		// Constant numbers!
		if ((exptype != 4) && (exptype != 5) && (param1type == 0) && (param2type == -1))
		{
			exptype = 0; // Is this needed? - redundant...
			//char *end;
			data = strtod(param1); //, &end);
		}
		// Test for strings:
		else if ((param1.length() > 0) && (param1.charAt(0)=='\"') && (param1.charAt(strlen(param1)-1)=='\"'))
		{
			param1type = 3;
			if (exptype != 5)
			{
				// Now parse newexp1 recursively - returning the below temp.
				data = mytokens.mystrings.size();
				//char* temp = new char[strlen(param1)-2]; //?
				//for (int n=0; n<(strlen(param1)-2); n++)
				//    temp[n] = param1.charAt(n+1];
				//temp[strlen(param1)-2] = (char)0;
				//mytokens.mystrings.add(temp); //[data] = temp;
				mytokens.mystrings.add(substr(param1, 1, strlen(param1)-2));
				exptype = 3; // Strings!  
			}
		}
		else if (exptype != 5) // NOT for operators (2 parameters) - for param1 only:
		{
			// Now parse them - if they are not constants (0) - and find out if they are:
			// 1=Variable names, 2=Functions - Func(newexpression), 3=Strings ("'..'").
			// (To determine param1type and param2type)

			// Test for functions (opening brackets AND closing brackets):
			if (strlen(param1)>0) // added in Java
			{
				if (param1.charAt(strlen(param1)-1)==')')
				{
					for (int nn=0; (nn<(strlen(param1)-1)) && (exptype != 2); nn++)
					{
						if (param1.charAt(nn) == '(')
							exptype = 2;
						else
							bracketposition++;
					}
					if (exptype != 2)
						exptype = -1; // error - debug?
				}
			}
		}

		// For functions - get the new expressions: (Do only if not operator)
		// Find the appropriate function number here too...
		if (exptype == 2) // Function found
		{
			String functionname = ""; //char functionname[100]; //char *functionname = new char[bracketposition];
			for (int nn=0; nn<bracketposition; nn++)
				functionname += param1.charAt(nn);
			//functionname[bracketposition] = (char)0;

			String newexp1 = ""; //char newexp1[50]; // 50?
			for (int nn=bracketposition+1; (nn<strlen(param1)-1); nn++)
				newexp1 += param1.charAt(nn); //newexp1[nn-bracketposition-1] = param1.charAt(nn);

			// This part is unusual!
			newexp1 = newexp1.substring(0, param1.length() - bracketposition - 2); //newexp1[strlen(param1)-bracketposition-2] = (char)0; // Note: -2, NOT -1!

			// Create a new instruction - insttype = 3|4 (Run function + set temp | just set temp)
			// Evaluate the expression - expand this for multiple parameters...!!!!!!!!!!!!!!!!!!!!!

			ret.insttype = 3; // Run function / set temp (1 arg only so far)
			ret.instflag = 0; // Function number

			// Evaluate the expressions here:
			MultiExpressionReturn exprets = evaluatemultiexpressions(newexp1, mytokens); //, numtemps);
			ret.numargs = exprets.numexpressions + 1; // +1 added - don't forget temp number also!
			for (int n=0; n<exprets.numexpressions; n++)
			{
				// Note: [n+1], as [0] is for temp value. Function number is in instflag...
				ret.argtypes[n+1] = exprets.exp[n].exptype;
				ret.args[n+1] = exprets.exp[n].expdata;
			}

			// Create new array (removed):
			//ret.numargs = 3;
			//ret.argtypes[1] = expret.exptype; ret.args[1] = expret.expdata;

			// If simple parentheses - change insttype!!!
			if (param1.charAt(0) == '(')
			{
				ret.insttype = 4; // Simple parentheses - simply set temp to expression
			}
			else
			{
				// Check with function list:
				for (int nn=1; (nn<=g.numfunctions) && ((ret.insttype) == 3); nn++)
				{
					if (0 == strncmp(lower(g.textfunction[nn]), lower(functionname), 1000)) // Zero/false = match
					{
						ret.instflag = nn; // Get the function number!
					}
				}
				
				// True = no match:
				if (ret.instflag == 0)
				{
					// Check for defined arrays here:
					boolean foundarray = false;
					for (int nn=0; (nn<mytokens.myarraynames.size()) && ((ret.insttype) == 3); nn++)
					{
						if (0 == strncmp(lower(mytokens.myarraynames.get(nn)), lower(functionname), 1000)) // Zero/false = match
						{
							//System.out.println("DEBUG: Get array value here! "+mytokens.myarraynames.get(nn));
							foundarray = true;
							ret.instflag = 100; // Special function - get array value!
							// Cludge = add the array identifier to the END of the expression list:
							ret.numargs++;
							ret.argtypes[ret.numargs - 1] = 0;
							ret.args[ret.numargs - 1] = nn; // Array identifier
						}
					}
					
					// This appears to be deprecated...
					if (!foundarray)
					{
						// If the two strings don't match - treat as a pair of parentheses:
						ret.insttype = 4; // Simple parentheses - simply set temp to expression
						/// To replace the low-level stuff below - slower, but might reduce crashes (when using char[] not char*)
						String param1n = ""; // added for Java
						for (int blark=0; blark<bracketposition; blark++)
							for (int sht=0; sht<(strlen(param1)-1); sht++)
								param1n += param1.charAt(sht+1); // shuffle chars...
						param1 = param1n;
						//param1 += bracketposition; // Clever low-level stuff. (removed as now using char[] nor char*)... // Removed in Java
						
						//System.out.println("Debug: Apparently simply treat as a pair of parentheses?");
					}
				}
			}

			// Get the new temp value:
			int tempvalue = numtemps;
			ret.args[0] = tempvalue; ret.argtypes[0] = 0; // Constant - is this necessary?
			//ret.arg3 = tempvalue; // Put into new line - show which temp to set!
			//ret.argtype3 = 0; // Constant - Is this necessary?      

			// Shallow copy (??)
			mytokens.myparameters.add(ret);

			// Now put the appropriate temp into the original instruction line:
			data = tempvalue;
			numtemps++; //*numtemps = *numtemps + 1; //*numtemps++; // Zeroed between instructions.
			exptype = 5; // Temp (not function, 2)
		}

		// Variables at last...
		if ((param1type == 1) && (param2type == -1) && (exptype != 5)
				&& (exptype != 2) && (optype == -1))
		{
			// Now parse newexp1 recursively - returning the below temp.
			int tempvalue = mytokens.myvarnames.size();
			data = tempvalue;
			String tempstring=""; //char tempstring[200];
			//char *tempstring = new char[strlen(param1)];
			for (int n=0; n<strlen(param1); n++)
				tempstring += param1.charAt(n);
			//tempstring[strlen(param1)] = (char)0;

			// Check with variable list:
			int varmatch=0;
			for (int nn=0; (nn<(mytokens.myvarnames.size())); nn++)
			{
				if (0 == strncmp(lower(mytokens.myvarnames.get(nn)), lower(tempstring), 100)) // Zero/false = match
				{
					data = nn; // Get the function number!
					varmatch = 1;
				}
			}

			if (0 == varmatch)
			{
				mytokens.myvarnames.add(tempstring); //mytokens.myvarnames[data] = tempstring;
				//strcpy(mytokens.myvarnames[data], tempstring); //mytokens.myvarnames[data] = tempstring;
				data = mytokens.myvarnames.size()-1;
				//System.out.println("Add variable!"); //debug
			}
			//else
			//{
			//// NEW - Update to latest case:
			//mytokens.myvarnames[data] = new char[100]; //strlen(tempstring)];
			//strcpy(mytokens.myvarnames[data], tempstring); //mytokens.myvarnames[data] = tempstring;
			//}
			exptype = 1; // Variables!
		}

		ExpressionReturn expdata = new ExpressionReturn();

		expdata.exptype = exptype;
		expdata.expdata = data;

		return expdata;
	}
	MultiExpressionReturn evaluatemultiexpressions(String expressions, TheTokens mytokens) //, int numtemps)
	{
		MultiExpressionReturn multi = new MultiExpressionReturn();
		multi.numexpressions = 0;
		//multi.exp[0];

		String expr = ""; //char expr[300];
		int nn=0, s=0, bracketlevel=0, instring=0, foundcomma=0, explen=0;
		int firstbracket=-1, lastbracket=-1, numcharsinzerobracketlevel=0;

		// First, remove any trailing spaces:
		if (expressions.length()>0)
			while (expressions.charAt(0)==' ')
				expressions = expressions.substring(1);
		// Low-level stuff removed for Java: expressions++;

		explen = expressions.length();
		for (;;) //while (true)
		{
			for (; nn<explen; nn++) // nn=nn;
			{
				char c = expressions.charAt(nn);
				foundcomma = 0;
				switch (c)
				{
				case ',':
					if ((bracketlevel==0) && (instring==0))
					{
						expr = expr.substring(0, s); //expr[s] = (char)0;
						multi.exp[multi.numexpressions] = evaluateexpression(expr, mytokens); //, numtemps);
						multi.numexpressions++;
						s = 0;
						foundcomma = 1;
					}
					break;
				case '(':
					bracketlevel++;
					if (firstbracket == -1)
						firstbracket=nn;
					break;
				case ')':
					bracketlevel--;
					lastbracket = nn;
					break;
				case '"':
					instring = 1 - instring;
					if (bracketlevel == 0)
						numcharsinzerobracketlevel++;
					break;
				default:
					if (bracketlevel == 0)
						numcharsinzerobracketlevel++;
					break;
				}

				if (foundcomma == 0)
				{
					String expr2 = "";
					expr2 += expr.substring(0,s);
					expr2 += expressions.charAt(nn);
					expr2 += substr(expr, s+1); //expr2 += expr.substring(s+1, expr.length()-1);
					expr = expr2;
					//expr[s] = expressions.charAt(nn);
					s++;
				}
			}

			// Used for calling functions as instructions with parentheses: print("hello", "world");
			if (foundcomma == 0 && firstbracket>=0 && numcharsinzerobracketlevel==0 && bracketlevel==0)
			{
				// expr = expr.substring(0, s);//expr[s] = (char)0; printf("--%d--%s\n", numcharsinzerobracketlevel, expr); //debug
				s = 0;
				nn = firstbracket + 1;
				explen = lastbracket;
				firstbracket = -1;
				lastbracket = -1;
			}
			else
			{
				break;
			}
		}

		// Finally, evaluate the last one:
		if (foundcomma == 0)
		{
			expr = expr.substring(0, s); //expr[s] = (char)0;
			multi.exp[multi.numexpressions] = evaluateexpression(expr, mytokens); //, numtemps);
			multi.numexpressions++;
		}

		return multi;
	}
	TokeniserReturn tokeniser(String textline, //String[] textinstruction, // removed for Java
			int numinstructions, int numfunctions, int tn) //TheTokens mytokens) //, int numtemps)
	{
		//String temptext1, temptext2; //char temptext1[300], temptext2[300]; // was [200] for both
		//TheTokens mytokens = g.mytokens.get(tn); // was passed to method - removed in Java
		//printf("%s\n", textline); //debug

		// Instructions to numbers:
		// int instcode = 0; // not used

		// For parsing expressions:
		String expression; // = new String();

		// Is the line recognised as containing a valid instruction?
		boolean instrecognised=false;

		// First get the length:
		int linelength = textline.length();

		// Added to ensure return:
		TokeniserReturn ret; // = new TokeniserReturn(); // debug - removed initialisation for Java

		// For the list of instructions:
		for (int n=1; (n<= (numinstructions + numfunctions)) && (instrecognised==false); n++)
		{
			instrecognised = false;

			String testinstruction;
			if (n <= numinstructions)
				testinstruction = g.textinstruction[n];
			else
				testinstruction = g.textfunction[n - numinstructions];
			
			// For the instruction - 1 char at a time - first get the length:
			int instlength = testinstruction.length();
			
			//System.out.println("DEBUG: Now testing for \""+testinstruction.toLowerCase()+"\" against \""+(substr(textline, 0, instlength).toLowerCase())+"\"");

			// Then do the comparison:
			boolean compare=true;
			if (!(substr(textline, 0, instlength).toLowerCase()).equals(testinstruction.toLowerCase()))
				compare = false;

			// If an instruction is recognised:
			if (compare)
			{
				//System.out.println("DEBUG: Instruction recognised! "+testinstruction);
				// Now parse the expression:
				expression = ""; //expression.charAt(0]=(char)0;
				//int expposition=0;

				for (int nn=instlength; nn<linelength; nn++)
				{
					//// Check for comments (//) - needs updating for strings etc.
					//if ((textline[nn] == '/') && (textline[nn+1] == '/'))
					//    nn = linelength;

					//if ((textline[nn] != ' ') && (textline[nn] != (char)0)) // Spaces removed later...
					if (textline.charAt(nn) != (char)0)
					{
						expression += textline.charAt(nn);
						//expposition++;
					}
					//expression = expression.substring(0, expposition); //expression.charAt(expposition] = (char)0; // last character only?
				}

				// Create the return object:
				ret = new TokeniserReturn();
				if (n <= numinstructions)
				{
					ret.insttype = 1; // Instruction recognised
					ret.instflag = n; // Instruction number
				}
				else
				{
					ret.insttype = 50; // Call function as instruction
					ret.instflag = n - numinstructions;
				}

				// Evaluate the expressions here:
				MultiExpressionReturn expret = evaluatemultiexpressions(expression, g.mytokens.get(tn)); //, numtemps);
				ret.numargs = expret.numexpressions;
				for (int nn=0; nn<expret.numexpressions; nn++)
				{
					ret.argtypes[nn] = expret.exp[nn].exptype;
					ret.args[nn] = expret.exp[nn].expdata;
				}

				//struct ExpressionReturn expret = evaluateexpression(expression, mytokens); //, numtemps);
				//ret.argtypes[0] = expret.exptype; //ret.argtype = expret.exptype; // Is this necessary???
				//ret.args[0] = expret.expdata; //ret.arg = expret.expdata; // Temporary value array index
				//ret.numargs = 1; // Fix this...

				// Shallow copy
				g.mytokens.get(tn).myparameters.add(ret);

				// Curently return only temps.
				return ret;
			}
		}
		
		// TODO: Check for procedure call without Proc:
		//if (instrecognised == false)
		//{
		//}
		
		// If not an instruction - check for: =, +=, -=, /-, *=
		int arrayfound = 0;
		if (instrecognised == false)
		{
			int foundequals=0;
			int equalsposition=0;
			int bracketdepth=0;
			boolean inastring=false;
			int postype=0; // Possible type.
			
			for (int nn=0; (nn < linelength) && (foundequals == 0); nn++)
			{
				equalsposition = nn;
				postype=0;
				switch (textline.charAt(nn))
				{
				case '+': if (bracketdepth == 0 && !inastring) postype=6; break;
				case '-': if (bracketdepth == 0 && !inastring) postype=7; break;
				case '/': if (bracketdepth == 0 && !inastring) postype=8; break;
				case '*': if (bracketdepth == 0 && !inastring) postype=9; break;
				case '=': if (bracketdepth == 0 && !inastring) foundequals=5; break; // Standard var = ... // Why not postype = 5 - doesn't work...
				case '(': if (!inastring) { bracketdepth++; if (arrayfound == 0) arrayfound = nn; } break;
				case ')': if (!inastring) bracketdepth--; break;
				case '"': case '\'': inastring = !inastring; break;
				
				//case '[':
				//	foundequals=5; // FIX! - Array[n] = ... (TO DO) - need second 'equals position' too...
				//	break;
				
				default: break;
				}
				if (postype != 0)
				{
					switch (textline.charAt(nn+1))
					{
					case '=': if (bracketdepth == 0 && !inastring) foundequals = postype; break; // += etc. (TO DO)
					case '+': if (bracketdepth == 0 && !inastring) foundequals = 10; break;
					case '-': if (bracketdepth == 0 && !inastring) foundequals = 11; break;
					default:  foundequals = 1; break; // Not recognised!
					}
				}
			}

			if (foundequals >= 5)
			{
				// A variable is assigned.
				// Note: for += etc, equalsposition is at the '+' (later ++ or +=1 to the '=' position)

				// Check with variable list:
				String tempstring = ""; //char tempstring[200]; //char *tempstring = new char[equalsposition];
				int p = 0; // Final position of variable name
				for (p = equalsposition - 1; (p >= 0) && (textline.charAt(p) == ' '); p--);

				for (int n=0; n<=p; n++)
					tempstring += textline.charAt(n); //tempstring[n] = textline[n];
				//tempstring[p+1] = (char)0;
				
				String varname = "";
				String arrayexpressions = "";
				
				if (arrayfound > 0)
				{
					varname = tempstring.substring(0, arrayfound);
					arrayexpressions = tempstring.substring(arrayfound+1, tempstring.length() - 1);
				}
				else
				{
					varname = tempstring;
				}
				
				// As for variables in arguments:
				int varmatch=0;
				int data=0;
				if (arrayfound == 0)
				{
					//System.out.println("Debug: Possible variable name: "+varname);
					
					for (int nn=0; nn<(g.mytokens.get(tn).myvarnames.size()) && (varmatch == 0); nn++)
					{
						if (g.mytokens.get(tn).myvarnames.get(nn).toLowerCase().equals(varname.toLowerCase())) // Zero/false = match
						{
							data = nn; // Get the function number!
							varmatch = 1;
							break;
						}
					}
				}
				else
				{
					//System.out.println("Debug: Array name: "+varname+", arguments: "+arrayexpressions);
					
					for (int nn=0; nn<(g.mytokens.get(tn).myarraynames.size()) && (varmatch == 0); nn++)
					{
						if (g.mytokens.get(tn).myarraynames.get(nn).toLowerCase().equals(varname.toLowerCase())) // Zero/false = match
						{
							data = nn; // Get the function number!
							varmatch = 1;
							break;
						}
					}
				}

				// Check if the 'variable name' contains a dot (.):
				// Fix for arrays!
				String part1 = varname.toLowerCase();
				String part2  = "";
				int test = part1.indexOf(".", 0);
				int nn;
				if (test != -1)
				{
					part2 = substr(part1, test+1, 100);
					part1 = substr(part1, 0, test);

					// Remove spaces after part1:
					while (substr(part1, 0, 1).equals(" ")) part1 = substr(part1, 1, 100);
					// Remove spaces before and after part2:
					while (substr(part2, 0, 1).equals(" ")) part2 = substr(part2, 1, 100);
					while (substr(part2, part2.length()-1, 1).equals(" ")) part2 = substr(part2, 0, part2.length()-1);

					// For part1 - check to see if it is a current variable name. If not, add it.
					varmatch = 0;
					for (nn=0; nn<(int)(g.mytokens.get(tn).myvarnames.size()) && (varmatch == 0); nn++)
						if (part1.equals(g.mytokens.get(tn).myvarnames.get(nn).toLowerCase()))
							varmatch = 1;
					nn--;
					if (varmatch == 0)
					{
						nn = g.mytokens.get(tn).myvarnames.size();
						g.mytokens.get(tn).myvarnames.add(part1); //mytokens.myvarnames[nn] = part1;
					}
					data = nn;
				}
				// Is the variable name not already used?           
				else if (varmatch == 0)
				{
					// For non-array variables:
					if (arrayfound == 0)
					{
						data = g.mytokens.get(tn).myvarnames.size();
						g.mytokens.get(tn).myvarnames.add(varname); //mytokens.myvarnames[data] = varname; // new char[100];
						//strcpy(mytokens.myvarnames[data], varname);
					}
					// For arrays:
					else
					{
						data = g.mytokens.get(tn).myarraynames.size();
						g.mytokens.get(tn).myarraynames.add(varname); //mytokens.myarraynames[data] = varname; // new char[100];
						//strcpy(mytokens.myarraynames[data], varname);
					}
				}
				//else //?
				//{
				//// Update to latest case:
				//mytokens.myvarnames[data] = new char[100];
				//strcpy(mytokens.myvarnames[data], varname);
				//}
				test = (test != -1) ? 1 : 0;

				// Now parse the expression (as before - simplify?):
				expression = ""; //expression.charAt(0]=(char)0;
				//int expposition=0;

				// Move on for +=, etc:
				if (foundequals > 5)
					equalsposition++;

				// Add 10 to instruction number if used to assign brain.var= :
				if (test != 0)
					foundequals += 10;
				
				// Add 20 to instruction number if used to assign an array:
				if (arrayfound > 0)
					foundequals += 20;

				for (int nnn=equalsposition+1; nnn<linelength; nnn++)
				{
					// Check for comments (//) - needs updating for strings etc.
					if ((textline.charAt(nnn) == '/') && (textline.charAt(nnn+1) == '/'))
						nnn = linelength;

					//if ((textline[nnn] != ' ') && (textline[nnn] != (char)0)) // Spaces removed later...???
					if (textline.charAt(nnn) != (char)0)
					{
						expression += textline.charAt(nnn);
						//expposition++;
					}
					//expression.charAt(expposition] = (char)0; // last character only?
				}
				
				// Add the additional expressions for array access if required:
				if (arrayfound > 0)
				{
					expression += "," + arrayexpressions;
				}

				// Evaluate the expressions here:
				MultiExpressionReturn expret = evaluatemultiexpressions(expression, g.mytokens.get(tn)); //, numtemps);

				// Create the return type for the line:
				ret = new TokeniserReturn();
				ret.insttype = foundequals; // Variable assignment: = (5), += (6), -= (7), *= (8), /= (9)...
				ret.instflag = data; // Variable number
				
				//if (arrayfound > 0) System.out.println("TO DO: Assign array here!");
				
				// If not using a dot:
				if (test == 0)
				{
					for (int exp=0; exp<expret.numexpressions; exp++)
					{
						ret.argtypes[exp] = expret.exp[exp].exptype; //ret.argtype = expret.exptype;
						ret.args[exp] = expret.exp[exp].expdata; //ret.arg = expret.expdata;
					}
					ret.numargs = expret.numexpressions;
				}
				else
				{					
					// Add a string constant:
					g.mytokens.get(tn).mystrings.add(part2);
					ret.argtypes[0] = 3;
					ret.args[0] = g.mytokens.get(tn).mystrings.size()-1;
					
					// Added - allow for array access with a dot!
					for (int exp=0; exp<expret.numexpressions; exp++)
					{
						ret.argtypes[exp + 1] = expret.exp[exp].exptype; //ret.argtype = expret.exptype;
						ret.args[exp + 1] = expret.exp[exp].expdata; //ret.arg = expret.expdata;
					}
					ret.numargs = expret.numexpressions + 1;
				}

				// Shallow copy
				g.mytokens.get(tn).myparameters.add(ret);

				return ret;
			}
		}

		return null; //return ret; // debug - modified in Java
	}

	// Optimise (remove temp[a]=temp[b] and update as appropriate) here...
	TheTokens optimisetemps(TheTokens mytokens, int lastlines) // changed type from int to TheTokens for Java
	{
		if ((mytokens.myparameters.size()) >= (lastlines)) // or lastlines (?) - >= or > (???)
		{
			// Go thru all the new lines up to the last one:
			for (int n=(lastlines); n<(mytokens.myparameters.size()); n++)
			{
				// If line is temp[a]=x, then remove the line, shuffle up:
				//and substitute x below:
				if ((mytokens.myparameters.get(n).insttype) == 4) // Simple set temp
				{
					// The one argument (excluding temp #):
					double myarg = mytokens.myparameters.get(n).args[1];
					int myargtype = mytokens.myparameters.get(n).argtypes[1]; //argtype;
					//int mynumargs = mytokens.myparameters.get(n).numargs; // ADDED! //? // removed
					// Temp #:
					int mytemp = (int)mytokens.myparameters.get(n).args[0]; 
					// Shuffle up the lines:
					for (int nn=n; nn<(mytokens.myparameters.size() - 1); nn++)
						mytokens.myparameters.set(nn, mytokens.myparameters.get(nn+1));

					// Remove last instance from ArrayList:
					mytokens.myparameters.remove(mytokens.myparameters.size()-1);

					// Now scan all the following lines for temp #, and replace it with the above argument:
					for (int nn=n; nn<(mytokens.myparameters.size()); nn++)
					{
						//System.out.println("line "+nn+": Replace any occurance of temp["+mytemp+"] with temp["+myarg+"]"); //debug
						//if (((mytokens.myparameters.get(nn).argtype) == 5) && ((mytokens.myparameters.get(nn).arg) == mytemp))
						for (int argnum=0; argnum<(mytokens.myparameters.get(nn).numargs); argnum++) // for all args!
							if (((mytokens.myparameters.get(nn).argtypes[argnum]) == 5)
									&& ((mytokens.myparameters.get(nn).args[argnum]) == mytemp))
							{
								mytokens.myparameters.get(nn).argtypes[argnum] = myargtype;
								mytokens.myparameters.get(nn).args[argnum] = myarg;
								//mytokens.myparameters.get(nn).numargs = mynumargs;
							}
					}
					n--; // Added - fixes bug with ((expression))...
				}
			}
		}
		//return 0;
		return mytokens; // modified in Java
	}

	// Removed for Java:
	ArrayList <String> addextravarnames(ArrayList <String> myvarnames)
	{
		myvarnames.add("Name");
		myvarnames.add("Description");
		myvarnames.add("Portable");
		myvarnames.add("Examine");
		myvarnames.add("Use");
		myvarnames.add("UseWith");  // Was originally UseWith, then UsedWith
		myvarnames.add("Take");
		myvarnames.add("InInventory");
		return myvarnames;
	}
	
	// Added to parse Dim statements:
	ArrayList<String> parsedim(String input)
	{
		ArrayList<String> individualstatements = new ArrayList<String>();
		ArrayList<String> output = new ArrayList<String>();
		individualstatements.add("");
		int bracketlevel=0;
		boolean instrings=false;
		int whichstatement=0;
		
		// First it is necessary to split by commas - ignoring commas inside brackets and ""
		// Start at 4 for now - assume space after "Dim":
		for (int n=4; n<input.length(); n++)
		{
			char c = input.charAt(n);
			if (c == '(')
				bracketlevel++;
			else if (c == ')')
				bracketlevel--;
			else if (c == '"')
				instrings = !instrings;
			
			if ((c == ',') && (bracketlevel == 0) && (!instrings))
			{				
				// Check for correct closing bracket here:
				if (individualstatements.get(whichstatement).charAt(individualstatements.get(whichstatement).length()-1) != ')')
				{
					System.err.println("Syntax error - array dimensioned without closing bracket!");
				}
				whichstatement++;
				individualstatements.add("");
			}
			else
			{
				// Add the character if not a space outside of a string:
				if (instrings || (c != ' '))
				{
					individualstatements.set(whichstatement, individualstatements.get(whichstatement) + c);
				}
			}
		}
		
		// Add the final split individual dim statement:
		whichstatement++;
		
		// Now, split each "individual statement" into array name and multi-expression:
		for (int s=0; s<whichstatement; s++)
		{
			// Find the opening bracket, '('
			// (We know there is a closing bracket at the end due to the previous test)
			int openingbracket = individualstatements.get(s).indexOf('(');
			// TODO - syntax error checking here - for missing opening bracket.
			
			// Grab the array name:
			output.add(individualstatements.get(s).substring(0, openingbracket));
			
			// Grab the multi-expression to dimension the array:
			output.add(individualstatements.get(s).substring(openingbracket+1, individualstatements.get(s).length()-1));
		}
		
		return output;
	}
	
	// Added for Procedure arguments - split a string by commas, and remove excess spaces:
	ArrayList<String> splitstringbycommas(String input)
	{
		ArrayList<String> output = new ArrayList<String>();
		int index=0;
		boolean started=false;
		
		// First count the number of commas:
		int numargs = 1;
		for (int p=0; p<input.length(); p++)
			if (input.charAt(p) == ',')
				numargs++;
		
		// Create the output string array (now ArrayList):
		//output = new String[numargs];
		output.add(""); //output[0] = "";
		
		// Load the output into the array, ignoring initial spaces:
		for (int p=0; p<input.length(); p++)
		{
			if ((started || (input.charAt(p) != ' ')) && input.charAt(p) != ',')
			{
				output.set(index, output.get(index) + input.charAt(p));
				started = true;
			}
			else if (input.charAt(p) == ',')
			{
				index++;
				output.add(""); //output[index] = "";
				started = false;
			}
		}
		
		// Finally strip any trailing spaces:
		for (int i=0; i<numargs; i++)
		{
			while (output.get(i).charAt(output.get(i).length() - 1) == ' ')
				output.set(i, output.get(i).substring(0, output.get(i).length() - 1));
		}
		
		// Debug: Print output:
		//System.out.println("Initial string: "+input);
		//System.out.println("Output string array:");
		//for (int i=0; i<numargs; i++)
		//	System.out.println(output[i]+";");
		
		return output;
	}

	int evaluateline(String textline, int tn)
	{
		String testline = "";;
		String testline2 = "";
		//String temptext = ""; //char* temptext = new char[300];
		//String temptext2 = ""; //char* temptext2 = new char[300];

		//TheTokens mytokens = g.mytokens.get(tn); // removed for Java
		//ArrayList <TheTokens> tokens = g.mytokens; // removed for Java
		// Instruction parser:
		// For each code line:
		//TokeniserReturn ret; // = new tokeniserreturn(); // moved for Java
		//tokeniserreturn* ret2;

		//int numtemps = 0; // moved to global as Java lacks pointers!
		numtemps = 0;

		testline = textline; //strcpy(testline, textline);

		// Reset the temporary variable counter:
		//numtemps = 0;
		// Get the number of lines before evaluating the line:
		int lastlines = g.mytokens.get(tn).myparameters.size();

		// New: Remove any initial spaces or tabs (indent):
		if (textline.length() > 0) // Added in Java
			while (testline.charAt(0)==' ' || testline.charAt(0)=='\t')
				testline = testline.substring(1);
		//for (int n=0; n<(testline.length()); n++)
		//testline[n] = testline[n+1];  
		//   testline = testline + 1; // low-level stuff - slower alternative above...

		// Check for comments (//) - and check if not inside strings:
		int instring = 0;
		for (int n=0; n<testline.length(); n++)
		{
			if (testline.charAt(n) == '"')
				instring = 1-instring;
			else if ((testline.charAt(n) == '/') && (testline.charAt(n+1) =='/') && (instring == 0))
			{
				testline = testline.substring(0, n); //testline[n] = (char)0; //linelength=n;
				break;
			}
		}

		// New: Remove any leading spaces, tabs, colons or semicolons (added - 13):
		if (testline.length() > 0) 
			while (testline.charAt(strlen(testline)-1)==' ' || testline.charAt(strlen(testline)-1)=='\t' 
			|| testline.charAt(strlen(testline)-1)==':' || testline.charAt(strlen(testline)-1)==';' || testline.charAt(strlen(testline)-1)==13 )
			{
				testline = testline.substring(0, testline.length() - 1); //testline[strlen(testline)-1]=(char)0;
				if (testline.length() == 0)
					break;
			}

		// Now check for colons or semicolons (: ;):
		instring = 0;
		for (int n=0; n<(int)testline.length(); n++)
		{
			if (testline.charAt(n) == '"')
				instring = 1-instring;
			else if ((testline.charAt(n) == ':' || testline.charAt(n) == ';' || testline.charAt(n) == '{' || testline.charAt(n) == '}') && (instring == 0))
			{
				int o=0;
				// Cut the string before, and tokenise it:
				if (n>0)
				{
					// Check for spaces before the :;{} :
					for (int nn=n-1; nn>=0 && testline.charAt(nn)==' '; nn--)
						o++;
					testline2 = "";
					for (int nn=0; nn<(n-o); nn++)
						testline2 += testline.charAt(nn);
					//testline2[n-o] = (char)0;

					// Check for brain ..., end brain:
					if ((strncmp(lower(testline2), "brain ", 6) == 0)
							|| (strncmp(lower(testline2), "adventure ", 10) == 0))
					{
						// Grab the brain name:
						String temp = "";
						//char* temp = new char[100];
						int count = 6;
						if (strncmp(lower(testline2), "adventure ", 10) == 0)
							count = 10;

						for (; (count < (int)strlen(testline2)) && (testline2.charAt(count)==' '); count++);
						//int count2 = count;

						// New: Don't include any spaces or [ at end of line:
						int findend = strlen(testline2) - 1;
						for (; (findend > 0) && ((testline2.charAt(findend)==' ') || (testline2.charAt(findend)=='[') || (testline2.charAt(findend)==13)); findend--);  

						for (; count <= findend; count++)
							temp += testline2.charAt(count);   
						//temp[count - count2] = (char)0;

						if (strcmp(lower(temp), "master") == 0)
						{
							tn = 0;
							//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // removed for Java
						}
						else
						{
							// Add another brain:
							tn = g.mytokens.size(); System.out.println("This shouldn't happen!");
							g.mytokens = inittokens(g.mytokens, tn, temp); // Modified for Java
							//mytokens[tn] = new thetokens(temp);
							//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // removed for Java
							// Add extra variables here (removed in Java):
							//mytokens.myvarnames = addextravarnames(mytokens.myvarnames); // removed
						}
					}
					else if ((strncmp(lower(testline2), "endbrain", 8) == 0)
							|| (strncmp(lower(testline2), "];", 2) == 0))
					{
						// never ran?
						// Remove the preceding "}" instruction if appropriate:
						if ((strncmp(lower(testline2), "];", 2) == 0))
						{
							// Remove last instance from ArrayList:
							g.mytokens.get(tn).myparameters.remove(g.mytokens.get(tn).myparameters.size()-1);
						}
						tn = 0;
						//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // removed for Java
					}
					else
					{
						// Tokenise the line:
						//System.out.println("DEBUG: Trying to tokenise line "+testline2+"..."); // debug
						tokeniser(testline2, g.numinstructions, g.numfunctions, tn); // g.mytokens.get(tn)); //, numtemps); // removed param 2 for Java
						
						// Optimise (remove temp[a]=temp[b] and update as appropriate) here...
						if (OPTIMISE)
							g.mytokens.set(tn, optimisetemps(g.mytokens.get(tn), lastlines)); //optimisetemps(g.mytokens.get(tn), lastlines); // modified in Java - different in C++
					}
				}

				// Now check for braces { } - fix this and combine with above...
				if (testline.charAt(n) == '{' || ((testline.charAt(n) == '}') && (testline.charAt(n + 1) != ';')))
				{
					// Create the return type for the line:
					TokeniserReturn ret = new TokeniserReturn();
					ret.insttype = 1; // Standard instructon
					ret.instflag = 10 + ((testline.charAt(n) == '}') ? 1 : 0); // 10={, 11=}
					ret.argtypes[0] = -1; // 0 shows in dumparg, -1 doesn't. (??????)
					ret.args[0] = 0;
					ret.numargs = 1; // Added - fixes bug with optimisetemps...

					// Shallow copy
					g.mytokens.get(tn).myparameters.add(ret);
				}

				testline = testline.substring(n+1); //testline += n+1; // low-level stuff - removed in Java
				// low-level space removal (removed in Java):
				while (testline.charAt(0) == ' ')
					testline = testline.substring(1); //testline++;
				n = -1; // as 1 is added (?)
				// (bug note: infinite loop without removing trailing colons/semicolons above...)
			}
		}
		
		
		// Added: Check for Procedure..., End Proc:
		boolean procfound = false;
		boolean dimfound = false;
		if (strncmp(lower(testline), "procedure ", 10) == 0)
		{
			// Added - scan for [] for passing arguments:
			int foundparameter = -1; int foundparameter2 = -1;
			for (int temp=10; temp<testline.length(); temp++)
			{
				if (testline.charAt(temp) == '[')
				{
					foundparameter = temp;
					break;
				}
			}
			if (foundparameter != -1)
			{
				for (int temp=(testline.length()-1); temp>foundparameter; temp--)
				{
					if (testline.charAt(temp) == ']')
					{
						foundparameter2 = temp;
						break;
					}
				}
				if (foundparameter2 == -1)
				{
					System.err.println("Syntax error: Procedure ...[ without closing ']' !");
				}
			}
			
			// First grab the procedure's name:
			String procname = "";
			int count = 10;
			// Ignore initial spaces:
			for (; (count < (int)strlen(testline)) && (testline.charAt(count)==' '); count++);
			
			// Don't include any spaces or [ at end of line:
			// Added - ignore anything after [ inclusive if Proc is called with parameters [...]:
			int findend;
			if (foundparameter == -1)
				findend = strlen(testline) - 1;
			else
				findend = foundparameter - 1;
			
			for (; (findend > 0) && ((testline.charAt(findend)==' ') || (testline.charAt(findend)=='[')  || (testline.charAt(findend)==13)); findend--);           
			
			// Now grab the procedure's name:
			for (; count <= findend; count++)
				procname += testline.charAt(count);
			
			// Add the procedure name to the list of procedure strings:
			g.mytokens.get(tn).myprocedures.add(procname.toLowerCase());
			
			// Add instruction here, as in tokeniser()
			TokeniserReturn ret = new TokeniserReturn();
			ret.insttype = 1; // Instruction recognised
			ret.instflag = 19; // Instruction number
			
			ret.numargs = 3;
			// Procedure number:
			ret.args[0] = g.mytokens.get(tn).myprocedures.size() - 1;
			ret.argtypes[0] = 0;
			// Used to store the End Proc position (later):
			ret.args[1] = 0;
			ret.argtypes[1] = 0;
			// Used to store the number of arguments in the procedure definition:
			ret.args[2] = 0;
			ret.argtypes[2] = 0;
			
			// Grab the procedure arguments string if enclosed in []:
			if ((foundparameter != -1) && (foundparameter2 != -1))
			{
				if ((foundparameter2-foundparameter-1) <= 0 )
				{
					System.err.println("Syntax error: Procedure ...[] without defined arguments!");
				}
				else
				{
					String arguments = testline.substring(foundparameter + 1, foundparameter2);
					//System.out.println("TO DO - argument support: Procedure "+procname+"["+arguments+"]"); //+", size="+(foundparameter2-foundparameter-1));
					
					// Split string by commas:
					ArrayList<String> varnames = splitstringbycommas(arguments);
					
					//for (int i=0; i<varnames.length; i++)
					//	System.out.println(varnames[i]+";");
					
					// Add the required number of arguments to the procedure definition:
					ret.args[2] = varnames.size();
					ret.numargs += varnames.size();
					
					// Here process the variable names in the procedure definition:
					for (int i=0; i<varnames.size(); i++)
					{
						// Check to see if it is a current variable name.
						int varnum = -1;
						int nn;
						for (nn=0; nn<(int)(g.mytokens.get(tn).myvarnames.size()) && (varnum == -1); nn++)
							if (varnames.get(i).equals(g.mytokens.get(tn).myvarnames.get(nn).toLowerCase()))
								varnum = nn;
						
						// If not, add it.
						if (varnum == -1)
						{
							varnum = g.mytokens.get(tn).myvarnames.size();
							g.mytokens.get(tn).myvarnames.add(varnames.get(i));
							//System.out.println("DEBUG: Added new variable #"+varnum+": "+varnames[i]+";");
						}
						//else
						//{
						//	System.out.println("DEBUG: Variable found #"+varnum+": "+varnames[i]+";");
						//}
						
						// Now add the variable index to the procedure's list of arguments, offset 3:
						ret.argtypes[i+3]=0;
						ret.args[i+3]=varnum;
					}
				}
			}
			
			// Add the procedure definition to the list of instructions here:
			g.mytokens.get(tn).myparameters.add(ret);
			
			// Add the procedure position to the list of procedure positions:
			int procedureposition = g.mytokens.get(tn).myparameters.size() - 1;
			g.mytokens.get(tn).myprocedurepositions.add(procedureposition);
			
			// Debug:
			//System.out.println("Procedure #"+procname+"# ("+ret.args[0]+"), position: "+procedureposition);

			procfound = true;
		}
		else if (strncmp(lower(testline), "end proc", 8) == 0)
		{
			// Added - scan for [] for returning an argument:
			int foundparameter = -1; int foundparameter2 = -1;
			for (int temp=8; temp<testline.length(); temp++)
			{
				if (testline.charAt(temp) == '[')
				{
					foundparameter = temp;
					break;
				}
			}
			if (foundparameter != -1)
			{
				for (int temp=(testline.length()-1); temp>foundparameter; temp--)
				{
					if (testline.charAt(temp) == ']')
					{
						foundparameter2 = temp;
						break;
					}
				}
				if (foundparameter2 == -1)
				{
					System.err.println("Syntax error: End Proc[ without closing ']' !");
				}
			}
		
			// Add instruction here, as in tokeniser()
			TokeniserReturn ret = new TokeniserReturn();
			ret.insttype = 1; // Instruction recognised
			ret.instflag = 20; // Instruction number
			
			// Grab the expression string if enclosed in []:
			if ((foundparameter != -1) && (foundparameter2 != -1))
			{
				if ((foundparameter2-foundparameter-1) <= 0 )
				{
					System.err.println("Syntax error: End Proc[] without argument!");
				}
				else
				{
					String expression = testline.substring(foundparameter + 1, foundparameter2);
					//System.out.println("Debug: End Proc["+expression+"], size="+(foundparameter2 - foundparameter - 1));
					
					// Parse the expression here and add to the program:
					// Evaluate the expressions here:
					MultiExpressionReturn expret = evaluatemultiexpressions(expression, g.mytokens.get(tn)); //, numtemps);
					if (expret.numexpressions > 1)
					{
						System.err.println("Syntax error: Too many arguments for End Proc[]!");
					}
					ret.numargs = expret.numexpressions;
					for (int nn=0; nn<expret.numexpressions; nn++)
					{
						ret.argtypes[nn] = expret.exp[nn].exptype;
						ret.args[nn] = expret.exp[nn].expdata;
					}
				}
			}
			else
			{
				ret.numargs = 0;
			}
			
			g.mytokens.get(tn).myparameters.add(ret);
			
			// Now set the End Proc position in the previous Procedure call (no nested procedures allowed):
			int procnum = g.mytokens.get(tn).myprocedurepositions.size() - 1;
			int procpos = g.mytokens.get(tn).myprocedurepositions.get(procnum);
			int endprocpos = g.mytokens.get(tn).myparameters.size() - 1;
			g.mytokens.get(tn).myparameters.get(procpos).args[1] = endprocpos;
			
			// Debug:
			//System.out.println("End Proc - position:"+(g.mytokens.get(tn).myparameters.size()-1));

			procfound = true;
		}
		else if (strncmp(lower(testline), "proc ", 5) == 0)
		{
			// Added - scan for [] for passing arguments:
			int foundparameter = -1; int foundparameter2 = -1;
			for (int temp=5; temp<testline.length(); temp++)
			{
				if (testline.charAt(temp) == '[')
				{
					foundparameter = temp;
					break;
				}
			}
			if (foundparameter != -1)
			{
				for (int temp=(testline.length()-1); temp>foundparameter; temp--)
				{
					if (testline.charAt(temp) == ']')
					{
						foundparameter2 = temp;
						break;
					}
				}
				if (foundparameter2 == -1)
				{
					System.err.println("Syntax error: Proc ...[ without closing ']' !");
				}
			}
			
			// Grab the procedure's name:
			String procname = "";
			int count = 5;
			// Ignore initial spaces:
			for (; (count < (int)strlen(testline)) && (testline.charAt(count)==' '); count++);
			
			// Don't include any spaces or [ at end of line:
			// Added - ignore anything after [ inclusive if Proc is called with parameters [...]:
			int findend;
			if (foundparameter == -1)
				findend = strlen(testline) - 1;
			else
				findend = foundparameter - 1;
			
			for (; (findend > 0) && ((testline.charAt(findend)==' ') || (testline.charAt(findend)=='[')  || (testline.charAt(findend)==13)); findend--);           

			// Now grab the procedure's name:
			for (; count <= findend; count++)
				procname += testline.charAt(count);
			
			// Add the procedure call name to the list of procedure call strings:
			g.mytokens.get(tn).myprocedurecalls.add(procname.toLowerCase());
			
			// Add instruction here, as in tokeniser()
			TokeniserReturn ret = new TokeniserReturn();
			ret.insttype = 1; // Instruction recognised
			ret.instflag = 21; // Instruction number
			
			
			// Grab the expression string if enclosed in []:
			if ((foundparameter != -1) && (foundparameter2 != -1))
			{
				if ((foundparameter2-foundparameter-1) <= 0 )
				{
					System.err.println("Syntax error: Proc ...[] without argument!");
					ret.numargs = 1;
				}
				else
				{
					String expression = testline.substring(foundparameter + 1, foundparameter2);
					//System.out.println("Debug: Proc["+expression+"], size="+(foundparameter2 - foundparameter - 1));
					
					// Parse the expression here and add to the program:
					// Evaluate the expressions here:
					MultiExpressionReturn expret = evaluatemultiexpressions(expression, g.mytokens.get(tn)); //, numtemps);
					
					// Added: +1, since first argument is reserved for the procedure call number (later the actual procedure number):
					ret.numargs = expret.numexpressions + 1;
					for (int nn=0; nn<expret.numexpressions; nn++)
					{
						ret.argtypes[nn+1] = expret.exp[nn].exptype;
						ret.args[nn+1] = expret.exp[nn].expdata;
					}
				}
			}
			else
			{
				ret.numargs = 1;
			}
			
			// Initial argument: Procedure call number (NOT Procedure number at this stage!)
			ret.args[0] = g.mytokens.get(tn).myprocedurecalls.size() - 1;
			ret.argtypes[0] = 0;
			
			// Add the Proc call to the list of instructions in the program:
			g.mytokens.get(tn).myparameters.add(ret);
			
			// Debug:
			//System.out.println("Proc #"+procname+"# ("+ret.args[0]+"), position: "+(g.mytokens.get(tn).myparameters.size()-1));
			
			procfound = true;
		}
		// Now parse array declarations (Dim):
		else if (strncmp(lower(testline), "dim ", 4) == 0)
		{
			ArrayList<String> arrays = parsedim(testline);
			
			// Each even string is the array name, the following string is the multi-expressions to dimension that array.
			// Create a new statement for each.
			
			for (int s=0; s<arrays.size()/2; s++)
			{
				// Add instruction here, as in tokeniser()
				TokeniserReturn ret = new TokeniserReturn();
				ret.insttype = 1; // Instruction recognised
				ret.instflag = 23; // Instruction number (Dim)
				
				String arrayname = arrays.get(s*2);
				String arraymultiexpression = arrays.get((s*2)+1);
				
				// Add the array name to the list of array names (TODO: Check for array already dimensioned!):
				g.mytokens.get(tn).myarraynames.add(arrayname.toLowerCase());
				
				// Parse the multi-expression here:
				MultiExpressionReturn expret = evaluatemultiexpressions(arraymultiexpression, g.mytokens.get(tn));
				
				// Added: +2, since first argument is reserved for the array number, second for numargs:
				ret.numargs = expret.numexpressions + 2;
				for (int nn=0; nn<expret.numexpressions; nn++)
				{
					ret.argtypes[nn+2] = expret.exp[nn].exptype;
					ret.args[nn+2] = expret.exp[nn].expdata;
				}
				
				// Initial argument: Array number:
				ret.args[0] = g.mytokens.get(tn).myarraynames.size() - 1;
				ret.argtypes[0] = 0;
				
				// Second argument: Number of arguments (=dimensions):
				ret.args[1] = expret.numexpressions;
				ret.argtypes[1] = 0;
				
				// Add the Dim (split to each definition) to the list of instructions in the program:
				g.mytokens.get(tn).myparameters.add(ret);
			}
			
			// Flag it to not pass the Dim instruction again:
			dimfound = true;
			
			// Debug - print out each statement:
			/*for (int s=0; s<arrays.size()/2; s++)
			{
				String arrayname = arrays.get(s*2);
				String arraymultiexpression = arrays.get((s*2)+1);
				
				System.out.print("Array name: ");
				System.out.print("#"+arrayname+"#");
				System.out.print(", array multi-expression: ");
				System.out.println("#"+arraymultiexpression+"#");
			}*/
		}
		
		
		
		// Check for brain ..., end brain:
		boolean test = strncmp(lower(testline), "brain ", 6) == 0;
		test = test || strncmp(lower(testline), "adventure ", 10) == 0;

		//if ( (strncmp(lower(testline, temptext), "brain ", 6) == 0)
		//  || (strncmp(lower(testline, temptext2), "adventure ", 10) == 0) )
		
		if (test)
		{
			// Grab the brain name:
			String temp = "";

			int count = 6;
			if (strncmp(lower(testline), "adventure ", 10) == 0)
				count = 10;

			for (; (count < (int)strlen(testline)) && (testline.charAt(count)==' '); count++);
			//int count2 = count;

			// New: Don't include any spaces or [ at end of line:
			int findend = strlen(testline) - 1;
			for (; (findend > 0) && ((testline.charAt(findend)==' ') || (testline.charAt(findend)=='[')  || (testline.charAt(findend)==13)); findend--);           

			for (; count <= findend; count++)
				temp += testline.charAt(count);

			if (strcmp(lower(temp), "master") == 0)
			{
				tn = 0;
				//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // line removed for Java
			}
			else
			{
				// Add another brain:
				tn = g.mytokens.size();
				g.mytokens = inittokens(g.mytokens, tn, temp); // modified for Java
				//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // line removed for Java
				// Add extra variables here (removed in Java):
				//mytokens.myvarnames = addextravarnames(mytokens.myvarnames); // removed
			}
		}
		//else if (strncmp(lower(testline, temptext), "endbrain", 8) == 0)
		else
		{
			//lower(testline2, temptext);
			test = strncmp(lowers(testline2), "endbrain", 8) == 0;
			test = test || (strncmp(testline2, "];", 2) == 0);
			//if ( (strncmp(lower(testline2, temptext), "endbrain", 8) == 0)
			//       || (strncmp(lower(testline2, temptext2), "];", 2) == 0) )

			if (test)
			{
				// Remove the preceding "}" instruction if appropriate:
				if ((strncmp(testline2, "];", 2) == 0))
				{
					// Remove last instance from ArrayList:
					g.mytokens.get(tn).myparameters.remove(g.mytokens.get(tn).myparameters.size()-1);
				}

				tn = 0;
				//g.mytokens.get(tn) = g.mytokens.get(tn); //mytokens = &tokens[tn]; // line removed for Java
			}
			else if ((!procfound) && (!dimfound)) // added - don't process Procedure/End Proc/Proc or Dim here.
			{
				// Tokenise the line:
				//System.out.println("DEBUG: Trying to tokenise line "+testline+"..."); // debug
				tokeniser(testline, g.numinstructions, g.numfunctions, tn); //g.mytokens.get(tn)); //, numtemps); // removed param 2 in Java
				// Optimise (remove temp[a]=temp[b] and update as appropriate) here... - removed a long time ago
				//if (OPTIMISE)
				//	g.mytokens.set(tn, optimisetemps(g.mytokens.get(tn), lastlines)); //optimisetemps(g.mytokens.get(tn), lastlines); // modified in Java
			}
		}

		//delete[] testline;
		//delete[] testline2;
		//delete[] temptext;
		//delete[] temptext2;
		return tn;
	}

	public int evaluateinstructions(ArrayList <String> textline) //, ArrayList <thetokens> tokens)
	{
		String temptext = "";
		//String temptext2 = ""; // removed - not used in Java
		
		//ArrayList <TheTokens> tokens = g.mytokens; // removed for Java

		// Instruction parser:
		// For each code line:
		//TokeniserReturn ret; // = new tokeniserreturn(); //? // removed for Java
		TokeniserReturn ret2; // = new tokeniserreturn(); //?

		//int numtemps;

		// Initialise brain number:
		int tn = 0;
		//TheTokens mytokens; // = g.mytokens.get(tn); // removed for Java
		for (int l=0; l<textline.size(); l++)
		{
			tn = evaluateline(textline.get(l), tn);
		}
		
		// Now add jump-points for while..wend, if..endif ...
		// Initiate the array for nested jump-points:
		int[] jumppoint = new int[100];
		int[] jumppoint2 = new int[100];
		int jumplevel, tt; //, lastinsttype, lastinstflag; // removed - not used
		for (tn=0; tn<g.mytokens.size(); tn++)
		{
			//mytokens = g.mytokens.get(tn); // removed for Java
			jumplevel = 0;
			//lastinsttype = 0; lastinstflag=0; // removed - not used
			for (int l=0; l<(g.mytokens.get(tn).myparameters.size()); l++)
			{
				//ret = mytokens.myparameters.get(l); // removed for Java

				// Finally, evaluate the instruction itself:
				if ((g.mytokens.get(tn).myparameters.get(l).insttype) == 1) // Standard Instruction
				{
					switch(g.mytokens.get(tn).myparameters.get(l).instflag)
					{
					case 1:
						// Else If
						//System.out.println("DEBUG: Trying to process ELSE IF..."); // debug
						if (l>0)
						{
							g.mytokens.get(tn).myparameters.get(l).numargs = 3; // added
							g.mytokens.get(tn).myparameters.get(l).args[2] = 0; // added

							// Find the first temp line (if any) before the Else If:
							tt = l;
							while (tt > 0)
							{
								int ins = g.mytokens.get(tn).myparameters.get(tt-1).insttype;
								if (tt>0 && (ins>=2 && ins<=4))
									tt--;
								else
									break;
							}

							// Check if the last instruction BEFORE ANY TEMPS is an endif, i.e. }:
							int test = 0;
							if ((g.mytokens.get(tn).myparameters.get(tt-1).insttype == 1) && (g.mytokens.get(tn).myparameters.get(tt-1).instflag == 7))
							{
								// If so, check the arg[2] of the If on jumplevel (NOT jumplevel-1) to see if it has braces:
								if (g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel]).args[2] != 0)
									test = 1;
							}

							if (test != 0)
							{
								// If braces:
								// Remove the "endif" or "}" before the Else If:
								g.mytokens.get(tn).myparameters.remove(tt - 1);
								// Correct the jump-point for (e.g. If):
								g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel]).args[1] = tt - 1;
								// Correct the current line number (l):
								l--;
								// Increase the jumplevel:
								jumplevel++;
							}
							else
							{
								// If no braces:
								// Set the jump-point for (e.g. If) (arg 2) to the first Temp line (if any) before the Else If:         
								g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel-1]).args[1] = tt;
								//mytokens.myparameters.get(jumppoint[jumplevel-1]).numargs = 2; // removed
							}
							jumppoint[jumplevel - 1] = l;
						}
						break;
					case 2:
						// Else
						//System.out.println("DEBUG: Trying to process ELSE..."); // debug
						g.mytokens.get(tn).myparameters.get(l).numargs = 3; // added
						g.mytokens.get(tn).myparameters.get(l).args[2] = 0; // added
						if (l>0)
						{
							// Check if the last instruction is an endif, i.e. }:
							int test = 0;
							if ((g.mytokens.get(tn).myparameters.get(l-1).insttype == 1) && (g.mytokens.get(tn).myparameters.get(l-1).instflag == 7))
							{
								// If so, check the arg[2] of the If on jumplevel (NOT jumplevel-1) to see if it has braces:
								if (g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel]).args[2] != 0)
									test = 1;
							}

							if (test != 0)
							{
								// If braces:
								// Remove the "endif" or "}" before the Else:
								g.mytokens.get(tn).myparameters.remove(l - 1);
								// Correct the jump-point for (e.g. If):
								g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel]).args[1] = l - 1;
								// Correct the current line number (l):
								l--;
								// Increase the jumplevel:
								jumplevel++;
							}
							else // recently added in Java
							{
								// As for Endif (if no braces):
								// Set the jump-point for (e.g. If) (arg 2) to the Else line:
								g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel-1]).args[1] = l;
								//mytokens.myparameters.get(jumppoint[jumplevel-1]).numargs = 2; // removed
							}
							jumppoint[jumplevel - 1] = l; // recently added in Java
						}
						break;
					case 4: case 14:
						// Repeat, Do
						//System.out.println("DEBUG: Trying to process REPEAT..."); // debug
						jumppoint[jumplevel] = l;
						jumplevel++;
						break;
					case 5:
						// Until
						//System.out.println("DEBUG: Trying to process UNTIL..."); // debug
						// Set the jump-point for until:
						g.mytokens.get(tn).myparameters.get(l).args[1] = jumppoint[jumplevel-1] + 1; // +1 optional. // was arg2
						g.mytokens.get(tn).myparameters.get(l).numargs = 2;

						// Drop the jump level:
						jumplevel--;
						break;
					case 6:
						// If
						//System.out.println("DEBUG: Trying to process IF..."); // debug
						g.mytokens.get(tn).myparameters.get(l).numargs = 4; // added
						g.mytokens.get(tn).myparameters.get(l).args[2] = 0; // added
						g.mytokens.get(tn).myparameters.get(l).args[3] = 0; // added
						jumppoint[jumplevel] = l;
						jumppoint2[jumplevel] = l;
						jumplevel++;
						break;
					case 7: case 18:
						// End If, Endif
						// Set the jump-point for if (arg 2) to the endif:
						//Note: Was the line after the endif, l+1
						//System.out.println("DEBUG: Trying to process ENDIF..."); // debug
						g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel-1]).args[1] = l; // was l+1 // was arg2
						g.mytokens.get(tn).myparameters.get(jumppoint2[jumplevel-1]).args[3] = l; // was l+1 // was arg2
						//mytokens.myparameters[jumppoint[jumplevel-1]].numargs = 2; // removed
						
						// Drop the jump level:
						jumplevel--;
						break;
					case 8:
						// While
						//System.out.println("DEBUG: Trying to process WHILE..."); // debug
						jumppoint[jumplevel] = l;
						jumplevel++;
						break;
					case 9: case 15: case 16: case 17:
						// Wend, Loop, Endwhile, Forever
						//System.out.println("DEBUG: Trying to process WEND..."); // debug
						// Set the jump-point for while (arg 2) to the line after the wend:
						g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel-1]).args[1] = l+1; // was arg2
						g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel-1]).numargs = 2;

						// Calculate the jumppoint for the wend - after line which is not insttype 2,3 or 4 (set temp):
						tt = jumppoint[jumplevel-1];
						while (tt > 0)
						{
							int ins = g.mytokens.get(tn).myparameters.get(tt-1).insttype;
							if (tt>0 && (ins>=2 && ins<=4))
								tt--;
							else
								break;
						}

						// Set the jump-point for wend:
						g.mytokens.get(tn).myparameters.get(l).args[0] = tt; // was arg
						g.mytokens.get(tn).myparameters.get(l).numargs = 1;

						// Drop the jump level:
						jumplevel--;
						break;
					case 10:
						// {
						//System.out.println("DEBUG: Trying to process {..."); // debug
						// (Possibly to do: For local variables within scope, set a property of the preceding instruction...)

						// If preceding line is If, set arg[2] to 1 (if with braces) - needed for Else and Else If.
						// Extended to Else and Else If also (1 and 2 as well as 6)
						if (l>0)
						{
							ret2 = g.mytokens.get(tn).myparameters.get(l-1);
							if ((ret2.insttype == 1) && ((ret2.instflag == 6) || (ret2.instflag == 1) || (ret2.instflag == 2)))
								g.mytokens.get(tn).myparameters.get(l-1).args[2] = 1;
						}

						// Remove this line, and shift down instructions:
						for (int ll=l; ll<(g.mytokens.get(tn).myparameters.size() - 1); ll++)
							g.mytokens.get(tn).myparameters.set(ll, g.mytokens.get(tn).myparameters.get(ll + 1));
						// Remove last instance from ArrayList:
						g.mytokens.get(tn).myparameters.remove(g.mytokens.get(tn).myparameters.size()-1);
						l--;
						break;
					case 11:
						// }
						//System.out.println("DEBUG: Trying to process }..."); // debug
						if (jumplevel == 0) // Error!
						{
							System.err.print("Error with '}'!");
							break;
						}
						jumplevel--;
						ret2 = g.mytokens.get(tn).myparameters.get(jumppoint[jumplevel]);
						if (ret2.insttype == 1)
							switch (ret2.instflag)
							{
							case 4:
								// Repeat
								// Next line (after temps) should be Until - test for error?

								// Remove this line, and shift down instructions:
								for (int ll=l; ll<(g.mytokens.get(tn).myparameters.size() - 1); ll++)
									g.mytokens.get(tn).myparameters.set(ll, g.mytokens.get(tn).myparameters.get(ll + 1));
								// Remove last instance from ArrayList:
								g.mytokens.get(tn).myparameters.remove(g.mytokens.get(tn).myparameters.size()-1);
								l--;
								break;
							case 6: case 1: case 2:
								// After If or Else If or Else
								// Set to Endif
								g.mytokens.get(tn).myparameters.get(l).instflag = 7;
								jumplevel++;
								l--;
								break;
							case 8:
								// After While
								// Set to Wend
								g.mytokens.get(tn).myparameters.get(l).instflag = 9;
								jumplevel++;
								l--;
								break;
							}
						break;
						
						// Added - for Procedures:
					case 21: case 22:
						// Do string matching of procedure call with defined procedures:
						TokeniserReturn ret = g.mytokens.get(tn).myparameters.get(l);
						String procname = g.mytokens.get(tn).myprocedurecalls.get((int)ret.args[0]);
						
						// Compare the called procedure string with the list of procedure strings:
						int numprocedures = g.mytokens.get(tn).myprocedures.size();
						int procedurenumber;
						for (procedurenumber = 0; procedurenumber<numprocedures; procedurenumber++)
							if (procname.equals(g.mytokens.get(tn).myprocedures.get(procedurenumber)))
								break;
						
						// Now set the procedure call reference to the procedure number, or give an error if not found:
						if (procedurenumber >= numprocedures)
						{
							System.err.println("ERROR: Procedure not found: "+procname);
						}
						else
						{
							//System.out.println("DEBUG: Procedure found: "+procname+", call number="+((int)ret.args[0])+", actual number="+procedurenumber);
							g.mytokens.get(tn).myparameters.get(l).args[0] = procedurenumber; //ret.args[0] = procedurenumber;
							//g.mytokens.get(tn).myparameters.set(l, ret); // removed
						}
						
						break;
					}
				}
				else if (g.mytokens.get(tn).myparameters.get(l).insttype == 2) // Operator
				{
					if (g.mytokens.get(tn).myparameters.get(l).instflag == 0) // Dot
					{
						// First, get the class/brain name from the variable name in arg[1]:
						temptext = lower(g.mytokens.get(tn).myvarnames.get((int)g.mytokens.get(tn).myparameters.get(l).args[1]));   
						int br = 0;
						// Find the appropriate class/brain (returned in br):
						for (br=0; br<g.mytokens.size(); br++)
						{
							if (temptext.equals(lower(g.mytokens.get(br).name)) == true)
								break;
						}
						if (br<g.mytokens.size())
						{
							// Get the referred variable name string from arg[2]:
							// To do - also do functions...
							temptext = lower(g.mytokens.get(tn).mystrings.get((int)g.mytokens.get(tn).myparameters.get(l).args[2]));
							int v;
							// Find the appropriate variable in the pointed brain:
							for (v=0; v<g.mytokens.get(br).myvarnames.size(); v++)
							{
								if (temptext.equals(lower(g.mytokens.get(br).myvarnames.get(v))) == true)
									break;
							}

							if (v < (g.mytokens.get(br).myvarnames.size()))
							{
								g.mytokens.get(tn).myparameters.get(l).args[2] = v;
								g.mytokens.get(tn).myparameters.get(l).argtypes[2] = 0;
							}
							else
							{
								System.out.println("Error - referred variable ("+temptext+") not found (q)! Brain = \""+(g.mytokens.get(tn).name)+"\"");
								for (v=0; v<g.mytokens.get(br).myvarnames.size(); v++)
									System.out.println("  "+v+": \"" + g.mytokens.get(br).myvarnames.get(v) + "\"");
							}
						}
						else
						{
							System.out.println("Error - class/brain not found (q)! Brain = \""
									+(g.mytokens.get(tn).myvarnames.get((int)g.mytokens.get(tn).myparameters.get(l).args[1]))+
									"\", length="+g.mytokens.get(tn).myvarnames.get(g.mytokens.get(tn).myparameters.get(l).instflag).length());
							// Debug:
							for ( br=0; br<g.mytokens.size(); br++)
								System.out.println("   Brain #"+br+" = \""+g.mytokens.get(br).name+"\", length="+g.mytokens.get(br).name.length());
						}
					}
				}
				else if (((g.mytokens.get(tn).myparameters.get(l).insttype) >= 15) && ((g.mytokens.get(tn).myparameters.get(l).insttype) <= 21))
				{
					// First, get the class/brain name from the variable name in ret.instflag:
					temptext = lower(g.mytokens.get(tn).myvarnames.get(g.mytokens.get(tn).myparameters.get(l).instflag));
					int br = 0;
					// Find the appropriate class/brain (returned in n):
					for (br=0; br<g.mytokens.size(); br++)
					{
						if (temptext.equals(lower(g.mytokens.get(br).name)) == false)
						{
							break;
						}
					}
					if (br<g.mytokens.size())
					{
						// Get the referred variable name string from arg[0]:
						// To do - also do functions...
						temptext = lower(g.mytokens.get(tn).mystrings.get((int)g.mytokens.get(tn).myparameters.get(l).args[0]));
						int v;
						// Find the appropriate variable in the pointed brain:
						for (v=0; v<g.mytokens.get(br).myvarnames.size(); v++)
						{
							//System.out.println("Comparing the string -"+temptext+" with -"+lower(g.mytokens.get(br).myvarnames.get(v))); // debug
							if (temptext.equals(lower(g.mytokens.get(br).myvarnames.get(v))) == true)
								break;
						}

						if (v < g.mytokens.get(br).myvarnames.size())
						{
							g.mytokens.get(tn).myparameters.get(l).args[0] = v;
							g.mytokens.get(tn).myparameters.get(l).argtypes[0] = 0;
						}
						else
						{
							System.out.println("Error - referred variable ("+temptext+") not found (AT END)! Brain = \""+(g.mytokens.get(br).name)+"\"");
							for (v=0; v<g.mytokens.get(br).myvarnames.size(); v++)
								System.out.println("  "+v+" \""+g.mytokens.get(br).myvarnames.get(v)+"\"");
						}
					}
					else
					{
						System.out.println("Error - class/brain not found (AT END)! Brain = \""
								+(g.mytokens.get(tn).myvarnames.get(g.mytokens.get(tn).myparameters.get(l).instflag))+"\" ("
								+g.mytokens.get(tn).myvarnames.get(g.mytokens.get(tn).myparameters.get(l).instflag).length()+")"); 

						// Debug:
						for (br=0; br<g.mytokens.size(); br++)
							System.out.println("   Brain["+br+"] = \""+g.mytokens.get(br).name+"\" ("+g.mytokens.get(br).name.length()+")\n");
					}
				}
				//else System.out.println("Unknown instruction!"); // debug
			}
		}

		// Here temptext[] is freed automatically by Java's garbage collector.

		return 0;
	}
	
	// Added to split a string:
	public int lexString(String str)
	{
		// First destroy the current tokens:
		g.mytokens = new ArrayList<TheTokens>();
		g.ActiveObjects = new ArrayList<ActiveObject>();
		
		// Added for jAMOS - initialise the MequaScript Parser:
        inittokens(g.mytokens, 0, "Master");
        
		// Load the instruction and function names:
		initinstructions();
		
		// Split the input string:
		ArrayList<String> splitstring = new ArrayList<String>(Arrays.asList(str.split("\r?\n|\r")));
		
		// Evaluate the instructions:
		evaluateinstructions(splitstring);

		// Do this after tokenisation:
		// For each brain, initialise an object (in myvalues[n]), and set its brain number to the object number (make more OO later):
		for (int n=0; n<g.mytokens.size(); n++)
		{
			ActiveObject temp = new ActiveObject();
			temp.ObjectBrain = n;
			g.ActiveObjects.add(temp);
		}
		
		// Now initialise the variables of each object:
		for (int n=0; n<g.mytokens.size(); n++)
			initvalues(g.mytokens, n);
		
		return 0;
	}
	
	// TODO - duplicate from Interpreter:
	public int initvalues(ArrayList <TheTokens> multitokens, int nn)
	{
		String temptext;
		//String temptext2;

		// Now initialise the variables for the object (size given in the brain/class):
		for (int n=0; n<(multitokens.get(g.ActiveObjects.get(nn).ObjectBrain).myvarnames.size()); n++)
		{
			// Exception: Check if any used variable names correspond to brain/class names:
			temptext = lower(multitokens.get(g.ActiveObjects.get(nn).ObjectBrain).myvarnames.get(n));
			int ob = 0;
			// Find the first object of the appropriate class/brain (returned in n):
			for (ob=0; ob<g.ActiveObjects.size() &&
					!temptext.equals(lower(multitokens.get(g.ActiveObjects.get(ob).ObjectBrain).name)); ob++);

			// Add the new variable:
			Mytype tempvar = new Mytype();
			if (ob<g.ActiveObjects.size())
				tempvar.d = (double)ob;
			else
				// Clear the variable
				tempvar.d = 0;

			tempvar.t = 0;
			g.ActiveObjects.get(nn).myvars.add(tempvar);
		}

		// Set the extra variables here (removed for Java):
		//setextravars(nn);

		// Note: temptext is deleted automatically by Java's garbage collector.
		return 0;
	}
}
