package jamos.mequascript;

// Added for jAMOS:
import jamos.AMOS_System;

// TODO - move this?
import java.util.ArrayList;


public class CommandWrapper
{
	// Added init method:
	Game g;
	// Added for jAMOS:
	AMOS_System am;
	public CommandWrapper(Game g_, AMOS_System am_)
	{
		g=g_;
		am = am_;
	}
	
	Mytype runfunction(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// For executing "Print" etc. :
		switch(ret.instflag)
		{
		case 1:  return m_double(ret, mytokens, myvalues, offset, realret, mytemps);
		case 2:  return m_print(ret, mytokens, myvalues, offset, realret, mytemps);
		case 3:  return m_say(ret, mytokens, myvalues, offset, realret, mytemps);
		case 4:  return m_instr(ret, mytokens, myvalues, offset, realret, mytemps);
		case 5:  return m_substring(ret, mytokens, myvalues, offset, realret, mytemps);

		// Added - for jAMOS:
		case 6:  return m_screenopen(ret, mytokens, myvalues, offset, realret, mytemps);
		case 7:  return m_screendisplay(ret, mytokens, myvalues, offset, realret, mytemps);
		case 8:  return m_screenoffset(ret, mytokens, myvalues, offset, realret, mytemps);
		case 9:  return m_screenclose(ret, mytokens, myvalues, offset, realret, mytemps);
		case 10: return m_screenclone(ret, mytokens, myvalues, offset, realret, mytemps);
		case 11: return m_screen(ret, mytokens, myvalues, offset, realret, mytemps);
		case 12: return m_doublebuffer(ret, mytokens, myvalues, offset, realret, mytemps);
		case 13: return m_dualplayfield(ret, mytokens, myvalues, offset, realret, mytemps);
		case 14: return m_dualpriority(ret, mytokens, myvalues, offset, realret, mytemps);
		case 15: return m_loadiff(ret, mytokens, myvalues, offset, realret, mytemps);
		case 16: return m_load(ret, mytokens, myvalues, offset, realret, mytemps);
		case 17: return m_erase(ret, mytokens, myvalues, offset, realret, mytemps);
		case 18: return m_hideon(ret, mytokens, myvalues, offset, realret, mytemps);
		case 19: return m_updateevery(ret, mytokens, myvalues, offset, realret, mytemps);
		case 20: return m_flashoff(ret, mytokens, myvalues, offset, realret, mytemps);
		case 21: return m_flash(ret, mytokens, myvalues, offset, realret, mytemps);
		case 22: return m_setrainbow(ret, mytokens, myvalues, offset, realret, mytemps);
		case 23: return m_rainbowdel(ret, mytokens, myvalues, offset, realret, mytemps);
		case 24: return m_rainbow(ret, mytokens, myvalues, offset, realret, mytemps);
		case 25: return m_boboff(ret, mytokens, myvalues, offset, realret, mytemps);
		case 26: return m_bob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 27: return m_setbob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 28: return m_spriteoff(ret, mytokens, myvalues, offset, realret, mytemps);
		case 29: return m_sprite(ret, mytokens, myvalues, offset, realret, mytemps);
		case 30: return m_setspritebuffer(ret, mytokens, myvalues, offset, realret, mytemps);
		case 31: return m_setreg(ret, mytokens, myvalues, offset, realret, mytemps);
		case 32: return m_unpack(ret, mytokens, myvalues, offset, realret, mytemps);
		case 33: return m_channeltosprite(ret, mytokens, myvalues, offset, realret, mytemps);
		case 34: return m_channeltobob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 35: return m_channeltoscreenoffset(ret, mytokens, myvalues, offset, realret, mytemps);
		case 36: return m_channeltoscreensize(ret, mytokens, myvalues, offset, realret, mytemps);
		case 37: return m_channeltorainbow(ret, mytokens, myvalues, offset, realret, mytemps);
		case 38: return m_channeltoscreendisplay(ret, mytokens, myvalues, offset, realret, mytemps);
		case 39: return m_bell(ret, mytokens, myvalues, offset, realret, mytemps);
		case 40: return m_xmouse(ret, mytokens, myvalues, offset, realret, mytemps);
		case 41: return m_ymouse(ret, mytokens, myvalues, offset, realret, mytemps);
		case 42: return m_mousekey(ret, mytokens, myvalues, offset, realret, mytemps);
		case 43: return m_xscreen(ret, mytokens, myvalues, offset, realret, mytemps);
		case 44: return m_yscreen(ret, mytokens, myvalues, offset, realret, mytemps);
		case 45: return m_xhard(ret, mytokens, myvalues, offset, realret, mytemps);
		case 46: return m_yhard(ret, mytokens, myvalues, offset, realret, mytemps);
		case 47: return m_joy(ret, mytokens, myvalues, offset, realret, mytemps);
		case 48: return m_jleft(ret, mytokens, myvalues, offset, realret, mytemps);
		case 49: return m_jright(ret, mytokens, myvalues, offset, realret, mytemps);
		case 50: return m_jup(ret, mytokens, myvalues, offset, realret, mytemps);
		case 51: return m_jdown(ret, mytokens, myvalues, offset, realret, mytemps);
		case 52: return m_fire(ret, mytokens, myvalues, offset, realret, mytemps);
		case 53: return m_xsprite(ret, mytokens, myvalues, offset, realret, mytemps);
		case 54: return m_ysprite(ret, mytokens, myvalues, offset, realret, mytemps);
		case 55: return m_isprite(ret, mytokens, myvalues, offset, realret, mytemps);
		case 56: return m_xbob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 57: return m_ybob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 58: return m_ibob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 59: return m_pastebob(ret, mytokens, myvalues, offset, realret, mytemps);
		case 60: return m_plot(ret, mytokens, myvalues, offset, realret, mytemps);
		case 61: return m_ink(ret, mytokens, myvalues, offset, realret, mytemps);
		case 62: return m_draw(ret, mytokens, myvalues, offset, realret, mytemps);
		case 63: return m_bar(ret, mytokens, myvalues, offset, realret, mytemps);
		case 64: return m_box(ret, mytokens, myvalues, offset, realret, mytemps);
		case 65: return m_circle(ret, mytokens, myvalues, offset, realret, mytemps);
		case 66: return m_ellipse(ret, mytokens, myvalues, offset, realret, mytemps);
		case 67: return m_rnd(ret, mytokens, myvalues, offset, realret, mytemps);
		case 68: return m_hrev(ret, mytokens, myvalues, offset, realret, mytemps);
		case 69: return m_vrev(ret, mytokens, myvalues, offset, realret, mytemps);
		case 70: return m_rev(ret, mytokens, myvalues, offset, realret, mytemps);
		case 71: return m_rain(ret, mytokens, myvalues, offset, realret, mytemps);
		case 72: return m_degree(ret, mytokens, myvalues, offset, realret, mytemps);
		case 73: return m_radian(ret, mytokens, myvalues, offset, realret, mytemps);
		case 74: return m_sin(ret, mytokens, myvalues, offset, realret, mytemps);
		case 75: return m_cos(ret, mytokens, myvalues, offset, realret, mytemps);
		case 76: return m_tan(ret, mytokens, myvalues, offset, realret, mytemps);
		case 77: return m_asin(ret, mytokens, myvalues, offset, realret, mytemps);
		case 78: return m_acos(ret, mytokens, myvalues, offset, realret, mytemps);
		case 79: return m_atan(ret, mytokens, myvalues, offset, realret, mytemps);
		case 80: return m_pi(ret, mytokens, myvalues, offset, realret, mytemps);
		case 81: return m_left(ret, mytokens, myvalues, offset, realret, mytemps);
		case 82: return m_right(ret, mytokens, myvalues, offset, realret, mytemps);
		case 83: return m_mid(ret, mytokens, myvalues, offset, realret, mytemps);
		case 84: return m_len(ret, mytokens, myvalues, offset, realret, mytemps);
		case 85: return m_upper(ret, mytokens, myvalues, offset, realret, mytemps);
		case 86: return m_lower(ret, mytokens, myvalues, offset, realret, mytemps);
		case 87: return m_string(ret, mytokens, myvalues, offset, realret, mytemps);
		case 88: return m_repeat(ret, mytokens, myvalues, offset, realret, mytemps);
		case 89: return m_space(ret, mytokens, myvalues, offset, realret, mytemps);
		case 90: return m_flip(ret, mytokens, myvalues, offset, realret, mytemps);
		case 91: return m_val(ret, mytokens, myvalues, offset, realret, mytemps);
		case 92: return m_str(ret, mytokens, myvalues, offset, realret, mytemps);
		case 93: return m_asc(ret, mytokens, myvalues, offset, realret, mytemps);
		case 94: return m_chr(ret, mytokens, myvalues, offset, realret, mytemps);
		case 95: return m_boom(ret, mytokens, myvalues, offset, realret, mytemps);
		case 96: return m_shoot(ret, mytokens, myvalues, offset, realret, mytemps);
		case 97: return m_paramstring(ret, mytokens, myvalues, offset, realret, mytemps);
		case 98: return m_paramfloat(ret, mytokens, myvalues, offset, realret, mytemps);
		case 99: return m_param(ret, mytokens, myvalues, offset, realret, mytemps);
		
		case 100: return m_getarrayvalue(ret, mytokens, myvalues, offset, realret, mytemps);


		// From 3Dlicious! (another project):
		/*
		case 6: return m_take(ret, mytokens, myvalues, offset, realret, mytemps);
		case 7: return m_rotate(ret, mytokens, myvalues, offset, realret, mytemps);
		case 8: return m_move(ret, mytokens, myvalues, offset, realret, mytemps);
		case 9: return m_setnode(ret, mytokens, myvalues, offset, realret, mytemps);
		case 10: return m_selectusewith(ret, mytokens, myvalues, offset, realret, mytemps);
		case 11: return m_usewithme(ret, mytokens, myvalues, offset, realret, mytemps);
		case 12: return m_setothernode(ret, mytokens, myvalues, offset, realret, mytemps);
		case 13: return m_kill(ret, mytokens, myvalues, offset, realret, mytemps);
		case 14: return m_createinventoryobject(ret, mytokens, myvalues, offset, realret, mytemps);
		case 15: return m_createActiveObject(ret, mytokens, myvalues, offset, realret, mytemps);
		case 16: return m_usewith(ret, mytokens, myvalues, offset, realret, mytemps);
		case 17: return m_scale(ret, mytokens, myvalues, offset, realret, mytemps);
		case 18: return m_sound(ret, mytokens, myvalues, offset, realret, mytemps);
		case 19: return m_drop(ret, mytokens, myvalues, offset, realret, mytemps);
		*/

		default: return m_dummyfunction(ret, mytokens, myvalues, offset, realret, mytemps);
		}
	}


	// Special functions:
	Mytype m_paramstring(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		realret.t = 1;
		realret.s = myvalues.myparamstring;
		return realret;
	}
	Mytype m_paramfloat(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		realret.t = 0;
		realret.d = myvalues.myparamfloat;
		return realret;
	}
	Mytype m_param(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		realret.t = 0;
		realret.d = myvalues.myparamfloat;
		//realret.d = myvalues.myparamint; // Uses float/double by default - TODO - allow AMOS behaviour!
		return realret;
	}
	
	// Special function:
	Mytype m_getarrayvalue(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		ArrayList<Integer> arraydims = new ArrayList<Integer>();
		for (int dim=0; dim<ret.numargs-2; dim++)
			arraydims.add((int)getarg(ret.args[offset+dim], ret.argtypes[offset+dim], myvalues, mytemps));
		
		//System.out.println("Debug: Number of params: "+arraydims.size());
		//for (int p=0; p<arraydims.size(); p++) System.out.println(""+ arraydims.get(p));
		
		Mytype actualret = myvalues.myarrays.get((int)ret.args[ret.numargs-1]).get(arraydims);
		
		//realret = actualret.copy(); // Below method used instead:
		
		realret.t = actualret.t;
		realret.d = actualret.d;
		realret.s = actualret.s;
		
		return realret;
	}
	
	
	// TODO - duplicates from Interpreter:
	String floattostring(double value)
	{
		if (((double)((int)value)) != value)
			return ""+value;
		else
			return ""+((int)value);
	}
	double getarg(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return arg;
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).d;
		case 3:
			return 0; // String: mytokens.mystrings[arg] - fix types!
		case 5:
			return mytemps[(int)arg].d; // Make sure initialised!
		default:
			return 0;
		}
	}
	String getarg2(double arg, int argtype, ActiveObject myvalues, TheTokens mytokens, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case 0:
			return floattostring(arg);
		case 1:
			// Var name (string): mytokens.myvarnames[arg]
			// Convert number if appropriate:
			if (myvalues.myvars.get((int)arg).t == 0)
				return floattostring(myvalues.myvars.get((int)arg).d);
			else
				return myvalues.myvars.get((int)arg).s;
		case 3:
			return mytokens.mystrings.get((int)arg);
		case 5:
			return ((mytemps[(int)arg].s)); // Make sure initialised!
		default:
		}
		return null;
	}
	// Was int, changed to boolean:
	boolean isnumber(double arg, int argtype, ActiveObject myvalues, Mytype[] mytemps)
	{
		switch(argtype)
		{
		case -1:
			return true;
		case 0:
			return true;
		case 1: // Variable name - to do:
			// Var name (string): mytokens.myvarnames[arg]
			return myvalues.myvars.get((int)arg).t == 0;
		case 3:
			return false;
		case 5:
			return (mytemps[(int)arg].t) == 0; // Make sure initialised!
		default:
		}
		return false;
	}
	
	

	// User-defined functions...
	Mytype m_dummyfunction(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		return realret;
	}
	Mytype m_double(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		if (ret.numargs == 0)
		{
			//realret.d = -1; // error (-1, now 0)...
			return realret;
		}
		// First arg only
		double arg = getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		realret.d = arg * 2;
		return realret;
	}
	Mytype m_print(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		for (int n=offset; n<ret.numargs; n++)
		{
			if (isnumber(ret.args[n], ret.argtypes[n], myvalues, mytemps))
				System.out.println(floattostring(getarg(ret.args[n], ret.argtypes[n], myvalues, mytemps)));
			else
				System.out.println(getarg2(ret.args[n], ret.argtypes[n], myvalues, mytokens, mytemps)); //, ret.argtypes[n]);
		}
		return realret;
	}
	Mytype m_say(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// Debug - as for print (for now):
		for (int n=offset; n<ret.numargs; n++)
		{
			if (isnumber(ret.args[n], ret.argtypes[n], myvalues, mytemps))
				System.out.println(floattostring(getarg(ret.args[n], ret.argtypes[n], myvalues, mytemps)));
			else
				System.out.println(getarg2(ret.args[n], ret.argtypes[n], myvalues, mytokens, mytemps)); //, ret.argtypes[n]);
		}
		return realret;
	}
	Mytype m_instr(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a=""; String b=""; double c=0;
		realret.t = 0;
		// Converted from C++ strstr()!=0 to Java .contains with ?: ternary operator:
		//realret.d = (getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps).contains(
		//		getarg2(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytokens, mytemps))) ? 1 : 0;
		
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = getarg2(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytokens, mytemps);
		
		if ((offset+2) < ret.numargs)
		{
			c = getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
			realret.d = am.instr(a, b, (int)c);
		}
		else
		{
			realret.d = am.instr(a, b);
		}
		
		return realret;
	}
	Mytype m_substring(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		realret.t = 1;
		realret.s = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		// Converted from C++ substr(index, length) to Java substring(index1, index2) with length=(index2-index1)
		realret.s = realret.s.substring((int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps),
				(int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps)
				-(int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps));
		return realret;
	}
	
	
	// Added - for jAMOS:
	// TODO - need to add wrappers:
	Mytype m_screenopen(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int s=0, w=320, h=200, d=16, r=0;
		if ((offset) < ret.numargs)
			s = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			w = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			h = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		if ((offset+4) < ret.numargs)
			r = (int)getarg(ret.args[offset+4], ret.argtypes[offset+4], myvalues, mytemps);
		
		am.screenOpen(s, w, h, d, r);
		
		return realret;
	}
	Mytype m_screendisplay(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int s=0, x=0, y=0;
		if ((offset) < ret.numargs)
			s = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			x = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			y = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		
		am.screenDisplay(s, x, y);
		
		return realret;
	}
	Mytype m_screenoffset(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int s=0, x=0, y=0;
		if ((offset) < ret.numargs)
			s = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			x = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			y = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		
		am.screenOffset(s, x, y);
		
		return realret;
	}
	Mytype m_screenclose(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.screenClose(); // TODO - more params
		return realret;
	}
	Mytype m_screenclone(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int s=0;
		if ((offset) < ret.numargs)
			s = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.screenClone(s);
		
		return realret;
	}
	Mytype m_screen(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int s=0;
		if ((offset) < ret.numargs)
			s = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.screen(s);
		
		return realret;
	}
	Mytype m_doublebuffer(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.doubleBuffer();
		return realret;
	}
	Mytype m_dualplayfield(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.dualPlayfield(a, b);
		
		return realret;
	}
	Mytype m_dualpriority(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.dualPriority(a, b);
		
		return realret;
	}
	Mytype m_loadiff(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.loadIff(a, b);
		return realret;
	}
	Mytype m_load(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.load(a, b);
		return realret;
	}
	Mytype m_erase(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.erase(a);
		return realret;
	}
	Mytype m_hideon(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.hideOn();
		return realret;
	}
	Mytype m_updateevery(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.updateEvery(a);
		return realret;
	}
	Mytype m_flashoff(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.flashOff(); // TODO - more params
		return realret;
	}
	Mytype m_flash(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{		
		int a=0;
		String b="";
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = getarg2(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytokens, mytemps);
		
		am.flash(a, b);
		return realret;
	}
	Mytype m_setrainbow(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0;
		String d="", e="", f="";
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = getarg2(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytokens, mytemps);
		if ((offset+4) < ret.numargs)
			e = getarg2(ret.args[offset+4], ret.argtypes[offset+4], myvalues, mytokens, mytemps);
		if ((offset+5) < ret.numargs)
			f = getarg2(ret.args[offset+5], ret.argtypes[offset+5], myvalues, mytokens, mytemps);
		
		am.setRainbow(a, b, c, d, e, f);
		return realret;
	}
	Mytype m_rainbowdel(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a;
		if ((offset) < ret.numargs)
		{
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
			am.rainbowDel(a);
		}
		else
		{
			am.rainbowDel();
		}
		
		return realret;
	}
	Mytype m_rainbow(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.rainbow(a, b, c, d);
		return realret;
	}
	Mytype m_boboff(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.bobOff(); // TODO - more params
		return realret;
	}
	Mytype m_bob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.bob(a, b, c, d);
		return realret;
	}
	Mytype m_setbob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.setBob(a, b, c, d);
		return realret;
	}
	Mytype m_spriteoff(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.spriteOff(); // TODO - more params
		return realret;
	}
	Mytype m_sprite(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.sprite(a, b, c, d);
		return realret;
	}
	Mytype m_setspritebuffer(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.setSpriteBuffer(a);
		return realret;
	}
	Mytype m_setreg(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.setReg(a, b);
		return realret;
	}
	Mytype m_unpack(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.unpack(a, b);
		return realret;
	}
	Mytype m_channeltosprite(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToSprite(a, b);
		return realret;
	}
	Mytype m_channeltobob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToBob(a, b);
		return realret;
	}
	Mytype m_channeltoscreenoffset(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToScreenOffset(a, b);
		return realret;
	}
	Mytype m_channeltoscreensize(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToScreenSize(a, b);
		return realret;
	}
	Mytype m_channeltorainbow(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToRainbow(a, b);
		return realret;
	}
	Mytype m_channeltoscreendisplay(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		am.channelToScreenDisplay(a, b);
		return realret;
	}
	Mytype m_bell(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params:
		am.bell();
		return realret;
	}
	Mytype m_xmouse(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params
		realret.d = am.xMouse();
		return realret;
	}
	Mytype m_ymouse(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params
		realret.d = am.yMouse();
		return realret;
	}
	Mytype m_mousekey(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params
		realret.d = am.mouseKey();
		return realret;
	}
	Mytype m_xscreen(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		if ((offset+1) < ret.numargs)
		{
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
			realret.d = am.xScreen(a, b);
		}
		else
		{
			realret.d = am.xScreen(a);
		}
	
		return realret;
	}
	Mytype m_yscreen(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		if ((offset+1) < ret.numargs)
		{
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
			realret.d = am.yScreen(a, b);
		}
		else
		{
			realret.d = am.yScreen(a);
		}
	
		return realret;
	}
	Mytype m_xhard(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		if ((offset+1) < ret.numargs)
		{
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
			realret.d = am.xHard(a, b);
		}
		else
		{
			realret.d = am.xHard(a);
		}
	
		return realret;
	}
	Mytype m_yhard(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		if ((offset+1) < ret.numargs)
		{
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
			realret.d = am.yHard(a, b);
		}
		else
		{
			realret.d = am.yHard(a);
		}
	
		return realret;
	}
	Mytype m_joy(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.joy(a);
			
		return realret;
	}
	Mytype m_jleft(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.jleft(a);
			
		return realret;
	}
	Mytype m_jright(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.jright(a);
			
		return realret;
	}
	Mytype m_jup(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.jup(a);
			
		return realret;
	}
	Mytype m_jdown(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.jdown(a);
			
		return realret;
	}
	Mytype m_fire(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.fire(a);
			
		return realret;
	}
	Mytype m_xsprite(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.xSprite(a);
			
		return realret;
	}
	Mytype m_ysprite(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.ySprite(a);
			
		return realret;
	}
	Mytype m_isprite(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.iSprite(a);
			
		return realret;
	}
	Mytype m_xbob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.xBob(a);
			
		return realret;
	}
	Mytype m_ybob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.yBob(a);
			
		return realret;
	}
	Mytype m_ibob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.iBob(a);
			
		return realret;
	}
	Mytype m_pastebob(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		
		am.pastebob(a, b, c);
		return realret;
	}
	Mytype m_plot(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		if ((offset+2) < ret.numargs)
		{
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
			am.plot(a, b, c);
		}
		else
		{
			am.plot(a, b);
		}
		
		return realret;
	}
	Mytype m_ink(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		am.ink(a);
		return realret;
	}
	Mytype m_draw(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.draw(a, b, c, d);
		return realret;
	}
	Mytype m_bar(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.bar(a, b, c, d);
		return realret;
	}
	Mytype m_box(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.box(a, b, c, d);
		return realret;
	}
	Mytype m_circle(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		
		am.circle(a, b, c);
		return realret;
	}
	Mytype m_ellipse(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0, d=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		if ((offset+3) < ret.numargs)
			d = (int)getarg(ret.args[offset+3], ret.argtypes[offset+3], myvalues, mytemps);
		
		am.ellipse(a, b, c, d);
		return realret;
	}
	
	Mytype m_rnd(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.rnd(a);
		return realret;
	}
	
	Mytype m_hrev(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.hrev(a);
		return realret;
	}
	Mytype m_vrev(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.vrev(a);
		return realret;
	}
	Mytype m_rev(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.rev(a);
		return realret;
	}
	Mytype m_rain(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0, b=0, c=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		if ((offset+2) < ret.numargs)
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
		
		am.rain(a, b, c);
		return realret;
	}
	Mytype m_degree(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.degree();
		return realret;
	}
	Mytype m_radian(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		am.radian();
		return realret;
	}
	Mytype m_sin(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.sin(a);
		return realret;
	}
	Mytype m_cos(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.cos(a);
		return realret;
	}
	Mytype m_tan(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.tan(a);
		return realret;
	}
	Mytype m_asin(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.asin(a);
		return realret;
	}
	Mytype m_acos(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.acos(a);
		return realret;
	}
	Mytype m_atan(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.d = am.atan(a);
		return realret;
	}
	Mytype m_pi(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		realret.d = am.pi();
		return realret;
	}
	Mytype m_left(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.left(a, b);
		return realret;
	}
	Mytype m_right(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.right(a, b);
		return realret;
	}
	Mytype m_mid(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0; int c=0;
		
		realret.t = 1;
		
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		if ((offset+2) < ret.numargs)
		{
			c = (int)getarg(ret.args[offset+2], ret.argtypes[offset+2], myvalues, mytemps);
			realret.s = am.mid(a, b, c);
		}
		else
		{		
			realret.s = am.mid(a, b);
		}
		return realret;
	}
	Mytype m_len(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);

		realret.d = am.len(a);
		return realret;
	}
	Mytype m_upper(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);

		realret.t = 1;
		realret.s = am.upper(a);
		return realret;
	}
	Mytype m_lower(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);

		realret.t = 1;
		realret.s = am.lower(a);
		return realret;
	}
	Mytype m_string(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am._string(a, b);
		return realret;
	}
	Mytype m_repeat(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		int b=0;
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		if ((offset+1) < ret.numargs)
			b = (int)getarg(ret.args[offset+1], ret.argtypes[offset+1], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.repeat(a, b);
		return realret;
	}
	Mytype m_space(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.space(a);
		return realret;
	}
	Mytype m_flip(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		
		realret.t = 1;
		realret.s = am.flip(a);
		return realret;
	}
	Mytype m_val(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);
		
		realret.d = am.val(a);
		return realret;
	}
	Mytype m_str(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.str(a);
		return realret;
	}
	Mytype m_asc(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		String a="";
		if ((offset) < ret.numargs)
			a = getarg2(ret.args[offset], ret.argtypes[offset], myvalues, mytokens, mytemps);

		realret.d = am.asc(a);
		return realret;
	}
	Mytype m_chr(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		int a=0;
		
		if ((offset) < ret.numargs)
			a = (int)getarg(ret.args[offset], ret.argtypes[offset], myvalues, mytemps);
		
		realret.t = 1;
		realret.s = am.chr(a);
		return realret;
	}
	Mytype m_boom(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params:
		am.boom();
		return realret;
	}
	Mytype m_shoot(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		// TODO - more params:
		am.shoot();
		return realret;
	}
	
	
	// From 3Dlicious! (another project) - removed in jAMOS:
	/*
	Mytype m_take(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Take");
		return realret;
	}
	Mytype m_rotate(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Rotate");
		return realret;
	}
	Mytype m_move(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Move");
		return realret;
	}
	Mytype m_scale(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Scale");
		return realret;
	}
	Mytype m_setnode(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("SetNode");
		return realret;
	}
	Mytype m_selectusewith(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("SelectUseWith");
		return realret;
	}
	Mytype m_usewith(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("UseWith");
		return realret;
	}
	Mytype m_setothernode(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("SetOtherNode");
		return realret;
	}
	Mytype m_kill(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Kill");
		return realret;
	}
	Mytype m_createinventoryobject(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("CreateInventoryObject");
		return realret;
	}
	Mytype m_createActiveObject(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("CreateActiveObject");
		return realret;
	}
	Mytype m_usewithme(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("UseWithMe");
		return realret;
	}
	Mytype m_sound(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Sound");
		return realret;
	}
	Mytype m_drop(TokeniserReturn ret, TheTokens mytokens, ActiveObject myvalues, int offset,
			Mytype realret, Mytype[] mytemps)
	{
		System.out.println("Drop");
		return realret;
	}*/

};
