package jamos.mequascript;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Dumper
{
	Game g;
	
	public Dumper(Game g_)
	{
		g=g_;
	}

	// TODO: Duplicate:
	// Borrowed... updated for Java
	// Converts a float to a string:
	String floattostring(double value)
	{
		if (((double)((int)value)) != value)
			return ""+value;
		else
			return ""+((int)value);
	}

	// For dumpoutput (below):
	int dumparg(double arg, int argtype, TheTokens mytokens)
	{
		if ((argtype) == 0)
			System.out.print(""+floattostring(arg));
		else if ((argtype) == 1)
			System.out.print(mytokens.myvarnames.get((int)arg)); // Var names without numbers (normal)
		//System.out.print(mytokens.myvarnames.get((int)arg) + " {"+arg+"}"); // Debug - var names with numbers
		else if ((argtype) == 3)
			System.out.print("\""+mytokens.mystrings.get((int)arg)+"\"");
		else if ((argtype) == 5)
			System.out.print("Temp["+floattostring(arg)+"]");
		else //if (argtype == -1)
			System.out.print("???");

		return 0;
	}
	int dumpoutput(ArrayList <TheTokens> multitokens)
	{
		TheTokens mytokens;
		TokeniserReturn ret; // = new tokeniserreturn();
		System.out.println("-- The tokenised code:");

		for (int tn=0; tn<multitokens.size(); tn++)
		{
			mytokens = multitokens.get(tn);
			System.out.println("- Brain "+mytokens.name+" ("+tn+"):"); // added

			for (int l=0; l<(mytokens.myparameters.size()); l++)
			{
				ret = mytokens.myparameters.get(l);
				System.out.print("("+l+") ");

				// Finally, evaluate the instruction itself:
				if ((ret.insttype) == 1) // Standard Instruction
				{
					//System.out.print("Instruction["+ret.instflag+"] (");
					System.out.print(g.textinstruction[ret.instflag]);
					for (int n=0; n<ret.numargs; n++)
					{
						if (ret.argtypes[n] != -1)
						{
							if (n>0)
								System.out.print(",");
							System.out.print(" ");
							dumparg(ret.args[n], ret.argtypes[n], mytokens);
						}
					}
					//if (ret.numargs <= 0) System.out.print("NOARG"); // Added for Java
					//System.out.print(", "); dumparg(ret.arg2, ret.argtype2, mytokens); System.out.print(", "); dumparg(ret.arg3, ret.argtype3, mytokens);
				}
				else if ((ret.insttype) == 2) // Let Temp[x] = a OPERATOR b
				{
					System.out.print("Temp["+floattostring(ret.args[0])+"] = ");
					//System.out.print("Arg: "+ret.args[1]+", Argtype: "+ret.argtypes[1]);
					dumparg(ret.args[1], ret.argtypes[1], mytokens);
					switch (ret.instflag)
					{
					case 0: System.out.print("."); break;
					case 1: System.out.print("Not "); break;
					case 2: System.out.print(" * "); break;
					case 3: System.out.print(" / "); break;
					case 4: System.out.print(" mod "); break;
					case 5: System.out.print(" + "); break;
					case 6: System.out.print(" - "); break;
					case 7: System.out.print(" < "); break;
					case 8: System.out.print(" > "); break;
					case 9: System.out.print(" <= "); break;
					case 10: System.out.print(" >= "); break;
					case 11: System.out.print(" == "); break;
					case 12: System.out.print(" != "); break;
					case 13: System.out.print(" and "); break;
					case 14: System.out.print(" or "); break;
					}
					dumparg(ret.args[2], ret.argtypes[2], mytokens);
				}
				else if ((ret.insttype) == 3) // Let Temp[x] = Function(a)
				{
					System.out.print("Temp["+floattostring(ret.args[0])+"] = "+g.textfunction[ret.instflag]+"(");
					for (int n=1; n<ret.numargs; n++)
					{ 
						dumparg(ret.args[n], ret.argtypes[n], mytokens);
						if (n<(ret.numargs-1))
							System.out.print(", ");
					}
					System.out.print(")");
				}
				else if ((ret.insttype) == 4) // Let Temp[x] = a (is this/should this be redundant?)
				{
					System.out.print("Temp["+floattostring(ret.args[0])+"] = ");
					dumparg(ret.args[1], ret.argtypes[1], mytokens); // start from arg[1] - print all...
				}
				else if (((ret.insttype) >= 5) && ((ret.insttype) <= 11)) // Var[instflag] = arg;
				{
					System.out.print(mytokens.myvarnames.get(ret.instflag)+" ");
					//System.out.print(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
					switch (ret.insttype)
					{
					case 5: System.out.print("="); break;
					case 6: System.out.print("+="); break;
					case 7: System.out.print("-="); break;
					case 8: System.out.print("/="); break;
					case 9: System.out.print("*="); break;
					case 10: System.out.print("++"); break;
					case 11: System.out.print("--"); break;
					}
					if (ret.insttype <= 9)
						System.out.print(" ");
					switch (ret.argtypes[0])
					{
					case 0: System.out.print(floattostring(ret.args[0])); break; // Constants
					case 1: System.out.print(mytokens.myvarnames.get((int)ret.args[0])); break; // Variables
					case 3: System.out.print("\""+mytokens.mystrings.get((int)ret.args[0])+"\""); break; // String constants
					case 5: System.out.print("Temp["+floattostring(ret.args[0])+"]"); break;// Temps
					default: System.out.print("ARGERROR! "+ret.argtypes[0]); break; // Added for Java
					}
				}
				else if (((ret.insttype) >= 15) && ((ret.insttype) <= 21)) // brain.var = arg;
				{
					System.out.print(mytokens.myvarnames.get(ret.instflag)+"."+floattostring(ret.args[0])+" ");
					//System.out.print(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
					switch (ret.insttype)
					{
					case 15: System.out.print("="); break;
					case 16: System.out.print("+="); break;
					case 17: System.out.print("-="); break;
					case 18: System.out.print("/="); break;
					case 19: System.out.print("*="); break;
					case 20: System.out.print("++"); break;
					case 21: System.out.print("--"); break;
					}
					if (ret.insttype <= 19)
						System.out.print(" ");
					switch (ret.argtypes[1])
					{
					case 0: System.out.print(floattostring(ret.args[1])); break; // Constants
					case 1: System.out.print(mytokens.myvarnames.get((int)ret.args[1])); break; // Variables
					case 3: System.out.print("\""+mytokens.mystrings.get((int)ret.args[1])+"\""); break; // String constants
					case 5: System.out.print("Temp["+floattostring(ret.args[1])+"]"); break;// Temps
					default: break;
					}
				}
				else if ((ret.insttype) == 50) // Function as Instruction
				{
					System.out.print(g.textfunction[ret.instflag]);
					for (int n=0; n<ret.numargs; n++)
					{
						if (ret.argtypes[n] != -1)
						{
							if (n>0)
								System.out.print(",");
							System.out.print(" ");
							dumparg(ret.args[n], ret.argtypes[n], mytokens);
						}
						else System.out.print(" ARGERROR! "+ret.argtypes[n]); // Added for Java
					}
					//if (ret.numargs <= 0) System.out.print("NOARG"); // Added for Java
				}
				else
				{
					System.out.print("No instruction recognised!");
				}
				System.out.println(""); //System.out.println(";");
			}

			// Display the variables:
			System.out.print("\nVariables ("+mytokens.myvarnames.size()+"): ");
			for (int n=0; n<mytokens.myvarnames.size(); n++)
			{
				System.out.print(mytokens.myvarnames.get(n));
				if (n<mytokens.myvarnames.size()-1)
					System.out.print(", ");
			}
			System.out.print("\n\n\n");
		}
		return 1;
	}

	// For dumpoutputtofile (below):
	int dumpfilearg(BufferedWriter fp, double arg, int argtype, TheTokens mytokens)
	{
		try
		{
			if ((argtype) == 0)
				fp.write(""+arg);
			else if ((argtype) == 1)
				//fp.write(mytokens.myvarnames.get((int)arg)); // Var names without numbers (normal)
				fp.write(mytokens.myvarnames.get((int)arg) + " {"+arg+"}"); // Debug - var names with numbers
			else if ((argtype) == 3)
				fp.write("\""+mytokens.mystrings.get((int)arg)+"\"");
			else if ((argtype) == 5)
				fp.write("Temp["+arg+"]");
			//else if (argtype == -1)
			//	fp.write("???");
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			System.exit(1);
		}
		return 0;
	}
	int olddumpoutputtofile(ArrayList <TheTokens> multitokens, String filename)
	{
		// Added - temp strings:
		//String[] tempargs = new String[30]; // removed for Java - not used!
		//int curtemp=0;

		FileWriter fstream; // added for Java
		BufferedWriter fp;
		// Attempt to open the file:
		try
		{
			fstream = new FileWriter(filename);
			fp = new BufferedWriter(fstream);
		}
		catch (IOException e)
		{
			//if ((fp = fopen(filename, "w"))==null) { // from C++
			System.err.println("Cannot open file!");
			return 0;
		}

		TheTokens mytokens;
		TokeniserReturn ret; //= new tokeniserreturn();

		try
		{
			fp.write("-- The tokenised code:\n");

			for (int tn=0; tn<multitokens.size(); tn++)
			{
				mytokens = multitokens.get(tn);
				fp.write("- Brain "+mytokens.name+" ("+tn+"):\n");

				for (int l=0; l<(mytokens.myparameters.size()); l++)
				{
					ret = mytokens.myparameters.get(l);
					fp.write("("+l+") ");

					// Finally, evaluate the instruction itself:
					if ((ret.insttype) == 1) // Standard Instruction
					{
						//fp.write("Instruction["+ret.instflag+"] (");
						fp.write(g.textinstruction[ret.instflag]);
						for (int n=0; n<ret.numargs; n++)
						{
							if (ret.argtypes[n] != -1)
							{
								if (n>0)
									fp.write(",");
								fp.write(" ");
								dumpfilearg(fp, ret.args[n], ret.argtypes[n], mytokens);
							}
						}
						//fp.write(", "); dumpfilearg(fp, ret.arg2, ret.argtype2, mytokens); fp.write(", "); dumpfilearg(fp, ret.arg3, ret.argtype3, mytokens);
					}
					else if ((ret.insttype) == 2) // Let Temp[x] = a OPERATOR b
					{
						fp.write("Temp["+floattostring(ret.args[0])+"] = ");
						//fp.write("Arg: "+ret.args[1]+", Argtype: "+ret.argtypes[1]);
						dumpfilearg(fp, ret.args[1], ret.argtypes[1], mytokens);
						switch (ret.instflag)
						{
						case 0: fp.write("."); break;
						case 1: fp.write("Not "); break;
						case 2: fp.write(" * "); break;
						case 3: fp.write(" / "); break;
						case 4: fp.write(" mod "); break;
						case 5: fp.write(" + "); break;
						case 6: fp.write(" - "); break;
						case 7: fp.write(" < "); break;
						case 8: fp.write(" > "); break;
						case 9: fp.write(" <= "); break;
						case 10: fp.write(" >= "); break;
						case 11: fp.write(" = "); break;
						case 12: fp.write(" != "); break;
						case 13: fp.write(" and "); break;
						case 14: fp.write(" or "); break;
						}
						dumpfilearg(fp, ret.args[2], ret.argtypes[2], mytokens);
					}
					else if ((ret.insttype) == 3) // Let Temp[x] = Function(a)
					{
						fp.write("Temp["+floattostring(ret.args[0])+"] = "+g.textfunction[ret.instflag]+"(");
						for (int n=1; n<ret.numargs; n++)
						{ 
							dumpfilearg(fp, ret.args[n], ret.argtypes[n], mytokens);
							if (n<(ret.numargs-1))
								fp.write(", ");
						}
						fp.write(")");
					}
					else if ((ret.insttype) == 4) // Let Temp[x] = a (is this/should this be redundant?)
					{
						fp.write("Temp["+floattostring(ret.args[0])+"] = ");
						dumpfilearg(fp, ret.args[1], ret.argtypes[1], mytokens); // start from arg[1] - print all...
					}
					else if (((ret.insttype) >= 5) && ((ret.insttype) <= 11)) // Var[instflag] = arg;
					{
						fp.write(mytokens.myvarnames.get(ret.instflag)+" ");
						//fp.write(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
						switch (ret.insttype)
						{
						case 5: fp.write("="); break;
						case 6: fp.write("+="); break;
						case 7: fp.write("-="); break;
						case 8: fp.write("/="); break;
						case 9: fp.write("*="); break;
						case 10: fp.write("++"); break;
						case 11: fp.write("--"); break;
						}
						if (ret.insttype <= 9)
							fp.write(" ");
						switch (ret.argtypes[0])
						{
						case 0: fp.write(floattostring(ret.args[0])); break; // Constants
						case 1: fp.write(mytokens.myvarnames.get((int)ret.args[0])); break; // Variables
						case 3: fp.write("\""+mytokens.mystrings.get((int)ret.args[0])+"\""); break; // String constants
						case 5: fp.write("Temp["+floattostring(ret.args[0])+"]"); break;// Temps
						default: break;
						}
					}
					else if (((ret.insttype) >= 15) && ((ret.insttype) <= 21)) // brain.var = arg;
					{
						fp.write(mytokens.myvarnames.get(ret.instflag)+"."+floattostring(ret.args[0])+" ");
						//fp.write(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
						switch (ret.insttype)
						{
						case 15: fp.write("="); break;
						case 16: fp.write("+="); break;
						case 17: fp.write("-="); break;
						case 18: fp.write("/="); break;
						case 19: fp.write("*="); break;
						case 20: fp.write("++"); break;
						case 21: fp.write("--"); break;
						}
						if (ret.insttype <= 19)
							fp.write(" ");
						switch (ret.argtypes[1])
						{
						case 0: fp.write(floattostring(ret.args[1])); break; // Constants
						case 1: fp.write(mytokens.myvarnames.get((int)ret.args[1])); break; // Variables
						case 3: fp.write("\""+mytokens.mystrings.get((int)ret.args[1])+"\""); break; // String constants
						case 5: fp.write("Temp["+floattostring(ret.args[1])+"]"); break;// Temps
						default: break;
						}
					}
					else if ((ret.insttype) == 50) // Function as Instruction
					{
						fp.write(g.textfunction[ret.instflag]);
						for (int n=0; n<ret.numargs; n++)
						{
							if (ret.argtypes[n] != -1)
							{
								if (n>0)
									fp.write(",");
								fp.write(" ");
								dumpfilearg(fp, ret.args[n], ret.argtypes[n], mytokens);
							}
						}
					}
					else
					{
						fp.write("No instruction recognised!");
					}
					fp.write("\n"); //fp.write(";\n");
				}

				// Display the variables:
				fp.write("\nVariables ("+mytokens.myvarnames.size()+"): ");
				for (int n=0; n<mytokens.myvarnames.size(); n++)
				{
					fp.write(mytokens.myvarnames.get(n));
					if (n<mytokens.myvarnames.size()-1)
						fp.write(", ");
				}
				fp.write("\n\n\n");
			}
			fp.close();
		}
		catch (IOException e)
		{
			System.err.println("Error writing file!"); // Added for Java
			return 0;
		}
		return 1;
	}

	// For dumpoutputtofile (below):
	String dumpstrarg(BufferedWriter fp, double arg, int argtype, TheTokens mytokens, String[] tempargs)
	{
		if (argtype == 0)
			return floattostring(arg);
		else if (argtype == 1)
			return mytokens.myvarnames.get((int)arg); // Var names without numbers (normal)
		//fp.write(mytokens.myvarnames.get((int)arg)+" {"+arg+"}"); // Debug - var names with numbers
		else if (argtype == 3)
			return "\"" + mytokens.mystrings.get((int)arg) + "\""; //  (%d) ... ,arg);
		else if (argtype == 5)
			return tempargs[(int)arg];
		// Debug:
		//else if (argtype == -1)
		//    fp.write("???");
		return "";
	}
	// For dumpoutputtofile (below):
	int dumpfileargn(BufferedWriter fp, double arg, int argtype, TheTokens mytokens, String[] tempargs)
	{
		try
		{
			if ((argtype) == 0)
				fp.write(""+arg); //fprintf(fp, "%s", floattostring(arg));
			else if ((argtype) == 1)
				fp.write(mytokens.myvarnames.get((int)arg)); // Var names without numbers (normal)
			//fp.write(mytokens.myvarnames.get((int)arg)+" {"+arg+"}");  // Debug - var names with numbers
			else if ((argtype) == 3)
				fp.write("\""+mytokens.mystrings.get((int)arg)+"\""); //  (%d) ... ,arg);
			else if (argtype == 5)
				fp.write(tempargs[(int)arg]);
			// Removed a long time ago:
			//else if ((argtype) == 5)
			//    fp.write("Temp["+arg+"]");

			// Debug:
			//else if (argtype == -1)
			//    fp.write("???");
		}
		catch (IOException e)
		{
			System.err.println("Error dumping to file from dumpfileargn!");
		}
		return 0;
	}
	int dumpoutputtofile(ArrayList <TheTokens> multitokens, String filename)
	{
		// Added - temp strings:
		String[] tempargs = new String[30];
		int indent = 0;
		int lastalways = 0;

		FileWriter fstream; // added for Java
		BufferedWriter fp;
		// Attempt to open the file:
		try
		{
			fstream = new FileWriter(filename);
			fp = new BufferedWriter(fstream);
		}
		catch (IOException e)
		{
			//if ((fp = fopen(filename, "w"))==null) { // from C++
			System.err.println("Cannot open file!");
			return 0;
		}

		TheTokens mytokens;
		TokeniserReturn ret; // = new tokeniserreturn();
		try
		{
			fp.write("-- The tokenised code:\n");

			for (int tn=0; tn<multitokens.size(); tn++)
			{
				mytokens = multitokens.get(tn);
				fp.write("- Brain "+mytokens.name+" ("+tn+"):\n");

				for (int l=0; l<(mytokens.myparameters.size()); l++)
				{
					ret = mytokens.myparameters.get(l);
					//fp.write("("+l+") ");

					// Finally, evaluate the instruction itself:
					if ((ret.insttype) == 1) // Standard Instruction
					{
						int numargstoshow = 0; // Added initialisation for Java
						fp.write("Instruction["+ret.instflag+"] (");

						// If instruction is 'If', display only 1 arg (and add a blank line):
						if (ret.instflag == 6)
						{
							indent++;
							lastalways = 0;

							fp.write("\n");

							for (int o=0; o<indent && ret.instflag != 6; o++)
								fp.write("   ");

							fp.write("If "); // "When" //fp.write(textinstruction[ret.instflag]);

							if (ret.argtypes[0] != -1)
								dumpfileargn(fp, ret.args[0], ret.argtypes[0], mytokens, tempargs);

							fp.write("\n");
						}
						else if (ret.instflag != 7 || ret.instflag != 11)
						{
							numargstoshow = ret.numargs;
							if ((lastalways==0) && (indent==0))
							{
								lastalways = 1;
								//fp.write("\nAlways\n"); // removed
							}
						}

						// In instruction is Endif or }, remove indent (and add a blank line):
						if (ret.instflag == 7 || ret.instflag == 11)
						{
							indent--;
							lastalways = 0;
							//fp.write("\n");
						}
						// Else, display the instruction and args
						else if (ret.instflag != 6)
						{
							for (int o=0; o<indent && ret.instflag != 6; o++)
								fp.write("   ");

							fp.write(g.textinstruction[ret.instflag]);

							for (int n=0; n<numargstoshow; n++)
							{
								if (ret.argtypes[n] != -1)
								{
									if (n>0)
										fp.write(",");
									fp.write(" ");
									dumpfileargn(fp, ret.args[n], ret.argtypes[n], mytokens, tempargs);
								}
							}
							fp.write("\n");
						}
						//fp.write(", "); dumpfilearg(fp, ret.arg2, ret.argtype2, mytokens); fp.write(", "); dumpfilearg(fp, ret.arg3, ret.argtype3, mytokens);
					}
					else if ((ret.insttype) == 2) // Let Temp[x] = a OPERATOR b
					{
						String op = ""; // added initialisation for Java
						tempargs[(int)ret.args[0]] = dumpstrarg(fp, ret.args[1], ret.argtypes[1], mytokens, tempargs);
						if (ret.instflag != 1)
							tempargs[(int)ret.args[0]] = tempargs[(int)ret.args[0]];
						switch (ret.instflag)
						{
						case 0: op = "."; break;
						case 1: op = "Not "; break;
						case 2: op = " * "; break;
						case 3: op = " / "; break;
						case 4: op = " mod "; break;
						case 5: op = " + "; break;
						case 6: op = " - "; break;
						case 7: op = " < "; break;
						case 8: op = " > "; break;
						case 9: op = " <= "; break;
						case 10: op = " >= "; break;
						case 11: op = " = "; break;
						case 12: op = " != "; break;
						case 13: op = " and "; break;
						case 14: op = " or "; break;
						}
						tempargs[(int)ret.args[0]] = tempargs[(int)ret.args[0]] + op + dumpstrarg(fp, ret.args[2], ret.argtypes[2], mytokens, tempargs);
					}
					else if ((ret.insttype) == 3) // Let Temp[x] = Function(a)
					{
						tempargs[(int)ret.args[0]] = g.textfunction[ret.instflag] + "(";
						for (int n=1; n<ret.numargs; n++)
						{ 
							tempargs[(int)ret.args[0]] = tempargs[(int)ret.args[0]] + dumpstrarg(fp, ret.args[n], ret.argtypes[n], mytokens, tempargs);
							if (n<(ret.numargs-1))
								tempargs[(int)ret.args[0]] = tempargs[(int)ret.args[0]] + ", ";
						}
						tempargs[(int)ret.args[0]] = tempargs[(int)ret.args[0]] + ")";
					}
					else if ((ret.insttype) == 4) // Let Temp[x] = a (is this/should this be redundant?)
					{
						tempargs[(int)ret.args[0]] = ("(") + dumpstrarg(fp, ret.args[1], ret.argtypes[1], mytokens, tempargs) + ")";
					}
					else if (((ret.insttype) >= 5) && ((ret.insttype) <= 11)) // Var[instflag] = arg;
					{
						if ((lastalways==0) && (indent==0))
						{
							lastalways = 1;
							//fp.write("\nAlways\n"); // removed
						}

						for (int o=0; o<indent; o++)
							fp.write("   ");

						fp.write(mytokens.myvarnames.get(ret.instflag)+" ");
						//fp.write(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
						switch (ret.insttype)
						{
						case 5: fp.write("="); break;
						case 6: fp.write("+="); break;
						case 7: fp.write("-="); break;
						case 8: fp.write("/="); break;
						case 9: fp.write("*="); break;
						case 10: fp.write("++"); break;
						case 11: fp.write("--"); break;
						}
						if (ret.insttype <= 9)
							fp.write(" ");
						switch (ret.argtypes[0])
						{
						case 0: fp.write(floattostring(ret.args[0])); break; // Constants
						case 1: fp.write(mytokens.myvarnames.get((int)ret.args[0])); break; // Variables
						case 3: fp.write("\""+mytokens.mystrings.get((int)ret.args[0])+"\""); break; // String constants
						case 5: fp.write(tempargs[(int)ret.args[0]]); break;
						//case 5: fp.write("Temp["+floattostring(ret.args[0])+"]"); break; // Temps
						default: break;
						}
						fp.write("\n");
					}
					else if (((ret.insttype) >= 15) && ((ret.insttype) <= 21)) // brain.var = arg;
					{
						if ((lastalways==0) && (indent==0))
						{
							lastalways = 1;
							//fp.write("\nAlways\n"); // removed
						}

						for (int o=0; o<indent; o++)
							fp.write("   ");

						fp.write(mytokens.myvarnames.get(ret.instflag)+"."+floattostring(ret.args[0])+" ");
						//fp.write(mytokens.myvarnames.get(ret.instflag)+" {"+ret.instflag+"} ");
						switch (ret.insttype)
						{
						case 15: fp.write("="); break;
						case 16: fp.write("+="); break;
						case 17: fp.write("-="); break;
						case 18: fp.write("/="); break;
						case 19: fp.write("*="); break;
						case 20: fp.write("++"); break;
						case 21: fp.write("--"); break;
						}
						if (ret.insttype <= 19)
							fp.write(" ");
						switch (ret.argtypes[1])
						{
						case 0: fp.write(floattostring(ret.args[1])); break; // Constants
						case 1: fp.write(mytokens.myvarnames.get((int)ret.args[1])); break; // Variables
						case 3: fp.write("\""+mytokens.mystrings.get((int)ret.args[1])+"\""); break; // String constants
						case 5: fp.write(tempargs[(int)ret.args[1]]); break;
						//case 5: fp.write("Temp["+floattostring(ret.args[1])+"]"); break;// Temps
						default: break;
						}
						fp.write("\n");
					}
					else if ((ret.insttype) == 50) // Function as Instruction
					{
						if ((lastalways==0) && (indent==0))
						{
							lastalways = 1;
							//fp.write("\nAlways\n"); // removed
						}

						for (int o=0; o<indent; o++)
							fp.write("   ");

						fp.write(g.textfunction[ret.instflag]);
						for (int n=0; n<ret.numargs; n++)
						{
							if (ret.argtypes[n] != -1)
							{
								if (n>0)
									fp.write(",");
								fp.write(" ");
								dumpfileargn(fp, ret.args[n], ret.argtypes[n], mytokens, tempargs);
							}
						}
						fp.write("\n");
					}
					else
					{
						if ((lastalways==0) && (indent==0))
						{
							lastalways = 1;
							//fp.write("\nAlways\n"); // removed
						}

						for (int o=0; o<indent; o++)
							fp.write("   ");

						fp.write("No instruction recognised!");
					}
					//fp.write(";\n");
				}

				// Display the variables:
				fp.write("\nVariables ("+ mytokens.myvarnames.size()+"): ");
				for (int n=0; n<mytokens.myvarnames.size(); n++)
				{
					fp.write(mytokens.myvarnames.get(n));
					if (n<mytokens.myvarnames.size()-1)
						fp.write(", ");
				}
				fp.write("\n\n\n");
			}

			fp.close();
		}
		catch (IOException e)
		{
			System.err.println("Error writing file!"); // Added for Java
			return 0;
		}
		return 1;
	}
}
