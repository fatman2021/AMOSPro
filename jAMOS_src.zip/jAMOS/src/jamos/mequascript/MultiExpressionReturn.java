package jamos.mequascript;

public class MultiExpressionReturn
{
	ExpressionReturn[] exp = new ExpressionReturn[20];
	int numexpressions;
}
