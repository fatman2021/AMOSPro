/*

    MequaScript

    (C) 2008-2012 Mequa Innovations

 */

package jamos.mequascript;
import java.util.*;
import java.io.*;

public class MequaScript
{
	boolean OPTIMISE = true;

	Game g = new Game();
	Parser lexer = new Parser(g, OPTIMISE);
	Interpreter interpreter = new Interpreter(g, null);
	Dumper dumper = new Dumper(g);

	// Moved from the main method - for unit testing:
	public int debugtest(String[] args)
	{
		ArrayList <String> textline = new ArrayList<String>();

		// File open:
		try
		{
			FileInputStream fstream = new FileInputStream("test.meq");

			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			// Read File Line By Line
			while ((strLine = br.readLine()) != null)
			{
				// Kill any new lines (is this needed?):
				if (strLine.length() > 0) // added for Java
					if (strLine.charAt(strLine.length()-1) == '\n')
						strLine = strLine.substring(0, strLine.length()-1);

				// Copy the string to the ArrayList:
				textline.add(strLine);
			}

			// Close the input stream
			in.close();
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			System.exit(1);
		}

		//thetokens[] mytokens = new thetokens[100]; //= new thetokens("")[10];

		// Removed - now initialised earlier:
		//g = new Game();
		lexer.inittokens(g.mytokens, 0, "Master");

		// Display raw code:
		System.out.println("- The raw code:");
		for (int n=0; n<textline.size(); n++)
			System.out.println(textline.get(n));
		System.out.println();
		System.out.println();

		// Load the instruction and function names:
		lexer.initinstructions();

		// Tokenise the instructions:
		lexer.evaluateinstructions(textline);

		// Once tokenisation is complete - dump the output (only in this demo):
		dumper.dumpoutput(g.mytokens);
		dumper.dumpoutputtofile(g.mytokens, "dump.txt");

		// For each brain, initialise an object (in myvalues[n]), and set its brain number to the object number (only in this demo):
		for (int n=0; n<g.mytokens.size(); n++)
		{
			ActiveObject temp = new ActiveObject();
			temp.ObjectBrain = n;
			g.ActiveObjects.add(temp);
		}

		// Now initialise the variables of each object:
		for (int n=0; n<g.mytokens.size(); n++)
			interpreter.initvalues(g.mytokens, n);

		// Once tokenisation is complete - interpret and run the code for all the objects!
		System.out.println("Now running the program:");

		// Removed for Java - try 2 iterations
		//for (int nn=0; nn<2; nn++)
		for (int n=0; n<g.ActiveObjects.size(); n++)
		{
			// Added for Java:
			//System.out.println("Brain #"+n+":");
			interpreter.interpret(g.mytokens, n);
		}

		System.out.println("Program complete.");

		// Wait for keypress here:
		/*System.out.println("Press enter to continue...");
	    try
	    {
	    	System.in.read();
	    }
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			System.exit(1);
		}*/

		return 0;
	}

	// The main method - for unit testing:
	public static void main(String[] args)
	{
		MequaScript mequascript = new MequaScript();
		int success = mequascript.debugtest(args);
		if (success == 0)
			System.out.println("Success!");
		else
			System.err.println("Error! "+success);
	}
}
