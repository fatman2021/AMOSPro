package jamos.abkviewer;

// Import the necessary libraries:

import java.awt.Color;

public class AbkDecode
{
	// Added extra classes:
	AbkViewer parent;
	
	// Initialisation methods:
	public AbkDecode(AbkViewer par)
	{
		parent = par;
		init();
	}
    void init()
    {
    }

    // Now for the core part: The ABK loader and processor:
    public void loadSprites(String filename, boolean usefile)
    {
    	// "input" changed from boolean to int:
    	int input = 0;
    	char charfield = 0;
    	String string = "";
    	boolean foundbank = false;
    	
    	if (parent.usefilebuffer)
    		parent.filebuffer = parent.abkfile.loadfiletobuffer(filename, usefile);
    	else
    		parent.abkfile.in = parent.abkfile.openbinaryfile(filename, usefile);
    	
    	// TO DO - give error if needed:
    	if (parent.abkfile.in == null)
    	{
    		System.err.println("Error opening file!");
    		return;
    	}
    	
    	// First check the first 4 characters:
    	for (int a=0; a<4; a++)
    	{
    		input = parent.abkfile.getnextbyte();
    		charfield = (char)(input);
    		string += Character.toString(charfield);
    	}
    	
    	if (string.length()==4 && string.equals("AmSp"))
    	{
    		//System.out.println("AMOS Sprite Bank");
    		foundbank = true;
    		parent.icon = false;
    	}
    	else if (string.length()==4 && string.equals("AmIc"))
    	{
    		//System.out.println("AMOS Icon Bank");
    		foundbank = true;
    		parent.icon = true;
    	}
    	else if (string.length()==4)
    	{
    		if (string.length()==4 && string.equals("AmBk"))
    		{
    			System.out.println("Wrong type of AMOS Bank. Only Sprite/Object/Bob and Icon type are supported. Quitting.");
    		}
    		else
    		{
    			System.out.println("Not an AMOS bank. Quitting.");
    		}
    		foundbank = false;
    		parent.abkfile.closebinaryfile(parent.abkfile.in);
    		return;
    	}
    	
    	// Exit if bank not found:
    	if (!foundbank)
    		(parent.abkfile).closebinaryfile((parent.abkfile).in);
    	
    	string = "";
    	
    	// Now try to find the number of objects:
    	parent.numobjects = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte());
    	//System.out.println("Number of Objects: "+numobjects);
    	
    	parent.image = new int[parent.numobjects][][];
    	parent.xsize = new int[parent.numobjects];
    	parent.ysize = new int[parent.numobjects];
    	parent.bitplanes = new int[parent.numobjects];
    	parent.xhandle = new int[parent.numobjects];
    	parent.yhandle = new int[parent.numobjects];
    	
    	// Now parse each object in turn to get its details:
    	for (int obj=0; obj<parent.numobjects; obj++)
    	{
    		parent.xsize[obj] = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte())*16;
    		parent.ysize[obj] = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte());
    		parent.bitplanes[obj] = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte());
    		parent.xhandle[obj] = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte());
    		parent.yhandle[obj] = ((parent.abkfile).getnextbyte()<<8)|((parent.abkfile).getnextbyte());
    		//System.out.println("For Object "+obj+": X_Size="+xsize[obj]+", Y_Size="+ysize[obj]+
    		//		", Bitplanes="+bitplanes[obj]+", X_Hot_Spot="+xhandle[obj]+", Y_Hot_Spot="+yhandle[obj]);
    		
    		// Allocate an array to hold the converted bitmap:
    		parent.image[obj] = new int[parent.xsize[obj]][parent.ysize[obj]];
    		//System.out.println("Image size: " + parent.xsize[obj]+", "+parent.ysize[obj]);
    		// Clear the buffer:
    		for (int x=0; x<parent.xsize[obj]; x++)
    			for (int y=0; y<parent.ysize[obj]; y++)
    				parent.image[obj][x][y] = 0;
    		
    		// Now parse the bitmap itself:
    		int bitmap;
    		
    		for (int bitplane=0; bitplane<parent.bitplanes[obj]; bitplane++)
    		{
    			// Clear the bitmap - add each bit on in turn:
    			bitmap = 0;
    			
    			// Parse the X and Y here:
    			for (int y=0; y<parent.ysize[obj]; y++)
    			{
    				for (int x=0; x<parent.xsize[obj]; x+=16)
    				{
    					int bit=0;
    					
    					// Grab the 16-bit bitmap segment here:
    					bitmap = ((parent.abkfile).getnextbyte()*256)+((parent.abkfile).getnextbyte());
    					
    					// Now parse and manipulate the bits and convert to chunky byte format:
    					for (int bitnum=0; bitnum<16; bitnum++)
    					{
    						// Get least significant bit:
    						bit = bitmap & 1;
    						
    						// Shift down:
    						bitmap >>= 1;
    						
    				    	// Now add to the chunky paletted buffer:
    						parent.image[obj][x+(15 - bitnum)][y] |= (bit << bitplane);
    					}
    				}
    			}
    		}
    	}

    	// Finally after all objects are processed, get the sprite palette details.
    	// This is always 32 colours:
    	int entry;
    	int red, green, blue;
    	
    	// Create extra indexes if using half bright mode:
    	if (parent.usehalfbright)
    	{
    		parent.palette = new int[64];
    		parent.colorpalette = new Color[64];
    	}
    	else
    	{
    		parent.palette = new int[32];
    		parent.colorpalette = new Color[32];
    	}
    	// Note: Always uses 32 colours for the sprite palette.
    	for (int index=0; index<32; index++)
    	{
    		entry = ((parent.abkfile).getnextbyte()<<8) + (parent.abkfile).getnextbyte();
    		parent.palette[index]=entry;
    		//System.out.println("Colour "+index+": "+Integer.toHexString(entry));
    		// Now get the red, green and blue values
    		// Bitwise AND to separate colour entries:
    		red   = (entry & 0xF00) / 0x100;
    		green = (entry & 0x0F0) / 0x10;
    		blue  = (entry & 0x00F);
    		
    		// Added: For 64 colour mode - 6 bitplanes on sprite images: Do the old-skool palette half-bright (may incur rounding):
    		// If the 24-bit/32-bit buffer need be dropped, this may work as a fall-back - but then implement EHB directly (TO DO):
    		if (parent.usehalfbright)
    			parent.palette[index + 32] = ((red/2) * 0x100) + ((green/2) * 0x10) + (blue/2);
    		
    		// Multiply by 0x11 (17) to scale 0xFFF to 0xFFFFFF
    		// Multiply by 0x11 (17) to convert 0xF (15) into 0xFF (255):
    		red   *= 0x11;
    		green *= 0x11;
    		blue  *= 0x11;
    		parent.colorpalette[index]=new Color(red, green, blue); //, index);
    		
    		// Added: For 64 colour mode: Do the half-bright 24-bit/32-bit palette index (if appropriate):
    		// Note that this uses true 24-bit brightness halving.
    		if (parent.usehalfbright)
    			parent.colorpalette[index + 32]=new Color(red / 2, green / 2, blue / 2); //, index);
    	}
    	
    	// The file can be closed now if not using a buffer (otherwise it is closed earlier):
    	if (!(parent.usefilebuffer))
    		(parent.abkfile).closebinaryfile((parent.abkfile).in);
    	
    	// Before drawing the image, create a 32-bit 2D array:
    	parent.image32 = new Color[parent.numobjects][][];
    	for (int obj=0; obj<parent.numobjects; obj++)
    		parent.image32[obj] = new Color[parent.xsize[obj]][parent.ysize[obj]];
    	
    	// Create a 24-bit/32-bit Color image array:
    	for (int obj=0; obj<parent.numobjects; obj++)
    		for (int y=0; y<parent.ysize[obj]; y++)
    			for (int x=0; x<parent.xsize[obj]; x++)
    				parent.image32[obj][x][y] = parent.colorpalette[parent.image[obj][x][y]];
    }
    
    // TO DO: Uncompressed IFF ILBM support:
    // Import Amiga .Iff ILBM picture files directly.
    public void loadIff(String fname, boolean usefile) //, Graphics2D g)
    {
    	// TODO: Remove Amiga path from filename:
    	// Removed - from Jamagic version:
    	//fname=(fname.SubString((fname.LastIndexOf(":")+1))); fname=(fname.SubString((fname.LastIndexOf("/")+1)));
    	
    	// Uses a file buffer by default now (usefilebuffer=true).
    	if (parent.usefilebuffer)
    	{
    		parent.filebuffer = (parent.abkfile).loadfiletobuffer(fname, usefile);
    	}
    	else
    	{
    		(parent.abkfile).in = (parent.abkfile).openbinaryfile(fname, usefile);
    		// TO DO - give error if needed:
    		if ((parent.abkfile).in == null)
    			return;
    	}
    	
    	int realfsize = (parent.filebuffer).length;
    	System.out.println("Real file size: "+realfsize);
    	
    	////fsize=41146;
    	int ofs;
    	ofs=1808; // ofs=640*3-112; //114 113
    	
    	// Reimplemented above - From Jamagic version:
    	//Var myBinary = New Binary(fname);  // Removed - from Jamagic version
    	//Var myBinary.SetByteOrdering(Binary.BIG_ENDIAN);  // Removed - from Jamagic version

    	// First set the default size and number of bits:
    	int xSize=320;
    	int ySize=256; //200;
    	int numBits=4;

    	//// TO DO - get correct width and height values.
    	//xSize=am.ScreenWidth[am.Currentscreen];  // Removed - from Jamagic version
    	//ySize=am.ScreenHeight[am.Currentscreen];  // Removed - from Jamagic version

    	int objMatrix[]=new int[xSize];

    	for (int n=0; n<xSize; n++)
    		objMatrix[n]=0;
    	//FillArray(objMatrix,0,320);
    	
    	int fsize = (xSize*ySize*numBits + ofs)/8 + 1;
    	//AMOS_Sys.RunningAdvancedScreenUpdate = TRUE; // Removed - from Jamagic version
    	
    	// Added: Create the new arrays:
    	parent.iffimage = new int[xSize][ySize];
    	parent.iffimage32 = new Color[xSize][ySize];
    	
    	parent.iffxsize = xSize;
    	parent.iffysize = ySize;

    	for (int n=0; (n<fsize) && (n<realfsize); n+=2)
    	{
    		//System.out.println("Debug: Reading a word of two bytes from byte offset n="+n);
    		int i, j, b;
    		//i = (parent.abkfile).getnextword();
    		i = ((parent.abkfile).getnextbyte() << 8) + (parent.abkfile).getnextbyte();
    		//i = myBinary.GetWord(n);
    		
    		b = 32768;
    		for (int bits=0; bits<16; bits++)
    		{
    			//System.out.println("Debug: Processing bit number "+(bits+1)+" out of 16:");
    			
    			j = i & b;
    			int scpos = (n*8)+bits-ofs;
    			int whichbit = (scpos/xSize) % numBits;
    			////whichbit = Math.Round(scpos/XSize) - (Math.Round(scpos/(XSize*NumBits))*NumBits); // was removed long ago
    			
    			// Note: This was rounded down (was Math.round() (Jamagic) or Math.floor()).
    			
    			//int scpos2 = scpos-((scpos/(xSize*numBits))*(xSize*(numBits-1)));
    			int scpos2 = scpos-((scpos*(numBits-1))/(numBits));
    			
    			//scpos2 = scpos-(xSize*whichbit); // was removed long ago
    			int ypos=scpos2/xSize;
    			int xpos=scpos2-(ypos*ySize);
    			
    			if (xpos == 0)
    				System.out.println("xpos="+xpos+", ypos="+ypos+", whichbit="+whichbit);
    			
    			//System.out.println("Debug: Doing a test now!");
    			if ((xpos==0) && (ypos>0) && (whichbit == 0))
    			{
    				System.out.println("Debug: Processing each xplot value now!");
    				for (int xplot=0; xplot<xSize; xplot++)
    				{
    					// TO DO: Here set the appropriate value in a Color[][] array
    					
    					// TO DO: Here set the appropriate ink value:
    					//System.out.println("Debug: x="+xplot+", y="+(ypos-1)+", xplot = "+xplot+", Colour value to set: " + objMatrix[xplot]);
    					
    					// Removed - no AWT in this class:
    					//g.setColor(Color.BLUE); // debug
    					
    					//g.setColor(objmatrix[xplot]); // using 32-bit array (memory hungry) // needs converting to colour type!
    					//A_SetInk(Objmatrix[xplot]); // Removed - from Jamagic version.
    					
    					// TO DO: Here plot to screen (later move):
    					// Plot the sprite using drawLine for now:
    					// Allow for scale:
        				
    					// Removed - no AWT in this class:
    					//for (int l=0; l<scale; l++)
    					//	g.drawLine(xplot * scale, (ypos-1) * scale + l, xplot * scale + (scale - 1), (ypos-1) * scale + l);
        				
        				//System.out.println("Plotting here at x="+(xplot)+", y="+(ypos-1)+", colour value = " + objMatrix[xplot]);
    					//A_Plot(xplot,ypos-1); // Removed - from Jamagic version.
    					////AMOS_Sys.Screens[AMOS_Sys.CurrentScreen].SetPixel(xplot, ypos-1, Objmatrix[xplot]); // was removed long ago
    					
    					if (((ypos-1) >= 0) && ((ypos-1)<ySize))
    						parent.iffimage[xplot][ypos-1] = objMatrix[xplot];
    					
        				if (xplot < xSize) // Is this test needed???
        					objMatrix[xplot] = 0;
    				}
    			}
    			else
    			{
    				//System.out.println("Debug: Fail!");
    			}
    			
    			int planaradd = 1;
    			if (whichbit < (numBits-1))
    				for (int temp=0; temp<=whichbit; temp++)
    					planaradd=planaradd*2;

    			// Added: Size safety:
    			if (xpos < xSize)
    				if ((j/b >0) && (scpos>=0))
    					objMatrix[xpos] += planaradd;

    			b >>= 1;
    		}
    	}

    	// The file can be closed now if not using a buffer (otherwise it is closed earlier):
    	if (!(parent.usefilebuffer))
    		(parent.abkfile).closebinaryfile((parent.abkfile).in);
    	
    	// Before drawing the image, create a 32-bit 2D array:
    	parent.iffimage32 = new Color[xSize][ySize];
    	
    	// TODO - create new colorpalette if not existing:
    	//parent.colorpalette = {1, 2, 3};
    	
    	// Create a 24-bit/32-bit Color image array:
    	for (int y=0; y<ySize; y++)
    		for (int x=0; x<xSize; x++)
    			parent.iffimage32[x][y] = new Color(parent.iffimage[x][y] * 16);
    			//parent.iffimage32[x][y] = parent.colorpalette[parent.iffimage[x][y]];
    }
}
