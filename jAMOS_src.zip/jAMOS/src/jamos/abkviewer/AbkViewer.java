package jamos.abkviewer;

// Import the necessary libraries:

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class AbkViewer implements Runnable
{
	// Added extra classes:
	public AbkFile abkfile;
	public AbkGfx abkgfx;
	public AbkDecode abkdecode;
	
	// Added: Support for Extra Half-Bright (EHB) images allowing 64 colours with a 32-colour palette.
	boolean usehalfbright = true;
	boolean useaga = false;
	boolean useham = false;
	
	// Added - define loading algorithm, load all at once or stream the file:
	boolean usefilebuffer = true;
	byte[] filebuffer = null;
	boolean runasmainclass = false;
	
	// Fields for the Abk sprite/icon loader:
	String[] inputargs;
	DisplayPanel panel;
	JFrame frame;
	
	String filename;
	int[] palette;
	Color[] colorpalette;
	Color image32[][][];
	int image[][][];
	Color iffimage32[][];
	int iffimage[][];
	public int xsize[];
	public int ysize[];
	int bitplanes[];
	int xhandle[];
	int yhandle[];
	public int numobjects;
	boolean icon = false;
	int scale;
	
	// Added for IFF (experimental):
	int iffxsize;
	int iffysize;
	int iffbitplanes;
	
	int numObjects() { return numobjects; }
	
	// The display panel class:
	class DisplayPanel extends JPanel
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 4116557920108266855L;
		// Note: The above was added by Eclipse IDE.
		
		AbkViewer mainclass;
		
		// Initialisation method:
		DisplayPanel(AbkViewer mainclass_)
		{
			mainclass = mainclass_;
		}
		
		// Used to update the graphics:
		public void paintComponent(Graphics _g)
		{
			// Needed for historical Java reasons:
			super.paintComponent(_g);
			Graphics2D g = (Graphics2D) _g;
			
			(mainclass.abkgfx).drawall(g);
		}
	}
	
	// Used with "implements Runnable" to create the frame on another thread:
	public void run()
	{
		// Select run as a main class:
		runasmainclass = true;
		
		// Create the frame:
		createframe();
	}
	
	// The main entry method for the program:
	public static void main(String[] args)
	{
		// Here check if file is already specified:
		String filename = "";
		if (args.length > 0)
			filename=args[0];
		
		// Create an object for the program:
		// Initialise and display the AbkSprites (graphical) class, default scale 2:
		AbkViewer program = new AbkViewer(filename, 2);
		program.init();
		
		// Select run as a main class:
		program.runasmainclass = true;
		
		// Launch the program on another thread
		//removed - requires implements Runnable:
		SwingUtilities.invokeLater(program);
		
		//// Now launch the GUI as appropriate (or on another thread):
		//program.createframe();
	}
	// Used to launch as a main class:
	public void createframe()
	{
		// Create the graphical window:
		if (icon)
			frame = new JFrame("AMOS Icon Bank Viewer - "+filename);
		else
			frame = new JFrame("AMOS Sprite Bank Viewer - "+filename);
		
		// Added for jAMOS integration - close on exit only if running as a main class:
		if (runasmainclass)
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.add(panel);
		frame.pack();
		frame.setLocationByPlatform(true);
		frame.setVisible(true);
	}
	
	// Initialisation methods:
	AbkViewer(String arg, int sc)
	{
		// Store the bank filename and scale number in the class:
		filename = arg;
		scale = sc;
	}
	AbkViewer(String arg)
	{
		// Store the bank filename and scale number in the class:
		filename = arg;
		scale = 1;
	}
	public AbkViewer(int sc)
	{
		// Store the bank filename and scale number in the class:
		filename = "";
        scale = sc;
    }
	public AbkViewer()
	{
		// Store the bank filename and scale number in the class:
		filename = "";
        scale = 1;
    }
    public void init()
    {
        // Load a file selector if appropriate:
    	String[] filenamearray = new String[2];
    	
    	abkfile = new AbkFile(this, filenamearray[0]);
    	abkgfx =  new AbkGfx(this);
    	abkdecode = new AbkDecode(this);
    	
    	filenamearray = abkfile.selectfile_native(filename);
    	filename = filenamearray[1]; // For title
        //filename = selectfile(filename);
        
    	// Load the sprites into memory:
    	abkdecode.loadSprites(filenamearray[0], true);

        // Create the panel here:
        panel = new DisplayPanel(this);

        // Set the initial size to 640x480 and setup the GUI:
        panel.setPreferredSize(new Dimension(640, 480));
    }
}
