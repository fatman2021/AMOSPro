package jamos.abkviewer;

// Import the necessary libraries:

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class AbkGfx
{
	// Added extra classes:
	AbkViewer parent;
	
	// Added for creating an image:
	Graphics2D g2 = null;
	Image offImg = null;
	Graphics2D[] testgraphic;
	Image[] testimage;

	// Expanded to support Extra Half-Bright palette:
	int SpritePaletteEntry(int index)
	{
		if ((!parent.usehalfbright) || (index < 32))
			return parent.palette[index];
		else
			return parent.palette[index % 32];
	}
	//int SpritePaletteEntry(int index) { return palette[index]; }
	
	//int palettedPixel(int obj, int x, int y) { return parent.image[obj][x][y]; }
	int objectWidth(int obj) { return parent.xsize[obj]; }
	int objectHeight(int obj) { return parent.ysize[obj]; }
	int objectBitplanes(int obj) { return parent.bitplanes[obj]; }
	int objectHotSpotX(int obj) { return parent.xhandle[obj]; }
	int objectHotSpotY(int obj) { return parent.yhandle[obj]; }
	
	Color colorPixel(int obj, int x, int y) { return parent.image32[obj][x][y]; }
	Color iffColorPixel(int x, int y) { return parent.iffimage32[x][y]; }
	
	// Expanded to support Extra Half-Bright palette:
	//Color colorSpritePaletteEntry(int index) { return colorpalette[index]; }
	Color colorSpritePaletteEntry(int index)
	{
		if ((!parent.usehalfbright) || (((index / 32) % 2) == 0))
			return parent.colorpalette[index % 32];
		else
			return getHalfBrite(parent.colorpalette[(index % 64) % 32]);
	}
	// This version does not round down to a 12-bit palette.
	// Query: Would that be required as an option for legacy purposes?
	Color getHalfBrite(Color victim)
	{
		int red, green, blue;
		red = victim.getRed()/2; green=victim.getGreen()/2; blue=victim.getBlue()/2;
		return new Color(red, green, blue);
	}
	
	int numObjects() { return parent.numobjects; }
	
	
	// Initialisation methods:
	public AbkGfx(AbkViewer par)
	{
		parent = par;
		init();
	}
    void init()
    {
       
    }

    public void plotsprites(Graphics2D g, int scale, int dispwidth, int dispheight, boolean usehotspots)
    {
    	// Now draw each image using the sprite palette:
    	// Here we intelligently position each image:

        int xinitialposition=0;
        int yinitialposition=0; // the top-left border // was 2,2 - use hotspots now!

        // Calculate the max x and y hot spot (handle) positions and set the initial position accordingly:
        if (usehotspots)
        for (int obj=0; obj<parent.numobjects; obj++)
        {
            if (xinitialposition < objectHotSpotX(obj))
            	xinitialposition = objectHotSpotX(obj);
            if (yinitialposition < objectHotSpotY(obj))
            	yinitialposition = objectHotSpotY(obj);
        }

        // Add small offset:
        xinitialposition += 2;
        yinitialposition += 2;

        int xspace=10;
        int yspace=10; // gap between sprites

        int width = dispwidth;
        //int height = dispheight; // make dynamic

        int xposition = xinitialposition;
        int yposition = yinitialposition;

        // Here clear the background to colour index 0 (was Color.BLACK):
        // MOVED!
        //g.setBackground(colorSpritePaletteEntry(0));
        //g.setColor(colorSpritePaletteEntry(0));
        //g.fillRect(0, 0, width, height);

        int maxy=0;
        for (int obj=0; obj<parent.numobjects; obj++)
        {
        	for (int y=0; y<parent.ysize[obj]; y++)
        	{
        		if (y>maxy)
        			maxy=y;
        		for (int x=0; x<parent.xsize[obj]; x++)
        		{
        			int paletteindex = parent.image[obj][x][y];
        			if (paletteindex > 0)
        			{
        				g.setColor(colorPixel(obj, x, y)); // using 32-bit array (memory hungry)
        				//g.setColor(colorSpritePaletteEntry(paletteindex)); // using palette index
        				
        				// Plot the sprite using drawLine for now:
        				// Enlarged version with support for scale and positioning (with optional hot spot/image handle support):
        				if (usehotspots)
        					for (int l=0; l<scale; l++)
        						g.drawLine((x + xposition - objectHotSpotX(obj)) * scale,
        								(y + yposition - objectHotSpotY(obj)) * scale + l,
        								(x + xposition - objectHotSpotX(obj)) * scale + (scale - 1),
        								(y + yposition - objectHotSpotY(obj)) * scale + l);
        				else
        					for (int l=0; l<scale; l++)
        						g.drawLine((x + xposition) * scale, (y + yposition) * scale + l,
        								(x + xposition) * scale + (scale - 1), (y + yposition) * scale + l);
        			}
        		}
        	}
        	xposition += parent.xsize[obj] + xspace; // Distance between drawn objects
        	if ((xposition + objectWidth(obj)) > ((width - xinitialposition) / scale))
        	{
        		xposition = xinitialposition;
        		yposition += maxy + yspace;
        	}
        }
        
        // Now resize the JPanel and JFrame (TO DO)
        if (xposition > xinitialposition)
        	yposition += maxy + yspace;
        //setPreferredSize(new Dimension(width, yposition*scale));
        //System.out.println("Current height: "+height+", new height: "+yposition*scale);
    }
    
    public void simpleplotsprite(Graphics2D g, int spritenum, int scale)
    {
    	// Draw a sprite image using the sprite palette:
    	
    	//// Here clear the sprite background to black:
    	//// TO DO - needs to be transparent!
    	//g.setBackground(Color.BLACK);
    	//g.setColor(Color.BLACK);
    	//g.fillRect(0, 0, objectWidth(spritenum), objectHeight(spritenum));
    	
    	for (int y=0; y<parent.ysize[spritenum]; y++)
    		for (int x=0; x<parent.xsize[spritenum]; x++)
    		{
    			int paletteindex = parent.image[spritenum][x][y];
    			if (paletteindex > 0)
    			{
    				g.setColor(colorPixel(spritenum, x, y)); // using 32-bit array (memory hungry)
    				//g.setColor(colorSpritePaletteEntry(paletteindex)); // using palette index
    				
    				// Plot the sprite using drawLine for now:
					// Allow for scale:
    				for (int l=0; l<scale; l++)
						g.drawLine(x * scale, y * scale + l, x * scale + (scale - 1), y * scale + l);
    				//for (int l=0; l<scale; l++)
    				//	g.drawLine(x, y, x, y);
    			}
    		}
    }
    
    public void simpleplotiff(Graphics2D g, int scale)
    {
    	// Draw a sprite image using the sprite palette:
    	
    	//// Here clear the sprite background to black:
    	//// TO DO - needs to be transparent!
    	//g.setBackground(Color.BLACK);
    	//g.setColor(Color.BLACK);
    	//g.fillRect(0, 0, objectWidth(spritenum), objectHeight(spritenum));
    	
    	for (int y=0; y<parent.iffysize; y++)
    		for (int x=0; x<parent.iffxsize; x++)
    		{
    			//int paletteindex = parent.iffimage[x][y];
    			//if (paletteindex > 0)
    			{
    				g.setColor(iffColorPixel(x, y)); // using 32-bit array (memory hungry)
    				
    				// Plot the sprite using drawLine for now:
					// Allow for scale:
    				for (int l=0; l<scale; l++)
						g.drawLine(x * scale, y * scale + l, x * scale + (scale - 1), y * scale + l);
    			}
    		}
    }
    
	// First test image creation:
    public void getimages(int scale)
    {
    	// First get the images:
    	if ((testgraphic != null) && (testimage != null))
    		return;
    	testgraphic = new Graphics2D[numObjects()];
    	testimage = new Image[numObjects()];
    	for (int n=0; n<numObjects(); n++)
    	{
    		testgraphic[n] = createSpriteGraphics2D(n, scale);
    	    testimage[n] = offImg;
    	}
    }
    
    // Based on the plotter algorithm above - draws the sprites in a much more efficient manner:
    public void drawimages(Graphics2D g, int scale, int dispwidth, int dispheight, boolean usehotspots)
    {
        	// Now draw each image using the sprite palette:
        	// Here we intelligently position each image:

            int xinitialposition=0;
            int yinitialposition=0; // the top-left border // was 2,2 - use hotspots now!

            // Calculate the max x and y hot spot (handle) positions and set the initial position accordingly:
            if (usehotspots)
            for (int obj=0; obj<parent.numobjects; obj++)
            {
                if (xinitialposition < objectHotSpotX(obj))
                	xinitialposition = objectHotSpotX(obj);
                if (yinitialposition < objectHotSpotY(obj))
                	yinitialposition = objectHotSpotY(obj);
            }

            // Add small offset:
            xinitialposition += 2;
            yinitialposition += 2;

            int xspace=10;
            int yspace=10; // gap between sprites

            int width = dispwidth;
            //int height = dispheight; // make dynamic

            int xposition = xinitialposition;
            int yposition = yinitialposition;
            
            int maxy=0;
        	// Now draw the images:
            for (int obj=0; obj<numObjects(); obj++)
            {
        		offImg = testimage[obj];
        		//g.drawImage(offImg, obj*128, 100, null);
        		
				// Enlarged version with support for scale and positioning (with optional hot spot/image handle support):
				if (usehotspots)
					g.drawImage(offImg, (xposition - objectHotSpotX(obj)) * scale, (yposition - objectHotSpotY(obj)) * scale, null);
				else
					g.drawImage(offImg, xposition * scale, yposition * scale, null);
        		
				// Get the maximum height so far:
            	for (int y=0; y<parent.ysize[obj]; y++)
            		if (y>maxy)
            			maxy=y;
            	
            	xposition += parent.xsize[obj] + xspace; // Distance between drawn objects
            	if ((xposition + objectWidth(obj)) > ((width - xinitialposition) / scale))
            	{
            		xposition = xinitialposition;
            		yposition += maxy + yspace;
            	}
            }
            
            // Now resize the JPanel and JFrame (TO DO)
            if (xposition > xinitialposition)
            	yposition += maxy + yspace;
    }
    
    // Create a Java AWT image:
    public Graphics2D createSpriteGraphics2D(int spritenum, int scale)
    {
    	g2 = null;
    	offImg = null; // reset the image
    	
    	int width = parent.xsize[spritenum];
    	int height = parent.ysize[spritenum];
    	
    	//if (offImg == null || ( (((Image)offImg).getWidth()) != width) || offImg.getHeight() != height)
    	
    	// Added to allow for empty sprites:
    	if ((width>0) && (height>0))
    		offImg = (BufferedImage) parent.frame.createImage(width*scale, height*scale);
    	
    	if (offImg != null)
    	{
    		g2 = ((BufferedImage)offImg).createGraphics();
    		g2.setBackground(Color.black);// (frame.getBackground());
            g2.setBackground(colorSpritePaletteEntry(0));
            g2.setColor(colorSpritePaletteEntry(0));
    	}
    	
    	if (g2 != null)
    	{
    		// Clear canvas - TO DO - make transparent:
    		g2.clearRect(0, 0, width*scale, height*scale);
    		
    		// Now draw the sprite on the canvas:
    		simpleplotsprite(g2, spritenum, scale);
    	}
    	return g2;
    }
    
    /*void drawoverlapping(Graphics2D g)
    {
        // Example to simply draw each sprite overlapping:
        for (int obj=0; obj<numobjects; obj++)
            simpleplotsprite(g, 0);
    }*/
    
    public void drawspritepaletteasband(Graphics2D g, int x, int y, int h, int numcolours)
    {
    	int size = 16;
    	
    	numcolours = 32;
    	if (parent.usehalfbright)
    		numcolours = 64;
    	
    	// Draw the sprite palette as coloured bands:
    	for (int index=0; index < numcolours; index++)
    	{
    		// Now draw the palette entry as a line:
    		g.setColor(colorSpritePaletteEntry(index));
    		for (int col=0; col < size; col++)
    		   g.drawLine(x + (index * size) + col, y, (index * size) + col, y + h);
    	}
    }
    
    // Used to update the graphics:
    public void drawall(Graphics2D g)
    {
    	// Clear the canvas:
        // Here clear the background to colour index 0 (was Color.BLACK):
        // MOVED!
        g.setBackground(colorSpritePaletteEntry(0));
        g.setColor(colorSpritePaletteEntry(0));
        g.fillRect(0, 0, (parent.panel).getWidth(), (parent.panel).getHeight());
        
        // Calculate the maximum number of bitplanes used:
        int numplanes = 0;
        //int numcolours = 1;
        for (int n=0; n<numObjects(); n++)
        	if (numplanes < objectBitplanes(n))
        		numplanes = objectBitplanes(n);
        
        if ((numplanes == 6) && !parent.useaga && !parent.useham)
        	parent.usehalfbright = true;
        
        // Now calculate the corresponding maximum number of colours used:
        //numcolours = 1;
        //for (int n=0; n<numplanes; n++)
        //	numcolours *= 2;
        //System.out.println("Number of colours used in bank: "+numcolours+" over "+numplanes+" bitplanes.");
        
        // Removed: Draw the sprite palette as a strip of colour:
        //drawspritepaletteasband(g, 0, 200, 64, numcolours);
        
        // Create the Java AWT images from the sprite bank if appropriate:
        getimages(parent.scale);
        
        // Now to actually draw the sprites:
        drawimages(g, parent.scale, (parent.panel).getWidth(), (parent.panel).getHeight(), false);
        //plotsprites(g, scale, panel.getWidth(), panel.getHeight(), false); // update display size here!

        // Test: Load Iff:
        //loadIff("NOIDTITLE.IFF", g);
        //loadIff("D:\\Users\\Student\\Documents\\NOIDTITLE.IFF", g);
        
        //drawoverlapping(g);
    }

    
}
