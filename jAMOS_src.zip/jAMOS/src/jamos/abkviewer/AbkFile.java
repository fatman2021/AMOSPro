package jamos.abkviewer;

// This class provides file access for the AbkViewer class.

// Import the necessary libraries:

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.awt.FileDialog;
import java.awt.Frame;

public class AbkFile
{
	// Added - define loading algorithm, load all at once or stream the file:
	AbkViewer parent;
	File file;
	String filename;
	int bufferposition;
	InputStream in;
	int filesize = 0;

	Class<?> defaultclass;

	// Initialisation methods:
	public AbkFile(AbkViewer par, String arg, Class<?> dclass)
	{
		// Store the bank filename in the class:
		filename = arg;
		parent = par;
		defaultclass = dclass;
		init();
	}
	public AbkFile(AbkViewer par, String arg)
	{
		// Store the bank filename in the class:
		filename = arg;
		parent = par;
		defaultclass = getClass();
		init();
	}
	public AbkFile(AbkViewer par)
	{
		// Store the bank filename in the class:
		filename = "";
		parent = par;
		defaultclass = getClass();
		init();
	}
	void init()
	{
		// Load a file selector if appropriate:
		//String[] filenamearray = new String[2];

		//filenamearray = selectfile_native(filename);
		//filename = filenamearray[1]; // For title
		//filename = selectfile(filename);
	}

	String[] selectfile_native(String fname)
	{
		// Create a file selector if appropriate:
		boolean usefilereq = false;
		//int returnVal = 0;

		if (fname == null)
			usefilereq = true;
		else if (fname.equals(""))
			usefilereq = true;

		if (!usefilereq)
		{
			// Here split the filename into 2 parts, complete and name only (for display):
			File file = new File(fname);
			return new String[]{file.getAbsolutePath(), file.getName()};
			//return new String[]{"", fname};
		}

		// Use an OS-native file requester:
		FileDialog fd = new FileDialog(new Frame(), "Load an .abk Sprite or Icon file", FileDialog.LOAD);

		// Save and set default name
		// TO DO - may need to move to another thread:
		fd.setFile("Sprites.Abk");
		fd.setDirectory("."); //.\\");
		fd.setLocation(50, 50);
		fd.setVisible(true); //fd.show(); // fix this!

		// Set global field:
		filename = fd.getFile();

		return new String[]{fd.getDirectory()+"/"+fd.getFile(), fd.getFile()};
		//System.out.println("Testing: Load file: \""+fname+"\"");
	}

	// Deprecated - use Java Swing-based file selector. OS-native is preferable.
	/*String selectfile(String filename)
    {
        // Create a file selector if appropriate:
        boolean usefilereq = false;
        int returnVal = 0;

        if (filename == null)
           usefilereq = true;
        else if (filename.equals(""))
           usefilereq = true;

        if (!usefilereq)
        	return filename;

        // Set dummy/debug filename:
        //filename = "Bugs.Abk";

        // Create a file chooser
        final JFileChooser chooser;

        chooser = new JFileChooser();

        //JFileFilter filter = new JFileFilter();
        //filter.addExtension("abk");
        //filter.setDescription("Amiga AMOS Sprite Banks (.abk)");
        //chooser.setFileFilter(filter);

        returnVal = chooser.showOpenDialog(panel);

        if(returnVal == JFileChooser.APPROVE_OPTION)
            filename = chooser.getSelectedFile().getName();
        else
            filename = "";

        return filename;
    }*/

	// The next half of the class loads and processes the .abk sprite/icon bank files:
	// First are the file access methods:

	// Loading and processing methods
	// These small methods are used with the large method below:
	InputStream openbinaryfile(String filename, boolean usefile)
	{
		InputStream in = null;
		file = null;

		// TO DO - use less "global variables".
		try
		{
			if (usefile)
			{
				file = new File(filename);
				in = new FileInputStream(file);
				filesize = (int)file.length();
			}
			else
			{
				in = defaultclass.getResourceAsStream(filename);
				filesize = defaultclass.getResourceAsStream(filename).available();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return in;
	}
	void closebinaryfile(InputStream file)
	{
		try
		{
			file.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	// This version does not support the disk streaming method:
	int getnextbyte()
	{
		byte b = 0;

		try
		{
			if (bufferposition < filesize)
			{
				b=parent.filebuffer[bufferposition];
				bufferposition++;
			}
			else
			{
				// End of file! TO DO
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return unsignedByteToInt(b);
	}
	// This version does not support the disk streaming method:
	// Using Amiga words - 16 bit (2 bytes) aka Java short:
	int getnextword()
	{
		int w = 0;
		try
		{
			w =  getnextbyte() << 8;
			w |= getnextbyte();
			//bufferposition+=2; // ???
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return w;
	}
	/*
    // This version supports both a file buffer and the disk streaming method:
    int getnextbyte()
    {
        byte b = 0;

        if (usefilebuffer)
        {
            try
            {
                b=(byte)filebuffer[bufferposition];
                bufferposition++;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return unsignedByteToInt(b);
        }
        else
        {
            try
            {
                b = (byte)in.read();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            return unsignedByteToInt(b);
        }
    }
	 */
	byte getnextbyte_file()
	{
		byte b = 0;
		try
		{
			b = (byte)in.read();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return b;
	}
	public byte[] loadfiletobuffer(String filename, boolean usefile)
	{
		byte[] ret;

		// Open the binary file:
		if (usefile)
			file = new File(filename);

		in = openbinaryfile(filename, usefile);

		// Exit if there is a problem:
		if (in == null)
		{
			System.err.println("Error loading ABK file/resource to buffer");
			return null;
		}

		// Here allocate the buffer (byte needs some work):
		ret = new byte[filesize];

		// Seems to be buggy when loading resources from .JAR file?
		if (usefile)
		{
			try
			{
				// Now dump the file contents into the buffer:
				in.read(ret);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			// Reset the buffer position:
			bufferposition = 0;

			// Clear the buffer (debug):
			for (int t=0; t<filesize; t++)
				ret[t] = 0; //(byte)0;

			// Now stream the file and dump its contents into the buffer:
			for (int t=0; t<filesize; t++)
				ret[t] = getnextbyte_file(); //(byte)getnextbyte_file();
		}

		// Close the file here:
		closebinaryfile(in);

		// Debug - dump the contents to console:
		//for (int t=0; t<filesize; t++)
		//    System.out.println("Byte "+t+": "+ unsignedByteToInt(ret[t]));
		//System.out.println("Debug: Successfully loaded to buffer!");

		return ret;
	}

	// Added to manipulate bytes and bits:
	public static int unsignedByteToInt(byte b)
	{
		return (int)b & 0xFF;
	}
}
