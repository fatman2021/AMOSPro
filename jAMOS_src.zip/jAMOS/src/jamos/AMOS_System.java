/////////////////////////////////////////////////////////////////
// jAMOS - AMOS BASIC reimplemented in Java!                   //
// (C) 2012 Mequa Innovations                                  //
/////////////////////////////////////////////////////////////////

package jamos;
import jamos.jamal.AMALBank;
import jamos.jamal.AMALCompiler;
import jamos.jamal.AMALEnvGen;
import jamos.jamal.AMALInterpreter;
import jamos.jamal.AMALParser;
import jamos.jamal.AmalPrograms;
import jamos.mequascript.Dumper;
import jamos.mequascript.Game;
import jamos.mequascript.Interpreter;
import jamos.mequascript.Parser;


import java.io.*;
import java.util.*;

public class AMOS_System
{
	int Mode, Fullscreen, ThreeDee, Scale, NumBobCols, LastBobTested, PenColor, PaperColor, MouseState, MouseClickState;
	int File, tim, Timer, CodeInput1, CodeInput2, _ink, _paper;
	public int CHAN;
	public int TOPCHANNEL;
	int oWorld, oCamera, KeyTimeLag, KeyDelaySpeed;
	int thetm, UpdateSpeed, AutoUpdate, NumZones, MouseSprite, MouseImageUsed;
	public int SCANFROM;
	public int FOUNDINSTRUCTION;
	public int FOUNDFUNCTION;
	public int RESULT;
	public int SLEN;
	public int NEST;
	public int BRSTACK;
	int DEBUGMODE;
	public int LOGICTRUE;
	boolean _degree, Bobcolled, RunningAdvancedScreenUpdate, MouseDisplayed;
	public boolean TEST;
	public boolean PAUSED;
	public String tokest;
	public String ttt;
	public String lastt;
	public String lastt2;

	int BobX[], BobY[], BobImage[], ImageHotSpotX[], ImageHotSpotY[], MouseImageHotSpotX[], MouseImageHotSpotY[];
	int ScreenWidth[], ScreenHeight[], ScreenColors[], ScreenRes[], ScreenOffsetX[], ScreenOffsetY[], ScreenDisplayX[], ScreenDisplayY[];
	int ScreenDisplayWidth[], ScreenDisplayHeight[], ScreenClonePointer[], ScreenXCur[], ScreenYCur[];
	int RainbowHeight[], RainbowOffset[], RainbowPos[], RainbowDisplayHeight[], Palette[], SpritePalette[], IconPalette[];
	public int PROGPOINTER[];
	public int AUTOTESTSTART[];
	public int AUTOTESTEND[];
	public int MAINPROGDEPPOINT[];
	public int LOCAL[][];
	public int SPECIAL[][];
	public int GLOBAL[];
	public int NUMINSTRUCTIONS[];
	public int NUMLINES[];
	public int INSTRLINENUM[][];
	public int TEMPCOUNT[];
	public int SETCHANNEL[];
	public int TYPECHANNEL[];
	public int N;
	public int NN;
	public int _TOTALNUMSTRINGS;
	public int T;
	int TT;
	public boolean RUNNINGAUTOTEST[];
	public boolean PROGNOTFINISHED[];
	public boolean FROZEN[];
	public boolean EXISTS[];
	public boolean AmalSynchro;
	public String commandlist[];
	public String argtypename[];
	public String strin[][][];
	public String temp[][];
	public int TOPARGNUM[];
	public int NUMSTRINGS[][];
	public int STRINGARGNUM[][];
	public int NUMARGS[][];
	public int ARGTYPE[][][];
	public int LABELS[][];
	public int COMMAND[][][];
	public int NESTINSTRNUM[];

	public int OLDPROGPOINTER; //SET!
	public int TEMP[][];

	public int ARG[][];
	public String arg[][]; // Needs to be flexible/dynamic type

	public String _input;
	public int JUMPED;
	public int caseon;
	int P1;
	public PrintStream out;
	Random randomgenerator;

	// Added:
	int currentScreen;

	// jAMAL:
	AMALParser amallexer;
	AMALInterpreter amalinterpreter;
	public AMALCompiler amalcompiler;
	AMALBank amalbank;
	public AMALEnvGen envGen;
	
	AMOS_System AM;
	jAMOS ma;
	GameEngineWrapper wrapper;

	// Added from MequaScript for jAMOS:
	boolean OPTIMISE; // TODO: debug this

	Game g;
	Parser lexer;
	Interpreter interpreter;
	Dumper dumper;


	boolean runningcompiled;

	AmalPrograms translatedamalprograms;

	// New: Pedantic mode. (Make settable in editor)
	int pedantic;


	// Moved:
	public boolean interpreterrunning;


	// Added: Use to store loaded image names:
	public ArrayList<String> loadedimages;
	public ArrayList<String> loadedspriteimages;
	public ArrayList<String> currentspriteimages;


	// Added - for procedures - update for multiple brains (move to ActiveObject.java):
	//public String myparamstring = "";
	//public double myparamfloat = 0.0;
	//public int myparamint = 0;
	//public int myparamtype = 0; // 0=int, 1=double, 2=string


	// Constructor function:
	public AMOS_System(jAMOS mygamei)
	{
		Mode=0; Fullscreen=0; ThreeDee=0; Scale=1; NumBobCols=0; LastBobTested=0; PenColor=0; PaperColor=0; currentScreen=0;
		_degree=false; MouseState=0; MouseClickState=0; Bobcolled=true; File=0; tim=0; Timer=0; CodeInput1=10; CodeInput2=-1;
		_ink=2; _paper=0; CHAN=0; TOPCHANNEL=0; oWorld=0; oCamera=0; KeyTimeLag=3; KeyDelaySpeed=30; RunningAdvancedScreenUpdate=false;
		thetm=0; UpdateSpeed=20; AutoUpdate=1; NumZones=0; MouseSprite=1; MouseDisplayed=true; MouseImageUsed=1;
		AmalSynchro = false;

		AM = this;
		ma = mygamei;
		////wrapper = ma.wrapper;
		wrapper = jAMOS.wrapper; // Needed for static type

		// Moved:
		OPTIMISE = false;
		interpreterrunning = false;
		runningcompiled = false;
		pedantic = 1;

		loadedimages = new ArrayList<String>();
		loadedspriteimages = new ArrayList<String>();
		currentspriteimages = new ArrayList<String>();

		// Is this needed here?
		g = new Game();
		lexer = new Parser(g, OPTIMISE);
		interpreter = new Interpreter(g, this);
		dumper = new Dumper(g);

		// Added: Load audio clips:
		wrapper.loadaudio();

		// Initialise the arrays here...
		Init();
	}
	public void Init()
	{
		randomgenerator = new Random();
		amallexer = new AMALParser(this);
		amalinterpreter = new AMALInterpreter(this);
		amalcompiler = new AMALCompiler(this);
		amalbank = new AMALBank(this);
		envGen = new AMALEnvGen(this);

		AMAL_Init();
	}
	public void AMAL_Init()
	{
		// For tokenizer:
		commandlist = new String[100]; // Initialise these String arrays!
		NUMLINES=new int[100]; NUMINSTRUCTIONS=new int[100]; TEMPCOUNT=new int[100]; // int arrays
		INSTRLINENUM = new int[100][100]; // int multi-array
		EXISTS = new boolean[8]; // New. // boolean array

		_input=""; // needs to be Global?
		N=0; NN=0;
		tokest="";
		SCANFROM=0; FOUNDINSTRUCTION=0; FOUNDFUNCTION=0;
		RESULT=0; TEST=false; SLEN=0; NEST=0;
		BRSTACK=0;

		// for compiler:
		caseon = 0;

		// for interpreter:
		// TODO! EXTREMELY memory inefficient in current implementation!
		LOCAL=new int[100][100]; GLOBAL=new int[100]; SPECIAL=new int[100][100]; //TEMP=0; ARG=0;
		PROGPOINTER=new int[100]; AUTOTESTSTART=new int[100]; AUTOTESTEND=new int[100];
		RUNNINGAUTOTEST=new boolean[100];
		MAINPROGDEPPOINT=new int[100];
		SETCHANNEL=new int[100]; TYPECHANNEL=new int[100]; EXISTS=new boolean[100];
		FROZEN=new boolean[100]; PROGNOTFINISHED=new boolean[100];
		NUMSTRINGS=new int[100][100];
		STRINGARGNUM = new int[100][100];
		NUMARGS = new int[100][100];
		ARGTYPE = new int[100][100][100];
		strin = new String[100][100][100];
		COMMAND = new int[100][100][100];
		TOPARGNUM = new int[100];
		NESTINSTRNUM = new int[100];
		LABELS = new int[100][100];
		ARG = new int[100][100];
		arg = new String[100][100];
		temp = new String[100][100];
		TEMP = new int[100][100];
		argtypename = new String[100];

		PAUSED=false; CHAN=0; TOPCHANNEL=0;
		DEBUGMODE = 0; // debug the AMAL interpreter
		LOGICTRUE = -1; // for AMOS

		// New:
		ScreenWidth = new int[100];
		ScreenHeight = new int[100];
		ScreenColors = new int[100];
		ScreenRes = new int[100];
		ScreenOffsetX = new int[100];
		ScreenOffsetY = new int[100];
		ScreenDisplayX = new int[100];
		ScreenDisplayY = new int[100];
		ScreenDisplayWidth=new int[100];
		ScreenDisplayHeight=new int[100];
		// TO DO - Cursor:
		ScreenXCur = new int[100];
		ScreenYCur = new int[100];
		// Perhaps clear/initialise these arrays here.

		// New:
		BobX=new int[2000];
		BobY=new int[2000];
		BobImage=new int[2000];

		for ( int T=0; T<= 25; T++ )
			GLOBAL[T]=0; // Clear all globals

		//// TYPECHANNEL[channel]=
		// 0: To Sprite (default)
		// 1: To Bob
		// 2: To Screen Display
		// 3: To Screen Offset
		// 4: To Screen Size
		// 5: To Rainbow
		// Set the channels (to default):
		for (int NUM=0; NUM<100; NUM++)
		{
			SETCHANNEL[NUM]=NUM;
			TYPECHANNEL[NUM]=0;
			EXISTS[NUM]=false;
		}
		AmalSynchro = false;
	}

	// AMOS functions follow...

	// BASIC-style string functions:
	public String left(String t1, int t2)
	{
		return t1.substring(0, t2);
	}
	public String right(String t1, int t2)
	{   //System.out.println("DIE! Trying Mid(" + t1 + ", " + (1 + (t1.length()) - t2) + ", " + t2 + ")");
		return mid(t1, 1 + (t1.length()) - t2, t2);
		//return t1.substring(t1.length() - t2, t2);
	}
	public String mid(String t1, int t2, int t3)
	{
		if (t2 > (t1.length()))
			return "";

		if ((t2 + t3) > (t1.length()))
			t3 = t1.length() - t2 + 1;

		if ((t1.length() <= 0) || (t3 <= 0))
			return "";

		if (t2 <= 1)
			return t1.substring(0, t3);
		else
			return t1.substring(t2 - 1, t2 + t3 - 1);
	}
	public String mid(String t1, int t2)
	{
		if ((t1.length() <= 0) || (t2 <= 1))
			return t1;
		else
			return t1.substring(t2 - 1, t1.length());
	}
	public int instr(String t1, String t2, int t3)
	{
		if (t3>1)
			return (t1.indexOf(t2, t3-1)) + 1;
		else // If 'start of search position' is 0 (same as for 1).....
			return (t1.indexOf(t2)) + 1;
	}
	public int instr(String t1, String t2)
	{
		return (t1.indexOf(t2)) + 1;
	}


	// Random number generator function:
	public int rnd(int t1)
	{
		return randomgenerator.nextInt(t1 + 1);
	}
	// These two are for AMAL's random number generator:
	public int amalZnd(int t1)
	{
		if (pedantic == 0)
		{
			// Use standard AMOS random number generator:
			return randomgenerator.nextInt(t1 + 1); //return rnd(t1);
		}
		else
		{
			// Return a bitwise AND with the result of "Znd" below:
			// TO DO: Convert to (pedantic) short type
			// to work with negative numbers (and need to verify).
			return ((int) (((new Integer(t1)).shortValue()) & amalZnd()));
		}
	}
	// Need to get this parsed in AMAL source:
	public short amalZnd()
	{
		// AMAL Z function without brackets (TO DO: Parser)
		// Return a random number in the range -32767 to 32768 (CHECK THIS)
		return (new Integer(randomgenerator.nextInt(65536) - 32767)).shortValue();
	}

	// Input/output AMOS instructions required for AMAL:
	public int xMouse()
	{
		return wrapper.xmouse();
	}
	public int yMouse()
	{
		return wrapper.ymouse();
	}
	public int joy(int t1)
	{
		return wrapper.joy(t1);
	}
	public int mouseKey()
	{
		return wrapper.mousekey(-1);
	}
	public int mouseKey(int t1)
	{
		return wrapper.mousekey(t1);
	}
	public void waitKey()
	{
	}

	// Added - more joystick controls:
	public int jleft(int t1)
	{
		return wrapper.joy(t1) & 1;
	}
	public int jright(int t1)
	{
		return wrapper.joy(t1) & 2;
	}
	public int jup(int t1)
	{
		return wrapper.joy(t1) & 4;
	}
	public int jdown(int t1)
	{
		return wrapper.joy(t1) & 8;
	}
	public int fire(int t1)
	{
		return wrapper.joy(t1) & 16;
	}

	// Screen, bob, sprite and collision AMOS functions for AMAL:
	public int xScreen(int t1, int t2)
	{
		return t2 + ScreenOffsetX[t1] - ScreenDisplayX[t1]; 
	}
	public int yScreen(int t1, int t2)
	{
		return t2 + ScreenOffsetY[t1] - ScreenDisplayY[t1];
	}
	public int xHard(int t1, int t2)
	{
		return t2 + ScreenDisplayX[t1] - ScreenOffsetX[t1];
	}
	public int yHard(int t1, int t2)
	{
		return t2 + ScreenDisplayY[t1] - ScreenOffsetY[t1];
	}
	public int xScreen(int t1)
	{
		return xScreen(currentScreen, t1);
	}
	public int yScreen(int t1)
	{
		return yScreen(currentScreen, t1);
	}
	public int xHard(int t1)
	{
		return xHard(currentScreen, t1);
	}
	public int yHard(int t1)
	{
		return yHard(currentScreen, t1);
	}

	// To do: Collision detection:
	public int bobCol(int t1, int t2, int t3)
	{
		return 0;
	}
	public int spriteCol(int t1, int t2, int t3)
	{
		return 0;
	}
	public int col(int t1)
	{
		return 0;
	}

	public int vumeter(int t1)
	{
		return 0;
	}
	
	public int xSprite(int t1)
	{
		return (int)(wrapper.xsprite(t1));
	}
	public int ySprite(int t1)
	{
		return (int)(wrapper.ysprite(t1));
	}
	public int iSprite(int t1)
	{
		return (int)(wrapper.isprite(t1));
	}
	public int xBob(int t1)
	{
		return (int)(wrapper.xbob(t1));
	}
	public int yBob(int t1)
	{
		return (int)(wrapper.ybob(t1));
	}
	public int iBob(int t1)
	{
		return (int)(wrapper.ibob(t1));
	}
	public int hrev(int a)
	{
		return a | 0x8000;
	}
	public int vrev(int a)
	{
		return a | 0x4000;
	}
	public int rev(int a)
	{
		return a | 0xC000;
	}

	// AMOS Sprite and Bob instructions:
	public void sprite(int a, double b, double c, int d)
	{
		wrapper.sprite(a,b,c,d);
	}
	public void sprite(int a, double b, double c)
	{
		wrapper.sprite(a,b,c);
	}
	public void bob(int a, double b, double c, int d)
	{
		wrapper.bob(a, (new Double(b).intValue()), (new Double(c).intValue()), d);
	}
	public void bob(int a, double b, double c)
	{
		wrapper.bob(a, (new Double(b).intValue()), (new Double(c).intValue()));
	}

	// AMOS Screen instructions:
	public void screenOpen(int a, int b, int c, int d, int e)
	{
		wrapper.screenOpen(a, b, c, d, e);
	}

	public void screenSize(int a, int b, int c)
	{
		wrapper.screenSize(a, b, c);
	}

	public void screenDisplay(int a, int b, int c)
	{
		wrapper.screenDisplay(a, b, c);
	}
	public void screenDisplay(int a, int b, int c, int d, int e)
	{
		screenDisplay(a, b, c);
		screenSize(a, c, e);
	}
	public void screenOffset(int a, int b, int c)
	{
		// Debug - to do:
		//screenSize(a, b, c);

		// Set the offset here (TO DO):
		ScreenOffsetX[a]=b;
		ScreenOffsetY[a]=c;

		// Re-display the screen (TO DO:)
		screenDisplay(a, ScreenDisplayX[a], ScreenDisplayY[a]);
	}

	public void screenClose()
	{
		// Close all screens here.
	}
	public void screenClose(int a)
	{
	}
	public void screenClone(int a)
	{
	}
	public void screen(int a)
	{
		// Set the current screen here:
		currentScreen = a;
	}
	public void doubleBuffer()
	{
		// Ignored for now - implementation is not low-level enough
	}
	public void dualPlayfield(int a, int b)
	{    	
	}
	public void dualPriority(int a, int b)
	{    	
	}

	// Required for Java:
	public int booltoint(boolean b)
	{
		if (b)
			return LOGICTRUE;
		else
			return 0;
	}

	// Added: for AMAL compiler:

	// Here Move is implemented as two parts:
	public void amalMoveInit(int CHAN, int a, int b, int c)
	{
		// Move (Initialise):
		SPECIAL[CHAN][3] = a;
		SPECIAL[CHAN][4] = b;
		SPECIAL[CHAN][5] = c;
		if (SPECIAL[CHAN][5] == 0)
			SPECIAL[CHAN][5]=1;
		SPECIAL[CHAN][6]=1;
	}
	public void amalMoveRun(int CHAN, int movejumppoint, int movejumppoint2)
	{
		int tempX;
		int tempY;

		// AMAL Move (run):
		tempX=(((SPECIAL[CHAN][6] - 1) * SPECIAL[CHAN][3]) / SPECIAL[CHAN][5]);
		tempY=(((SPECIAL[CHAN][6] - 1) * SPECIAL[CHAN][4]) / SPECIAL[CHAN][5]);

		SPECIAL[CHAN][0] += ((SPECIAL[CHAN][6] * SPECIAL[CHAN][3]) / SPECIAL[CHAN][5]) - tempX;
		SPECIAL[CHAN][1] += ((SPECIAL[CHAN][6] * SPECIAL[CHAN][4]) / SPECIAL[CHAN][5]) - tempY;
		PAUSED = true;

		if (SPECIAL[CHAN][6]<SPECIAL[CHAN][5])
		{
			SPECIAL[CHAN][6]++; // Increase the Counter.
			PROGPOINTER[CHAN]=movejumppoint;
		}
		else
		{
			PROGPOINTER[CHAN]=movejumppoint2; // End of Move, go to next jump point
		}
		// break; removed - need to use break inside compiled Java program.
	}
	// Not yet implemented - would need a variable number of input operators!
	public void amalAnim(int CHAN, int a, int b, int c, int d, int e, int f, int g, int h, int i, int j, int k)
	{
		amalAnimInit(CHAN, a);
	}
	public void amalAnim(int CHAN, int a, int b, int c, int d, int e, int f, int g, int h, int i)
	{
		amalAnimInit(CHAN, a);
	}
	public void amalAnim(int CHAN, int a, int b, int c, int d, int e, int f, int g)
	{
		amalAnimInit(CHAN, a);
	}
	public void amalAnim(int CHAN, int a, int b, int c, int d, int e)
	{
		amalAnimInit(CHAN, a);
	}
	public void amalAnim(int CHAN, int a, int b, int c)
	{
		amalAnimInit(CHAN, a);
	}
	// Part implemented here:
	public void amalAnimInit(int CHAN, int a)
	{
		// AMAL Anim (partial initialisation only):
		// TO DO - does CHAN work, or need channel variable from compiled program? Synchronise?
		// Current frame number (0 = no animation)
		SPECIAL[CHAN][10] = 1;
		// Number of frames (i.e. brackets)
		SPECIAL[CHAN][11] = +((NUMARGS[CHAN][(PROGPOINTER[CHAN])]-1)/2); //+"; // Number of frames");
		// Timer for current frame (VBLs)...
		SPECIAL[CHAN][12] = 1;
		// Copy the arguments into the special registers...
		SPECIAL[CHAN][13] = a;
	}
	// TO DO - need to test this works with compiler:
	public void amalAnimInitPair(int CHAN, int offset, int a, int b)
	{
		// Following SPECIAL[CHAN][13] = a; above:
		// Here offset is 0,1,2,3....
		SPECIAL[CHAN][(offset*2)+14] = a;
		SPECIAL[CHAN][(offset*2)+15] = b;  	
	}
	// These need to be followed by "break;" in a compiled AMAL program:
	public void amalJump(int CHAN, int progpointer)
	{
		PROGPOINTER[CHAN] = progpointer;
	}
	public void amalDirect(int CHAN, int progpointer)
	{
		RUNNINGAUTOTEST[CHAN] = false; // Leave Autotest...
		PROGPOINTER[CHAN] = progpointer;
	}
	public void amalPause(int CHAN, int progpointer)
	{
		PROGPOINTER[CHAN] = progpointer;
		PAUSED = true;
	}
	public void amalWait(int CHAN, int progpointer)
	{
		PROGPOINTER[CHAN] = progpointer;
		PAUSED = true;
	}
	public void amalInitAutotest(int CHAN, int start, int end)
	{
		AUTOTESTSTART[CHAN] = start;
		AUTOTESTEND[CHAN] = end;

		// Skip to end of Autotest:
		PROGPOINTER[CHAN] = end;
	}
	public void amalEndAutotest(int CHAN)
	{
		// As for eXit:
		// Re-enter the main program again, at the original departure point:
		RUNNINGAUTOTEST[CHAN] = false; // Leave Autotest...
		if ( MAINPROGDEPPOINT[CHAN] >= 0 )
			PROGPOINTER[CHAN] = MAINPROGDEPPOINT[CHAN];
		else
			// Jump to end of Autotest:
			PROGPOINTER[CHAN] = AUTOTESTEND[CHAN];
	}
	public void amalExitAutotest(int CHAN)
	{
		// Re-enter the main program again, at the original departure point:
		RUNNINGAUTOTEST[CHAN] = false; // Leave Autotest...
		if ( MAINPROGDEPPOINT[CHAN] >= 0 )
			PROGPOINTER[CHAN] = MAINPROGDEPPOINT[CHAN];
		else
			// Jump to end of Autotest:
			PROGPOINTER[CHAN] = AUTOTESTEND[CHAN];    	
	}
	public void amalEnd(int CHAN)
	{
		PROGNOTFINISHED[CHAN] = false;
	}
	// TO DO - Does this work? ("On") - run from AUtotest, should restart main program from Wait.
	public void amal_On(int CHAN)
	{
		// On
		// Re-enter the main program again, after the original departure point:
		RUNNINGAUTOTEST[CHAN] = false; // Leave Autotest...");
		if (MAINPROGDEPPOINT[CHAN] >= 0)
			PROGPOINTER[CHAN] = MAINPROGDEPPOINT[CHAN] + 1;
		else
			// Jump to end of Autotest:
			PROGPOINTER[CHAN] = INSTRLINENUM[CHAN][COMMAND[CHAN][(AUTOTESTSTART[CHAN])][1]-1]+2; // +1+1");
	}

	// Access AMAL registers:
	public int amalGetGlobal(int reg)
	{
		return GLOBAL[reg];
	}
	public int amalGetLocal(int CHAN, int reg)
	{
		return LOCAL[CHAN][reg];
	}
	public int amalGetSpecial(int CHAN, int reg)
	{
		return SPECIAL[CHAN][reg];
	}
	public int amalGetX(int CHAN)
	{
		return SPECIAL[CHAN][0];
	}
	public int amalGetY(int CHAN)
	{
		return SPECIAL[CHAN][1];
	}
	public int amalGetA(int CHAN)
	{
		return SPECIAL[CHAN][2];
	}

	public void amalSetGlobal(int reg, int value)
	{
		GLOBAL[reg] = value;
	}
	public void amalSetLocal(int CHAN, int reg, int value)
	{
		LOCAL[CHAN][reg] = value;
	}

	// These two are used for AMAL For loops:
	public void amalIncGlobal(int reg)
	{
		GLOBAL[reg]++;
	}
	public void amalIncLocal(int CHAN, int reg)
	{
		LOCAL[CHAN][reg]++;
	}

	public void amalSetSpecial(int CHAN, int reg, int value)
	{
		SPECIAL[CHAN][reg] = value;
	}
	public void amalSetX(int CHAN, int value)
	{
		SPECIAL[CHAN][0] = value;
	}
	public void amalSetY(int CHAN, int value)
	{
		SPECIAL[CHAN][1] = value;
	}
	public void amalSetA(int CHAN, int value)
	{
		SPECIAL[CHAN][2] = value;
	}

	// Added for int/boolean expressions:
	boolean istrue(boolean value)
	{
		return value;
	}
	boolean istrue(int value)
	{
		return value != 0;
	}
	boolean isfalse(boolean value)
	{
		return value;
	}
	boolean isfalse(int value)
	{
		return value == 0;
	}

	// Compiled version (for now, with int - memory bank strings with int will be later):
	public void amal(int p1, int p2)
	{
		boolean synchroStatus = AmalSynchro;
		AmalSynchro = true;
		CHAN = p1;

		//boolean isfunction = false; // was used for the compiler on Jamagic

		// From Jamagic version:
		//if (isfunction) // (IsFunction(p2))
		//{
		//AMALFun[p1]=p2; // needs a re-write in Java!
		if ( CHAN>TOPCHANNEL )
		{
			TOPCHANNEL=CHAN;
		}
		NUMLINES[p1] = 1; // added (long ago).

		// We need to set the CHANNEL to the PROGRAM here. For now (n,n).

		// Initialize the interpreter:
		PROGPOINTER[p1]=0; RUNNINGAUTOTEST[p1]=false; AUTOTESTSTART[p1]=-1; MAINPROGDEPPOINT[p1]=-1;
		SPECIAL[p1][10]=0; // No Anim running at beginning...
		PROGNOTFINISHED[p1]=true; FROZEN[p1]=true; EXISTS[p1]=true;
		
		for ( int T=0; T<= 9; T++ ) { LOCAL[p1][T]=0; }

		AmalSynchro = synchroStatus;
	}

	// AMOS BASIC AMAL instructions:
	public void amal(int p1, String p2)
	{
		boolean synchroStatus = AmalSynchro;
		AmalSynchro = true;
		CHAN = p1;

		//boolean isfunction = false; // was used for the compiler on Jamagic

		_input=p2;

		if ( CHAN>TOPCHANNEL )
		{
			TOPCHANNEL=CHAN;
		}	

		amallexer.Tokenize();

		//else // very old and removed long ago
		//{
		//	NUMLINES[P1] = 1;
		//}

		// Initialize the interpreter:
		PROGPOINTER[p1]=0; RUNNINGAUTOTEST[p1]=false; AUTOTESTSTART[p1]=-1; MAINPROGDEPPOINT[p1]=-1;
		SPECIAL[p1][10]=0; // No Anim running at beginning...
		PROGNOTFINISHED[p1]=true; FROZEN[p1]=true; EXISTS[p1]=true;
		for ( int T=0; T<= 9; T++ ) { LOCAL[p1][T]=0; }

		AmalSynchro = synchroStatus;
	}

	public int amreg(int t1)
	{
		return GLOBAL[t1];
	}
	public int amreg(int t1, int t2)
	{
		return LOCAL[t1][t2];
	}
	public void setAmreg(int t1, int t2)
	{
		GLOBAL[t2] = t1;
	}
	public void setAmreg(int t1, int t2, int t3)
	{
		LOCAL[t2][t3] = t1;
	}
	public void amalOn(int p1)
	{
		FROZEN[p1] = false;
	}
	public void amalOn()
	{
		for (int p1 = 1; p1 <= TOPCHANNEL; p1++) // should start from 0
			FROZEN[p1] = false;
	}
	public void amalFreeze(int p1)
	{
		FROZEN[p1] = true;
	}
	public void amalFreeze()
	{
		for (int p1 = 1; p1 <= TOPCHANNEL; p1++) // should start from 0
			FROZEN[p1] = true;
	}

	public void amalOff()
	{
		for (int p1=1; p1 <= TOPCHANNEL; p1++) // should start from 0
		{
			PROGPOINTER[p1] = 0;
			NUMLINES[p1] = 0;
			EXISTS[p1] = false;

			// Destroy AMAL program from memory here:
		}
		TOPCHANNEL = 0;
	}
	public void amalOff(int p1)
	{
		// Need to check if out of range here.

		PROGPOINTER[p1] = 0;
		NUMLINES[p1] = 0;
		EXISTS[p1] = false;

		// Need to destroy AMAL program from memory here. (?)

		// Drop down the top channel here:
		if (p1 == TOPCHANNEL)
			if ( NUMLINES[P1]==0 && P1 >= 0 ) // while ( NUMLINES[P1]==0 && P1>=0 )
				TOPCHANNEL--;
	}

	public void channelToSprite(int p1, int p2)
	{
		// Channel p1 To Sprite P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 0; // To Sprite.
	}
	public void channelToBob(int p1, int p2)
	{
		// Channel p1 To Bob P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 1; // To Bob.
	}
	public void channelToScreenDisplay(int p1, int p2)
	{
		// Channel p1 To Screen Display P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 2; // To Screen Display
	}
	public void channelToScreenOffset(int p1, int p2)
	{
		// Channel p1 To Screen Offset P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 3; // To Screen Offset.
	}
	public void channelToScreenSize(int p1, int p2)
	{
		// Channel p1 To Screen Size P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 4; // To Screen Size.
	}
	public void channelToRainbow(int p1, int p2)
	{
		// Channel p1 To Rainbow P2
		SETCHANNEL[p1] = p2;
		TYPECHANNEL[p1] = 5; // To Rainbow.
	}

	public void synchroOff()
	{
		AmalSynchro = false;
	}
	public void synchroOn()
	{
		AmalSynchro = true;
	}
	public void synchro()
	{
		AMAL_Do(runningcompiled);
	}

	public void AMAL_Do(boolean isfunction)
	{
		if (!isfunction)
			interpreterrunning = true; // needed if compiled?

		//System.out.println("Running AMAL_Do!");

		// if (TOPCHANNEL > 0) // old and removed
		for ( CHAN=1; CHAN <= TOPCHANNEL; CHAN++ ) // Originally from 0, not from 1..
		{
			//System.out.println("CHAN = "+CHAN);

			boolean objectremoved = false;
			//Say(""+CHAN+" "+TOPCHANNEL); // Wait(100);

			if (EXISTS[CHAN]) if ( (FROZEN[CHAN] == false))
			{			
				// Get values for special registers: 
				if (DEBUGMODE == 0 )
				{
					// Debug - only print if typechannel > 0:
					//if (TYPECHANNEL[CHAN]> 0)
					//	System.out.println("Debug: Fetching special registers. TYPECHANNEL["+CHAN+"] = "+TYPECHANNEL[CHAN]);

					switch ( TYPECHANNEL[CHAN] )
					{
					case 0:
						// Channel CHAN To Sprite SETCHANNEL[CHAN]
						SPECIAL[CHAN][0]=xSprite(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][1]=ySprite(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][2]=iSprite(SETCHANNEL[CHAN]);
						break;
					case 1:
						// Channel CHAN To Bob SETCHANNEL[CHAN]   

						// From Jamagic version - fix to detect deleted bobs:
						//if (!IsObject(Bobs[SETCHANNEL[CHAN]]))
						//{
						//	amalOff(CHAN); objectremoved = true;
						//	break;
						//}

						SPECIAL[CHAN][0]=(int)xBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][1]=(int)yBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][2]=(int)iBob(SETCHANNEL[CHAN]);
						break;
					case 2:
						// Channel AMOS_Sys.CHAN To Screen Display AMOS_Sys.SETCHANNEL(AMOS_Sys.CHAN) 

						// FIX - is currentScreen correct here?
						SPECIAL[CHAN][0]=(int)ScreenDisplayX[currentScreen]; // TO DO: Screen number is: (SETCHANNEL[CHAN])
						SPECIAL[CHAN][1]=(int)ScreenDisplayY[currentScreen]; // TO DO: Screen number is: (SETCHANNEL[CHAN])
						//System.out.println("Debug: Running Channel "+CHAN+
						//" to Screen Display (Screen) "+(SETCHANNEL[CHAN]));
						break;
					case 3:
						// Channel AMOS_Sys.CHAN To Screen Offset AMOS_Sys.SETCHANNEL(AMOS_Sys.CHAN) 
						// TO DO:
						SPECIAL[CHAN][0]=(int)xBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][1]=(int)yBob(SETCHANNEL[CHAN]);
						break;
					case 4:
						// Channel AMOS_Sys.CHAN To Screen Size AMOS_Sys.SETCHANNEL(AMOS_Sys.CHAN) 
						// TO DO:
						SPECIAL[CHAN][0]=(int)xBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][1]=(int)yBob(SETCHANNEL[CHAN]);
						break;
					case 5:
						// Channel AMOS_Sys.CHAN To Rainbow AMOS_Sys.SETCHANNEL(AMOS_Sys.CHAN) 
						// TO DO:
						SPECIAL[CHAN][0]=(int)xBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][1]=(int)yBob(SETCHANNEL[CHAN]);
						SPECIAL[CHAN][2]=(int)iBob(SETCHANNEL[CHAN]);
						break;
					}
				}

				if (!objectremoved)
				{
					if (PROGNOTFINISHED[CHAN])
					{
						// Do the Autotest if applicable: 
						if ( AUTOTESTSTART[CHAN]>=0 )
						{
							MAINPROGDEPPOINT[CHAN]=PROGPOINTER[CHAN]; // Record the position..
							PROGPOINTER[CHAN]=AUTOTESTSTART[CHAN]+1; // Jump to the Autotest
							RUNNINGAUTOTEST[CHAN]=true;
						}

						// Now run the AMAL commands:
						//boolean isfunction = false; // added - debug
						if (isfunction) // if (isFunction(AMALFun[CHAN]))
						{
							//fun = AMALFun[CHAN];
							//Forrepeat=0;					
							//fun();

							// Now we run the compiled/translated AMAL programs:
							translatedamalprograms.forrepeat = false; // needed?
							translatedamalprograms.runAmal(CHAN, CHAN);
						}
						else
						{
							while ( PROGPOINTER[CHAN]<NUMLINES[CHAN] && PAUSED==false )
							{
								//THINGY++; //DEBUG!!
								amalinterpreter.interpret();

								// Debug: 
								if ( DEBUGMODE != 0 )
									amalinterpreter.DEBUG();
							}
							// Does this work ???
							if ( PROGPOINTER[CHAN] < NUMLINES[CHAN] )
								PROGNOTFINISHED[CHAN] = true; // was PROGFINISHED[CHAN] = false;
						}
						//A_Say(""+CHAN+" "+TYPECHANNEL[CHAN] ); // Wait(100);

						PAUSED=false;
						if ( DEBUGMODE != 0 )
							System.out.println("PAUSED...");
					}

					// Run the AMAL Anim if applicable... 
					if ( SPECIAL[CHAN][10]>0 )
						AMAL_ANIM();

					// Return values from the special registers: 
					if (DEBUGMODE == 0) switch (TYPECHANNEL[CHAN])
					{
					case 0:
						// Channel CHAN To Sprite SETCHANNEL[CHAN]
						sprite(SETCHANNEL[CHAN], SPECIAL[CHAN][0], SPECIAL[CHAN][1], SPECIAL[CHAN][2]);
						break;
					case 1:
						//for (int n=0; n<5; n++) System.out.println("Trying to draw a bob, lulz!!!");
						// Channel CHAN To Bob SETCHANNEL[CHAN]
						bob(SETCHANNEL[CHAN], SPECIAL[CHAN][0], SPECIAL[CHAN][1], SPECIAL[CHAN][2]);
						break;
					case 2:
						// Channel CHAN To Screen Display SETCHANNEL[CHAN]
						screenDisplay(SETCHANNEL[CHAN], SPECIAL[CHAN][0], SPECIAL[CHAN][1]);
						break;
					case 3:
						// Channel CHAN To Screen Offset SETCHANNEL[CHAN]
						screenOffset(SETCHANNEL[CHAN],SPECIAL[CHAN][0],SPECIAL[CHAN][1]);
						break;
					case 4:
						// Channel CHAN To Screen Size SETCHANNEL[CHAN]
						//ScreenDisplay(SETCHANNEL[CHAN],(int)null,(int)null, SPECIAL[CHAN][0], SPECIAL[CHAN][1]);
						screenSize(SETCHANNEL[CHAN], SPECIAL[CHAN][0], SPECIAL[CHAN][1]);
						break;
					case 5:
						// Channel CHAN To Rainbow SETCHANNEL[CHAN]
						rainbow(SETCHANNEL[CHAN],SPECIAL[CHAN][0],SPECIAL[CHAN][1],SPECIAL[CHAN][2]);
					}
				}
			}
		}
		interpreterrunning = false;
	}

	public void AMAL_ANIM()
	{
		// Set the object image:
		SPECIAL[CHAN][2]=SPECIAL[CHAN][12+((SPECIAL[CHAN][10])*2)];

		// Increase the timer/counter for current frame:
		SPECIAL[CHAN][12]++;
		// If the counter is finished, move to the next frame:
		if ( (SPECIAL[CHAN][12])>(SPECIAL[CHAN][13+((SPECIAL[CHAN][10])*2)]) )
		{
			SPECIAL[CHAN][10]++;
			SPECIAL[CHAN][12]=1;
			// If past the number of frames:
			if ( (SPECIAL[CHAN][10])>(SPECIAL[CHAN][11]) )
			{
				switch ( SPECIAL[CHAN][13] )
				{
				case 0:
					// for infinite repeats:
					// Start from the beginning (first frame):
					SPECIAL[CHAN][10]=1;
					break;
				case 1:
					// Last time finished:
					// Stop running the animation.
					SPECIAL[CHAN][10]=0;
					break;
				default:
					// Repeat again, with count down:
					SPECIAL[CHAN][13]--;
					// Start from the beginning (first frame):
					SPECIAL[CHAN][10]=1;
				}
			}
		}
	}

	// To do - added channel number to run from an interpreted or compiled program.
	public int amalPLay(int CHAN, int t1)
	{
		return 0;
	}


	// Load image or IFF file (supports other formats instead for now):
	public void loadIff(String a, int b)
	{
		wrapper.loadIff(a, b);
	}

	public void loadIff(String a)
	{
		wrapper.loadIff(a, currentScreen);
	}

	// Banks:
	// Load a bank (folder of sprites for now)
	// TO DO - faux packed pictures (with unpack).
	public void load(String a, int b)
	{
		wrapper.load(a,  b);
	}
	public void erase(int a)
	{
		wrapper.erase(a);
	}

	// Load a Sprite bank from AMOS Basic .abk files:
	public int loadamosabk(String fileName)
	{
		return wrapper.loadamosabk(fileName);
	}

	public int pastebob(int x, int y, int a)
	{
		return wrapper.pastebob(x, y, a);
	}

	public int ink(int a)
	{
		_ink = a;
		return 0;
	}
	public int pen(int a)
	{
		_ink = a; // TODO - separate value for pen and ink!
		return 0;
	}
	public int paper(int a)
	{
		_paper = a;
		return 0;
	}

	public int plot(int x, int y, int a)
	{
		return wrapper.plot(x, y, a);
	}
	public int plot(int x, int y)
	{
		return wrapper.plot(x, y);
	}
	public int draw(int x1, int y1, int x2, int y2)
	{
		return wrapper.draw(x1, y1, x2, y2);
	}
	public int bar(int x1, int y1, int x2, int y2)
	{
		return wrapper.bar(x1, y1, x2, y2);
	}
	public int box(int x1, int y1, int x2, int y2)
	{
		return wrapper.box(x1, y1, x2, y2);
	}
	public int circle(int x1, int y1, int r)
	{
		return wrapper.circle(x1, y1, r);
	}
	public int ellipse(int x1, int y1, int r1, int r2)
	{
		return wrapper.ellipse(x1, y1, r1, r2);
	}

	// Old version (remove?)
	/*public int loadabk(String fileName) throws IOException
    {
    	String outputstring = ""; // fix this

	    String out = "";

	    //String file = fileName; //application.getRealPath("/") + fileName;
	    char c = 0;
	    //System.out.println("Trying file: "+fileName);

		InputStream input = getClass().getResourceAsStream(fileName);
		//ByteArrayOutputStream output = new ByteArrayOutputStream(1024);

	    for (int t=0; t<4; t++)
	        if ((c = (char)input.read()) > 0)
	        {
	           out += c; //System.out.println("" + c);
	        }
		input.close();

	    //FileInputStream fileinputstream = new FileInputStream(file);
	    //ObjectInputStream inputobjectStream = new ObjectInputStream(fileinputstream);
	    //c = inputobjectStream.readChar();
	    //inputobjectStream.close();

	    outputstring = out; // fix this

	    // Added for Eclipse:
	    if (outputstring != null);

	    return 0+(int)c;
    }*/

	// Added from Myqu:
	public void _default()
	{
		bobOff();
		rainbowDel();
		for (int n=0; n<=7; n++)
		{	
			ScreenClonePointer[n]=-1;
			//if (screens[n] != null)
			//{
			//	// Delete the screen here:
			//	screens[n] = null;
			//}
		}
		//screenOpen(0,320,200,3,lowres()); // create the default screen here
		// Erase the screen here
		//screens[0].SetBackgroundColor(A_PalTo24(1, AMOS_Sys.ScreenPalette[0,1]));
		//screens[0].EraseRect();
		_paper=1; //?

		MouseDisplayed = true;

		ink(3); bar(2,9,10,11);
		flash(3, "(DD0,2)(EE0,2)(FF2,2)(FF8,2)(FFC,2)(FFF,2)(AAF,2)(88C,2)(66A,2)(226,2)(004,2)(001,2)(000,2)(440,2)(880,2)(BB0,2)");
		ink(2);

		amalOff(); // FIX ME!
		AMAL_Init(); // FIX ME!
	}
	public int lowres() { return 0; }
	public int hires() { return 32768; }
	public int laced() { return 4; }

	public int timer() { return Timer; }
	public void setTimer(int t1) { Timer = t1; }

	///////////////////////////////////////////////////////
	// Maths Functions
	public void degree() { _degree = true; }
	public void radian() { _degree = false; }
	public double sin(double t1) { if (_degree) return Math.sin(t1*Math.PI / 180.0); else return Math.sin(t1); }
	public double cos(double t1) { if (_degree) return Math.cos(t1*Math.PI / 180.0); else return Math.cos(t1); }
	public double tan(double t1) { if (_degree) return Math.tan(t1*Math.PI / 180.0); else return Math.tan(t1); }
	public double asin(double t1) { if (_degree) return Math.asin(t1)*180.0 / Math.PI; else return Math.asin(t1); }
	public double acos(double t1) { if (_degree) return Math.acos(t1)*180.0 / Math.PI; else return Math.acos(t1); }
	public double atan(double t1) { if (_degree) return Math.atan(t1)*180.0 / Math.PI; else return Math.atan(t1); }
	public double pi() { return Math.PI; }
	public int _true() { return -1; } // TODO
	public int _false() { return 0; } // TODO
	//public boolean _true() { return true; }
	//public boolean _false() { return false; }

	///////////////////////////////////////////////////////
	// String Functions
	public int len(String t1) { return t1.length(); }
	public String upper(String t1) { return t1.toUpperCase(); }
	public String lower(String t1) { return t1.toLowerCase(); }
	public String _string(String t1, int t2) { String o=""; for (int t=0; t<t2; t++) o=o+t1; return o; }
	public String repeat(String t1, int t2) { String o=""; for (int t=0; t<t2; t++) o=o+t1; return o; } // TODO
	public String space(int t1) { String o=""; for (int t=0; t<t1; t++) o=o+" "; return o; }
	public String flip(String i) { String o=""; for (int t=0; t<i.length(); t++) { o+=i.charAt(i.length()-t-1); } return o; }
	public double val(String i) { return Double.parseDouble(i); }
	//public int val(String i) { return Integer.parseInt(i); }
	public String str(double i) { return Double.toString(i); }
	public String stri(int i) { return Integer.toString(i); } // added
	public String str(int i) { return Integer.toString(i); }
	public int asc(String a) { if (a==null) return 0; if (a.length()==0) return 0; return (int)a.charAt(0);}
	public int asc(char a) { return (int)a; }
	public String chr(int a) { return Character.toString((char)a); }

	///////////////////////////////////////////////////////
	// AMOS Rainbows
	public void rainbow(int t1, int t2, int t3, int t4)
	{
		// TODO:
		//RainbowOffset[t1]=t2; RainbowPos[t1]=t3; RainbowDisplayHeight[t1]=t4;
	}

	public void rain(int t1, int t2, int t3) // Which order??? ???? number t1, line t2 = colour t3......
	{
		//int b = ((t3&3840)/256)*16; // +1)*16)-1

		// Big-endian (?):
		//int b = ((t3 & 0x00F) * 0x11 / 0x001) + ((t3 & 0x0F0) * 0x1100 / 0x010) + ((t3 & 0xF00) * 0x110000 / 0x100);
		// Little-endian:
		int b = ((t3 & 0x00F) * 0x110000 / 0x001) + ((t3 & 0x0F0) * 0x1100 / 0x010) + ((t3 & 0xF00) * 0x11 / 0x100);

		//System.out.println(b); // debug
		ink(b);
		draw(0, t2, ScreenWidth[0], t2); // debug

		//Rainbows[t1].SetPixel(0, t2, GetRGB((t3&15)*16, t3&240, b)); // TODO
		////AMOS_Sys.Rainbows[t1].SetPixel(0, t2, A_PalTo24(0,t3)); // WHY DOES THIS GET $RGB MIXED UP WITH $BGR ???
	}
	public void setRainbow(int t1, int t2, int t3, String t4, String t5, String t6)
	{
		//If (IsObject(Rainbows[t1])) delete AMOS_Sys.Rainbows[t1]; // TODO
		//Rainbows[t1]=New Surface(1,t3,16); // TODO
		//Rainbows[t1].SetAutoRefresh(OFF); // TODO

		// TODO:
		//RainbowHeight[t1]=t3;
		//RainbowOffset[t1]=0; RainbowPos[t1]=0; RainbowDisplayHeight[t1]=0;

		int _red=0; int _green=0; int _blue=0;
		int _rednumberon=0; int _redcountdone=0;
		int _greennumberon=0; int _greencountdone=0;
		int _bluenumberon=0; int _bluecountdone=0;

		int t, tt;

		// Parse the red string:
		int Rnumber=0, Rstep=0, Rcount=0;
		if (t4.length() > 0)
		{
			t=t4.indexOf(","); tt=t4.indexOf(",", t+1);
			Rnumber=Integer.parseInt(t4.substring(1, t)); // was t-1
			Rstep=Integer.parseInt(t4.substring(t + 1, tt)); // was tt-t-1
			Rcount=Integer.parseInt(t4.substring(tt + 1, t4.length() - 1)); // was t4.length()-tt-1;
		}

		// Parse the green string:
		int Gnumber=0, Gstep=0, Gcount=0;
		if (t5.length() > 0)
		{
			t=t5.indexOf(","); tt=t5.indexOf(",", t+1);
			Gnumber=Integer.parseInt(t5.substring(1, t));
			Gstep=Integer.parseInt(t5.substring(t + 1, tt));
			Gcount=Integer.parseInt(t5.substring(tt + 1, t5.length() -1));
		}

		// Parse the blue string:
		int Bnumber=0, Bstep=0, Bcount=0;
		if (t6.length() > 0)
		{
			t=t6.indexOf(","); tt=t6.indexOf(",", t + 1);
			Bnumber=Integer.parseInt(t6.substring(1, t));
			Bstep=Integer.parseInt(t6.substring(t+1, tt));
			Bcount=Integer.parseInt(t6.substring(tt + 1, t6.length() - 1));
		}

		//System.out.println("Red string: Rnumber="+Rnumber+", Rstep="+Rstep+", Rcount="+Rcount); // debug
		//System.out.println("Green string: Gnumber="+Gnumber+", Gstep="+Gstep+", Gcount="+Gcount); // debug
		//System.out.println("Blue string: Bnumber="+Bnumber+", Bstep="+Bstep+", Bcount="+Bcount); // debug

		for (t=0; t<t3; t++)
		{
			rain(t1,t,_red + _green*16 + _blue*256);

			if (_redcountdone >= Rcount) // Reset the cycle from here...
			{
				_rednumberon=0; _redcountdone=0; _red=0;
			}
			_rednumberon++;
			if (_rednumberon == Rnumber)
			{
				_red += Rstep; _red=_red % 16;
				_rednumberon=0;
				_redcountdone++; // Does this go here, or below?
			}

			if (_greencountdone >= Gcount) // Reset the cycle from here...
			{
				_greennumberon=0; _greencountdone=0; _green=0;
			}
			_greennumberon++;
			if (_greennumberon == Gnumber)
			{
				_green += Gstep; _green=_green % 16;
				_greennumberon=0;
				_greencountdone++; // Does this go here, or below?
			}

			if (_bluecountdone >= Bcount) // Reset the cycle from here...
			{	_bluenumberon=0; _bluecountdone=0; _blue=0;
			}
			_bluenumberon++;
			if (_bluenumberon == Bnumber)
			{
				_blue += Bstep; _blue=_blue % 16;
				_bluenumberon=0;
				_bluecountdone++; // Does this go here, or below?
			}
		}
	}
	public void rainbowDel()
	{
	}
	public void rainbowDel(int a)
	{
	}

	// Misc (to sort):
	public void hide()
	{
		hideOn();
	}
	public void hideOn()
	{
	}
	public void hideOff()
	{
	}
	public void updateEvery(int a)
	{
	}
	public void flashOff()
	{
	}
	public void flash(int a, String b)
	{
	}
	public void bobOff(int a)
	{
		wrapper.boboff(a);
	}
	public void bobOff()
	{
		wrapper.boboff();
	}
	public void setBob(int a, int b, int c, int d)
	{
	}
	public void spriteOff(int a)
	{
		wrapper.spriteoff(a);
	}
	public void spriteOff()
	{
		wrapper.spriteoff();
	}
	public void setSpriteBuffer(int a)
	{
	}

	// May require extended syntax:
	public void setReg(int a, int b)
	{
	}
	public void unpack(int a, int b)
	{
	}

	// To do - tests for Environment Generator:
	public boolean isScreen(int a)
	{
		return false;
	}
	public boolean isNotScreen(int a)
	{
		return false;
	}
	public boolean isBank(int a)
	{
		return false;
	}
	public boolean isNotBank(int a)
	{
		return false;
	}
	public boolean isReg(int a, int b)
	{
		return (a) != b;
	}

	// New:
	public void bell()
	{
		wrapper.bell();
	}
	public void bell(int pitch)
	{
		wrapper.bell(pitch);
	}
	public void shoot()
	{
		wrapper.shoot();
	}
	public void boom()
	{
		wrapper.boom();
	}

}
