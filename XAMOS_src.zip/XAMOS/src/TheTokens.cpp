#include "TheTokens.h"

TheTokens::TheTokens()
{
	name = "";
}

TheTokens::TheTokens(string s)
{
	name = s;
}

