#include "Console.h"

Console::Console()
{
}

