make clean
make
rm *.o
cd ..
./XAMOS
