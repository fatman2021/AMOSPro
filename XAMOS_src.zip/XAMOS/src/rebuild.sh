make clean
make
cd ..
./XAMOS
