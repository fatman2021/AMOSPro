// Stub Console class:

#ifndef CONSOLE_H
#define CONSOLE_H
class Console
{
public:
	Console();
};
#endif

