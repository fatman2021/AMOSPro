make
cd ..
./XAMOS
