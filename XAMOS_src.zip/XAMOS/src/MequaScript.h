#ifndef MEQUASCRIPT_H
#define MEQUASCRIPT_H
class MequaScript
{
public:
	int debugtest(int argc, char *argv[]);
	int mymain(int argc, char *argv[]);
};
#endif
