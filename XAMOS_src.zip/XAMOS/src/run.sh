cd ..
./XAMOS
