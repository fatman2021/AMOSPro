#ifndef MULTIEXPRESSIONRETURN_H
#define MULTIEXPRESSIONRETURN_H

#include "ExpressionReturn.h"

class ExpressionReturn;


class MultiExpressionReturn
{
public:
	ExpressionReturn exp[20];
	int numexpressions;
};
#endif

