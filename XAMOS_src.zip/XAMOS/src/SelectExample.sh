cd ..
./XAMOS -launcher
